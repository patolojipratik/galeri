from __future__ import annotations

import subprocess
import threading
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import messagebox, ttk

APP_ROOT = Path(__file__).resolve().parents[1]


def _python() -> Path:
    candidate = APP_ROOT / ".venv" / "Scripts" / "python.exe"
    return candidate if candidate.exists() else Path(__import__("sys").executable)


def _run_tool(script: Path, *args: str) -> None:
    if not script.exists():
        raise RuntimeError(f"Arac bulunamadi: {script}")
    flags = subprocess.CREATE_NO_WINDOW if __import__("os").name == "nt" else 0
    subprocess.Popen([str(_python()), str(script), *args], cwd=str(APP_ROOT), creationflags=flags)


def _open_docs() -> None:
    local = APP_ROOT / "_belgeler" / "HARICI_SSD_DEVAM_REHBERI.md"
    if local.exists():
        try:
            __import__("os").startfile(str(local))
            return
        except Exception:
            pass
    webbrowser.open("https://github.com/patolojipratik/galeri/blob/main/HARICI_SSD_DEVAM_REHBERI.md")


class MaintenanceWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Patoloji Pratik - Bakim ve Sistem")
        self.geometry("820x610")
        self.minsize(720, 520)
        self.transient(parent)

        container = ttk.Frame(self, padding=18)
        container.pack(fill="both", expand=True)
        ttk.Label(container, text="Bakim ve Sistem", font=("Segoe UI", 17, "bold")).pack(anchor="w")
        ttk.Label(
            container,
            text="Gunluk slayt islemlerinden ayri; konum, yedek, web ve sistem denetimleri.",
        ).pack(anchor="w", pady=(4, 14))

        buttons = ttk.Frame(container)
        buttons.pack(fill="x")
        specs = [
            ("Sistem saglik kontrolu", self.health),
            ("Konumlar ve ilk kurulum", self.locations),
            ("Guvenlik yedegi olustur", self.backup),
            ("Kurtarma ZIP'i olustur", self.recovery),
            ("Web goruntulerini kontrol et", self.web_check),
            ("Web goruntulerini onar", self.web_repair),
            ("Guncelleme kanalini esitle", self.update_sync),
            ("Yerel temizlik onizleme", self.cleanup_preview),
            ("Kok klasoru sadelestir", self.root_layout),
            ("Kullanim rehberi", _open_docs),
        ]
        for i, (text, command) in enumerate(specs):
            ttk.Button(buttons, text=text, command=command).grid(row=i // 3, column=i % 3, padx=4, pady=4, sticky="ew")
        for i in range(3):
            buttons.columnconfigure(i, weight=1)

        ttk.Separator(container).pack(fill="x", pady=13)
        self.output = tk.Text(container, wrap="word", font=("Consolas", 9), padx=9, pady=9)
        self.output.pack(fill="both", expand=True)
        self._set("Hazir. 'Sistem saglik kontrolu' ile baslayabilirsiniz.")

    def _set(self, text: str) -> None:
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text)

    def _thread(self, func) -> None:
        self._set("Calisiyor...")

        def worker():
            try:
                value = func()
                text = str(value)
            except Exception as exc:
                text = f"HATA: {type(exc).__name__}: {exc}"
            self.after(0, lambda: self._set(text))

        threading.Thread(target=worker, daemon=True).start()

    def health(self) -> None:
        from .system_health import format_checks, run_checks
        self._thread(lambda: format_checks(run_checks()))

    def locations(self) -> None:
        from .storage_manager import configure_locations
        value = configure_locations(self)
        self._set("Konumlar kaydedildi.\n\n" + "\n".join(f"{k}: {v}" for k, v in value.items()))

    def backup(self) -> None:
        from .backup_manager import create_safety_backup
        try:
            path = create_safety_backup("manual")
            self._set(f"Guvenlik yedegi olusturuldu:\n{path}")
        except Exception as exc:
            messagebox.showerror("Yedek hatasi", str(exc), parent=self)

    def recovery(self) -> None:
        from .backup_manager import create_recovery_zip
        try:
            path = create_recovery_zip()
            self._set(f"Kurtarma ZIP'i olusturuldu:\n{path}\n\nToken ve kaynak slaytlar bu ZIP'e alinmaz.")
        except Exception as exc:
            messagebox.showerror("Kurtarma ZIP hatasi", str(exc), parent=self)

    def web_check(self) -> None:
        from .viewer_repair import verify_all

        def work():
            lines = []
            result = verify_all(from_number=76, progress=lambda text: lines.append(str(text)))
            return "\n".join(lines + ["", str(result)])

        self._thread(work)

    def web_repair(self) -> None:
        try:
            from .viewer_repair import repair_in_background
            repair_in_background(self.parent, from_number=76)
            self._set("Web goruntuleyici onarimi arka planda baslatildi.")
        except Exception as exc:
            messagebox.showerror("Web onarim hatasi", str(exc), parent=self)

    def update_sync(self) -> None:
        script = APP_ROOT / "_sistem" / "araclar" / "guncelleme_kanalini_esitle.py"
        try:
            _run_tool(script)
            self._set("Guncelleme kanali esitleme araci baslatildi. Sonuc logs klasorune yazilir.")
        except Exception as exc:
            messagebox.showerror("Guncelleme kanali", str(exc), parent=self)


    def root_layout(self) -> None:
        try:
            from .root_layout_manager import migrate
            result = migrate(self)
            self._set(
                "Kok klasor duzeni uygulandi.\n\n"
                f"Tasinan: {len(result.get('moved', []))}\n"
                f"Tasinamayan: {len(result.get('left', []))}\n\n"
                "Bundan sonra kokte BASLAT.bat kullanin."
            )
        except Exception as exc:
            messagebox.showerror("Kok klasor duzeni", str(exc), parent=self)

    def cleanup_preview(self) -> None:
        script = APP_ROOT / "_sistem" / "araclar" / "yerel_temizlik.py"
        try:
            result = subprocess.run(
                [str(_python()), str(script)],
                cwd=str(APP_ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=120,
            )
            self._set(result.stdout)
        except Exception as exc:
            messagebox.showerror("Temizlik onizleme", str(exc), parent=self)


def open_maintenance(parent) -> None:
    existing = getattr(parent, "_maintenance_window", None)
    try:
        if existing is not None and existing.winfo_exists():
            existing.lift()
            existing.focus_force()
            return
    except Exception:
        pass
    window = MaintenanceWindow(parent)
    parent._maintenance_window = window
