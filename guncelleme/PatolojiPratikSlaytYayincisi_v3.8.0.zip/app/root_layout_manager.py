from __future__ import annotations

import json
import shutil
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]
SYSTEM = APP_ROOT / "_sistem"
STATE = SYSTEM / "kok_duzeni.json"

NEW_BASLAT = r'''@echo off
setlocal
cd /d "%~dp0"
if not exist "_sistem\BASLAT_IC.bat" (
  echo Patoloji Pratik sistem dosyalari bulunamadi.
  echo _sistem klasorunu kontrol edin.
  pause
  exit /b 1
)
call "_sistem\BASLAT_IC.bat"
endlocal
'''

START_TEXT = """PATOLOJI PRATIK - BURADAN BASLAYIN

Normal kullanimda yalnizca BASLAT.bat dosyasina cift tiklayin.

Program:
- SSD/PC surucu harfi degisse de kendi konumunu algilar.
- Kaynak slayt klasorunu bulamazsa size sorar ve secimi kaydeder.
- Kucuk guvenlik yedeklerini bilgisayarda ayrica saklayabilir.
- Yeni surum varsa BASLAT sirasinda guncelleme secenegi gosterir.

Teknik araclar: _sistem
Kullanim belgeleri: _belgeler
Eski rapor ve dosyalar: _arsiv

Kaynak KFB/SVS dosyalari ve GitHub tokeni otomatik kurtarma ZIP'ine dahil edilmez.
"""


def is_done() -> bool:
    try:
        value = json.loads(STATE.read_text(encoding="utf-8"))
        return bool(value.get("done"))
    except Exception:
        return False


def migrate(parent=None) -> dict:
    SYSTEM.mkdir(parents=True, exist_ok=True)
    (APP_ROOT / "_belgeler").mkdir(parents=True, exist_ok=True)
    (APP_ROOT / "_arsiv").mkdir(parents=True, exist_ok=True)

    main_script = APP_ROOT / "baslat.py"
    system_main = SYSTEM / "baslat.py"
    if main_script.exists():
        shutil.copy2(main_script, system_main)
    elif not system_main.exists():
        raise RuntimeError("Ana baslat.py bulunamadi; kok duzeni degistirilmedi.")

    req = APP_ROOT / "requirements.txt"
    if req.exists():
        shutil.copy2(req, SYSTEM / "requirements.txt")

    version = APP_ROOT / "version.json"
    if version.exists():
        target = SYSTEM / "guncelleme" / "version.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(version, target)

    (APP_ROOT / "BASLAT.bat").write_text(NEW_BASLAT, encoding="utf-8")
    (APP_ROOT / "BURADAN_BASLAYIN.txt").write_text(START_TEXT, encoding="utf-8")

    import sys
    sys.path.insert(0, str(SYSTEM))
    from root_finalize import finalize
    return finalize()


def schedule_migration(root_widget) -> None:
    if is_done():
        return

    def ask():
        try:
            worker = getattr(root_widget, "worker", None)
            if worker is not None and worker.is_alive():
                root_widget.after(2500, ask)
                return
        except Exception:
            pass
        try:
            from tkinter import messagebox
            answer = messagebox.askyesno(
                "Patoloji Pratik - Klasorleri sadelestir",
                f"{APP_ROOT} kok klasoru teknik dosyalarla kalabalik.\n\n"
                "Simdi duzenlenirse kokte yalnizca BASLAT.bat ve BURADAN_BASLAYIN.txt kalir; "
                "teknik dosyalar _sistem, belgeler _belgeler, eski dosyalar _arsiv altina tasinir.\n\n"
                "app/config/data/repos/work/guncelleme ve kaynak slaytlar korunur.\n\n"
                "Simdi duzenlensin mi?",
                parent=root_widget,
            )
            if not answer:
                return
            result = migrate(root_widget)
            messagebox.showinfo(
                "Klasor duzeni tamamlandi",
                "Kok klasor sadelestirildi.\n\n"
                "Bundan sonra yalnizca BASLAT.bat kullanin.\n"
                f"Tasinamayan oge: {len(result.get('left', []))}",
                parent=root_widget,
            )
        except Exception as exc:
            try:
                from tkinter import messagebox
                messagebox.showerror("Klasor duzeni", str(exc), parent=root_widget)
            except Exception:
                pass

    root_widget.after(3500, ask)
