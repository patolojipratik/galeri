from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SYSTEM = ROOT / "_sistem"
ARCHIVE = ROOT / "_arsiv"
DOCS = ROOT / "_belgeler"

KEEP_FILES = {"BASLAT.bat", "BURADAN_BASLAYIN.txt"}
KEEP_DIRS = {
    ".venv", "app", "config", "data", "github", "guncelleme", "logs", "repos", "work",
    "_sistem", "_belgeler", "_arsiv",
}


def _move(source: Path, destination: Path) -> bool:
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            destination = destination.with_name(destination.stem + "_" + stamp + destination.suffix)
        shutil.move(str(source), str(destination))
        return True
    except Exception:
        return False


def finalize() -> dict[str, list[str]]:
    ARCHIVE.mkdir(parents=True, exist_ok=True)
    DOCS.mkdir(parents=True, exist_ok=True)
    moved: list[str] = []
    left: list[str] = []

    cache = ROOT / "__pycache__"
    if cache.exists():
        shutil.rmtree(cache, ignore_errors=True)

    public_release = ROOT / "public_release"
    if public_release.exists():
        if _move(public_release, ARCHIVE / "public_release"):
            moved.append("public_release")
        else:
            left.append("public_release")

    stamp_folder = ARCHIVE / "kok_eski_dosyalar"
    stamp_folder.mkdir(parents=True, exist_ok=True)

    for item in list(ROOT.iterdir()):
        if item.is_dir():
            if item.name in KEEP_DIRS:
                continue
            # Unknown top-level folders are not moved automatically.
            left.append(item.name)
            continue
        if item.name in KEEP_FILES:
            continue
        if item.name.lower() == "baslat.py":
            target = SYSTEM / "baslat.py"
            if not target.exists():
                try:
                    shutil.copy2(item, target)
                except Exception:
                    left.append(item.name)
                    continue
        if item.name.lower() == "requirements.txt":
            try:
                shutil.copy2(item, SYSTEM / "requirements.txt")
            except Exception:
                pass
        if item.name.lower() == "version.json":
            try:
                target = SYSTEM / "guncelleme" / "version.json"
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target)
            except Exception:
                pass
        if _move(item, stamp_folder / item.name):
            moved.append(item.name)
        else:
            left.append(item.name)

    state = {
        "done": not bool(left),
        "moved": moved,
        "left": left,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    (SYSTEM / "kok_duzeni.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return state


if __name__ == "__main__":
    print(json.dumps(finalize(), ensure_ascii=False, indent=2))
