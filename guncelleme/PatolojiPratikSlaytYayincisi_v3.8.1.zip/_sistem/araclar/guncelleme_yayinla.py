from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import tkinter as tk
from tkinter import filedialog, messagebox

APP_ROOT = Path(__file__).resolve().parents[2]
SYSTEM_UPDATE = APP_ROOT / "_sistem" / "guncelleme"
sys.path.insert(0, str(SYSTEM_UPDATE))
from update_crypto import load_key, private_to_public, sign, verify
MANAGED_START = "<!-- PATOLOJI-UPDATE-START -->"
MANAGED_END = "<!-- PATOLOJI-UPDATE-END -->"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON nesnesi bekleniyordu: {path}")
    return value


def _version_tuple(value: str) -> tuple[int, ...]:
    numbers = [int(x) for x in re.findall(r"\d+", str(value))]
    return tuple(numbers or [0])


def _read_sidecar_signature(package: Path, digest: str) -> str | None:
    """Paketin onceden uretilmis guvenilir imzasini bulup dogrula."""
    roots = [package.parent, APP_ROOT / "guncelleme", APP_ROOT / "guncelleme" / "uygulandi"]
    public_path = SYSTEM_UPDATE / "update_trusted_public.key"
    if not public_path.exists():
        return None
    trusted = load_key(public_path)
    seen: set[Path] = set()
    for root in roots:
        sig_path = root / (package.name + ".sig")
        sha_path = root / (package.name + ".sha256.txt")
        if sig_path in seen:
            continue
        seen.add(sig_path)
        if not sig_path.exists():
            continue
        if sha_path.exists():
            parts = sha_path.read_text(encoding="ascii", errors="replace").split()
            if parts and parts[0].strip().lower() != digest.lower():
                continue
        signature = sig_path.read_text(encoding="ascii", errors="replace").strip()
        if signature and verify(digest.encode("ascii"), signature, trusted):
            return signature
    return None


def settings() -> dict[str, Any]:
    path = APP_ROOT / "config" / "settings.json"
    return read_json(path) if path.exists() else {}


def token_for(username: str) -> str:
    try:
        sys.path.insert(0, str(APP_ROOT))
        from app.token_store import get_token  # type: ignore
        value = get_token(username)
        if value:
            return value.strip()
    except Exception:
        pass
    try:
        import keyring
        value = keyring.get_password("patoloji-pratik-github-yayinlama", username)
        if value:
            return value.strip()
    except Exception:
        pass
    raise RuntimeError("GitHub tokeni bulunamadi. Once GITHUB_BAGLA.bat calistirin.")


def find_git() -> str:
    direct = shutil.which("git")
    if direct:
        return direct
    candidates = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Git" / "cmd" / "git.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Git" / "cmd" / "git.exe",
    ]
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    if local:
        candidates.extend(sorted(local.glob("GitHubDesktop/app-*/resources/app/git/cmd/git.exe"), reverse=True))
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    raise RuntimeError("git.exe bulunamadi")


def git_env(username: str, token: str, askpass: Path) -> dict[str, str]:
    env = os.environ.copy()
    env.update(
        {
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_ASKPASS": str(askpass),
            "GITHUB_USERNAME": username,
            "GITHUB_TOKEN": token,
        }
    )
    return env


def run_git(args: list[str], cwd: Path, env: dict[str, str]) -> str:
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    # Bu yayinci, Windows/Git Credential Manager'da kayitli baska GitHub
    # hesaplarini kullanmamalidir. Sadece uygulamanin Windows kimlik kasasindan
    # okudugu hedef hesap tokeni GIT_ASKPASS ile kullanilir. Bos helper degeri,
    # bu subprocess icin kalitsal credential helper listesini sifirlar.
    result = subprocess.run(
        [find_git(), "-c", "credential.helper=", *args],
        cwd=str(cwd),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=flags,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} basarisiz:\n{result.stdout}")
    return result.stdout


def validate_package(path: Path) -> tuple[dict[str, Any], str]:
    if not path.exists() or path.suffix.lower() != ".zip":
        raise ValueError("Gecerli bir ZIP paketi secin")
    with zipfile.ZipFile(path) as archive:
        try:
            manifest = json.loads(archive.read("update-package.json").decode("utf-8"))
        except KeyError as exc:
            raise ValueError("ZIP icinde update-package.json yok") from exc
        if not isinstance(manifest, dict):
            raise ValueError("update-package.json gecersiz")
        files = manifest.get("files")
        if not isinstance(files, dict) or not files:
            raise ValueError("Paket dosya listesi eksik")
        for name, expected in files.items():
            try:
                data = archive.read(str(name))
            except KeyError as exc:
                raise ValueError(f"Pakette eksik dosya: {name}") from exc
            if hashlib.sha256(data).hexdigest() != str(expected).lower():
                raise ValueError(f"Paket ici SHA-256 hatasi: {name}")
        try:
            notes = archive.read("SURUM_NOTLARI.md").decode("utf-8")
        except KeyError:
            notes = f"# {manifest.get('label') or manifest.get('version')}\n\nGuncelleme paketi.\n"
    version = str(manifest.get("version") or "").strip()
    if not version:
        raise ValueError("Paket surumu eksik")
    return manifest, notes


def choose_zip() -> Path | None:
    root = tk.Tk()
    root.withdraw()
    value = filedialog.askopenfilename(
        title="Yayinlanacak Patoloji Pratik guncelleme ZIP'ini secin",
        initialdir=str(APP_ROOT / "guncelleme"),
        filetypes=[("ZIP paketi", "*.zip")],
    )
    root.destroy()
    return Path(value) if value else None


def update_readme(existing: str, version: str, package_name: str) -> str:
    """Geriye donuk uyumluluk icin tutulur; README artik otomatik degistirilmez."""
    return existing


def publish(package: Path) -> str:
    manifest, notes = validate_package(package)
    version = str(manifest["version"])
    config = settings()
    username = str(config.get("github_username") or "patolojipratik").strip()
    repo = str(config.get("gallery_repo") or "galeri").strip()
    token = token_for(username)

    digest = sha256(package)
    signature = _read_sidecar_signature(package, digest)
    if not signature:
        private_path = APP_ROOT / "config" / "update_signing_private.key"
        public_path = SYSTEM_UPDATE / "update_trusted_public.key"
        if not private_path.exists():
            raise RuntimeError(
                "Guncelleme icin dogrulanmis .sig dosyasi veya imzalama anahtari bulunamadi."
            )
        private = load_key(private_path)
        trusted = load_key(public_path)
        if private_to_public(private) != trusted:
            raise RuntimeError("Ozel imzalama anahtari guvenilir acik anahtarla eslesmiyor")
        signature = sign(digest.encode("ascii"), private)
    release = {
        "schema": 1,
        "version": version,
        "title": str(manifest.get("label") or version),
        "package": package.name,
        "sha256": digest,
        "signature": signature,
        "release_notes": "SURUM_NOTLARI.md",
        "mandatory": bool(manifest.get("mandatory", False)),
        "published_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }

    temp_root = Path(tempfile.mkdtemp(prefix="patoloji_pratik_publish_"))
    try:
        askpass = temp_root / ("askpass.cmd" if os.name == "nt" else "askpass.sh")
        if os.name == "nt":
            askpass.write_text(
                "@echo off\n"
                "echo %~1 | findstr /I \"Username\" >nul\n"
                "if not errorlevel 1 (echo %GITHUB_USERNAME%) else (echo %GITHUB_TOKEN%)\n",
                encoding="utf-8",
            )
        else:
            askpass.write_text(
                "#!/bin/sh\ncase \"$1\" in *Username*) echo \"$GITHUB_USERNAME\";; *) echo \"$GITHUB_TOKEN\";; esac\n",
                encoding="utf-8",
            )
            askpass.chmod(0o700)
        env = git_env(username, token, askpass)
        repo_dir = temp_root / "galeri"
        remote = f"https://github.com/{username}/{repo}.git"
        run_git(["clone", "--depth=1", "--branch", "main", remote, str(repo_dir)], temp_root, env)

        remote_latest = repo_dir / "guncelleme" / "latest.json"
        if remote_latest.exists():
            try:
                remote_version = str(read_json(remote_latest).get("version") or "0")
                if _version_tuple(remote_version) > _version_tuple(version):
                    return f"GitHub guncelleme kanali daha yeni: {remote_version}. Geriye dusurulmedi."
            except Exception:
                pass

        update_dir = repo_dir / "guncelleme"
        update_dir.mkdir(parents=True, exist_ok=True)
        for old in update_dir.glob("*.zip"):
            if old.name != package.name:
                old.unlink(missing_ok=True)
        for old in update_dir.glob("*.zip.sha256.txt"):
            if old.name != package.name + ".sha256.txt":
                old.unlink(missing_ok=True)
        for old in update_dir.glob("*.zip.sig"):
            if old.name != package.name + ".sig":
                old.unlink(missing_ok=True)
        shutil.copy2(package, update_dir / package.name)
        (update_dir / (package.name + ".sha256.txt")).write_text(
            f"{digest}  {package.name}\n", encoding="ascii"
        )
        (update_dir / (package.name + ".sig")).write_text(signature + "\n", encoding="ascii")
        (update_dir / "latest.json").write_text(
            json.dumps(release, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        (update_dir / "SURUM_NOTLARI.md").write_text(notes, encoding="utf-8")

        public_docs = (
            "HARICI_SSD_DEVAM_REHBERI.md",
            "KENDI_SISTEMINI_KUR.md",
            "YONETICI_REHBERI_TR.md",
            "KURULUM_GUNCELLEME_KURTARMA_REHBERI_TR.md",
            "YEREL_KLASOR_TEMIZLIK_REHBERI_TR.md",
            "GUNCELLEME_SISTEMI_README.md",
            "AGENTS.md",
        )
        for doc in public_docs:
            source = APP_ROOT / "_belgeler" / doc
            if not source.exists():
                source = APP_ROOT / doc
            if source.exists():
                shutil.copy2(source, repo_dir / doc)
        # README.md depo sahibinin yonettigi insan belgesidir. Guncelleme yayinlama
        # araci README'yi artik ne degistirir ne de stage eder.
        add_paths = ["guncelleme"] + [doc for doc in public_docs if (repo_dir / doc).exists()]
        run_git(["add", *add_paths], repo_dir, env)
        status = run_git(["status", "--porcelain"], repo_dir, env).strip()
        if not status:
            return "GitHub'daki guncelleme zaten ayni surumde."
        run_git(["config", "user.name", str(config.get("commit_name") or "Patoloji Pratik")], repo_dir, env)
        email = str(config.get("commit_email") or f"{username}@users.noreply.github.com")
        run_git(["config", "user.email", email], repo_dir, env)
        run_git(["commit", "-m", f"Guncelleme {version} yayinlandi"], repo_dir, env)
        try:
            run_git(["push", "origin", "main"], repo_dir, env)
        except RuntimeError as exc:
            detail = str(exc).lower()
            if not any(x in detail for x in ("fetch first", "non-fast-forward", "rejected")):
                raise
            # Another gallery/update commit may have landed after the shallow
            # clone. Rebase once; never force-push.
            run_git(["fetch", "origin", "main"], repo_dir, env)
            try:
                run_git(["rebase", "FETCH_HEAD"], repo_dir, env)
            except Exception:
                try:
                    run_git(["rebase", "--abort"], repo_dir, env)
                except Exception:
                    pass
                raise RuntimeError(
                    "GitHub'daki yeni commit otomatik birlestirilemedi. Force push yapilmadi."
                ) from exc
            run_git(["push", "origin", "main"], repo_dir, env)
        return f"Guncelleme yayinlandi: {username}/{repo}/guncelleme/{package.name}"
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", nargs="?")
    args = parser.parse_args()
    package = Path(args.package).resolve() if args.package else choose_zip()
    if package is None:
        return 0
    try:
        result = publish(package)
        print(result)
        if os.name == "nt":
            root = tk.Tk(); root.withdraw(); messagebox.showinfo("Guncelleme yayini", result); root.destroy()
        return 0
    except Exception as exc:
        print(f"HATA: {exc}")
        if os.name == "nt":
            root = tk.Tk(); root.withdraw(); messagebox.showerror("Guncelleme yayini hatasi", str(exc)); root.destroy()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
