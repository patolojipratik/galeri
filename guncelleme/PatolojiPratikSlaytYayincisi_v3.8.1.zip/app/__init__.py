from __future__ import annotations

"""Patoloji Pratik uygulama paketi.

Ana masaustu arayuzu baslatilirken:
- surum etiketini version.json ile esler,
- ana galeri README.md dosyasini korur,
- ana galeri kartlarinda Baslik/Tani alanlarini dogru sirada gosterir,
- lightweight Pages viewer/workflow ciktilarini same-origin full Pages yapisina
  dosya yazilirken cevirir,
- yalnizca gorunumsal/yardimci GUI iyilestirmelerini uygular,
- kurulan imzali guncellemeyi uygun bakim bilgisayarinda GitHub kanalina esitlemeyi planlar.

Diger komut satiri araclarinda GUI monkey-patch'i kurulmaz.
"""

import json
import sys
from pathlib import Path


def _running_main_gui() -> bool:
    try:
        return Path(sys.argv[0]).name.lower() == "baslat.py"
    except Exception:
        return False


def _sync_display_version() -> None:
    try:
        from . import config as _config

        root = Path(__file__).resolve().parents[1]
        version_file = root / "_sistem" / "guncelleme" / "version.json"
        if not version_file.exists():
            version_file = root / "version.json"
        if not version_file.exists():
            return
        raw = json.loads(version_file.read_text(encoding="utf-8"))
        label = str(raw.get("label") or raw.get("version") or "").strip()
        if label:
            _config.APP_VERSION = label
    except Exception:
        pass


if _running_main_gui():
    _sync_display_version()
    try:
        from .gallery_readme_guard import install_gallery_readme_guard
        install_gallery_readme_guard()
    except Exception:
        pass
    try:
        from .gallery_display_guard import install_gallery_display_guard
        install_gallery_display_guard()
    except Exception:
        pass
    try:
        from .viewer_repair import install_viewer_html_guard
        install_viewer_html_guard()
    except Exception:
        pass
    try:
        from .ui_enhancer import install_ui_enhancer
        install_ui_enhancer()
    except Exception:
        pass
