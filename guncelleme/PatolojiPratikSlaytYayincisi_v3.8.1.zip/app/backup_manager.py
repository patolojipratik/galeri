from __future__ import annotations

import json
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]
SYSTEM_DIR = APP_ROOT / "_sistem"
LOCATIONS_FILE = SYSTEM_DIR / "konumlar.json"
STATE_FILE = SYSTEM_DIR / "yedek_durumu.json"


def _read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def backup_root() -> Path:
    locations = _read_json(LOCATIONS_FILE)
    value = str(locations.get("pc_backup_dir") or "").strip()
    if value:
        path = Path(value)
        try:
            path.mkdir(parents=True, exist_ok=True)
            return path
        except Exception:
            pass
    fallback = APP_ROOT / "_arsiv" / "kurtarma"
    fallback.mkdir(parents=True, exist_ok=True)
    return fallback


def _critical_files() -> list[tuple[Path, str]]:
    files = [
        (APP_ROOT / "config" / "settings.json", "config/settings.json"),
        (APP_ROOT / "data" / "slides.csv", "data/slides.csv"),
        (APP_ROOT / "data" / "slides.pending.csv", "data/slides.pending.csv"),
        (SYSTEM_DIR / "guncelleme" / "version.json", "_sistem/guncelleme/version.json"),
        (SYSTEM_DIR / "konumlar.json", "_sistem/konumlar.json"),
        (APP_ROOT / "BURADAN_BASLAYIN.txt", "BURADAN_BASLAYIN.txt"),
    ]
    return [(src, rel) for src, rel in files if src.exists() and src.is_file()]


def create_safety_backup(reason: str = "manual") -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = backup_root() / "otomatik" / stamp
    target.mkdir(parents=True, exist_ok=True)
    for source, rel in _critical_files():
        destination = target / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
    state = _read_json(STATE_FILE)
    state.update(
        {
            "last_backup": datetime.now().isoformat(timespec="seconds"),
            "last_backup_path": str(target),
            "last_backup_reason": reason,
        }
    )
    _write_json(STATE_FILE, state)
    _prune_backups(backup_root() / "otomatik", keep=30)
    return target


def _prune_backups(folder: Path, keep: int = 30) -> None:
    if not folder.exists():
        return
    dirs = sorted((p for p in folder.iterdir() if p.is_dir()), key=lambda p: p.name, reverse=True)
    for old in dirs[keep:]:
        shutil.rmtree(old, ignore_errors=True)


def maybe_daily_backup() -> Path | None:
    state = _read_json(STATE_FILE)
    today = datetime.now().date().isoformat()
    last = str(state.get("last_backup") or "")[:10]
    if last == today:
        return None
    try:
        return create_safety_backup("daily")
    except Exception:
        return None


def create_recovery_zip() -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = backup_root() / "kurtarma"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"PatolojiPratik_Kurtarma_{stamp}.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for source, rel in _critical_files():
            archive.write(source, rel)
        docs = APP_ROOT / "_belgeler"
        if docs.exists():
            for source in docs.rglob("*"):
                if source.is_file():
                    archive.write(source, str(Path("_belgeler") / source.relative_to(docs)))
        info = (
            "PATOLOJI PRATIK KURTARMA PAKETI\n"
            "\n"
            "Bu ZIP kaynak KFB/SVS dosyalarini ve GitHub tokenini ICERMEZ.\n"
            "Yeni kurulumda once program dosyalarini kurun, sonra config ve data\n"
            "dosyalarini ayni konumlara geri kopyalayin.\n"
            "\n"
            f"Olusturma: {datetime.now().isoformat(timespec='seconds')}\n"
            f"Kaynak sistem: {APP_ROOT}\n"
        )
        archive.writestr("KURTARMA_BILGISI.txt", info.encode("utf-8"))
    state = _read_json(STATE_FILE)
    state.update(
        {
            "last_recovery_zip": datetime.now().isoformat(timespec="seconds"),
            "last_recovery_zip_path": str(target),
        }
    )
    _write_json(STATE_FILE, state)
    return target
