from __future__ import annotations

import os
import queue
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path

from .config import APP_ROOT, Settings


class GitError(RuntimeError):
    pass


def find_git() -> str:
    direct = shutil.which("git")
    if direct:
        return direct
    candidates = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Git" / "cmd" / "git.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Git" / "cmd" / "git.exe",
    ]
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    if local:
        candidates.extend(sorted(local.glob("GitHubDesktop/app-*/resources/app/git/cmd/git.exe"), reverse=True))
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    raise GitError("git.exe bulunamadi. Git for Windows kurulup PATH'e eklenmelidir.")


def _askpass_file() -> Path:
    path = APP_ROOT / "config" / "git-askpass.cmd"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "@echo off\n"
        "echo %~1 | findstr /I \"Username\" >nul\n"
        "if not errorlevel 1 (\n"
        "  echo %GITHUB_USERNAME%\n"
        ") else (\n"
        "  echo %GITHUB_TOKEN%\n"
        ")\n",
        encoding="utf-8",
    )
    return path


def _git_environment(token: str | None = None, username: str | None = None) -> dict[str, str]:
    env = os.environ.copy()
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["GIT_FLUSH"] = "1"
    if token and username:
        env["GIT_ASKPASS"] = str(_askpass_file())
        env["GITHUB_TOKEN"] = token
        env["GITHUB_USERNAME"] = username
    return env


def _format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def _format_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} GB"


def _repo_files(repo_dir: Path) -> list[tuple[Path, str, int]]:
    """Return regular repository files, excluding Git metadata."""
    files: list[tuple[Path, str, int]] = []
    for root, dirs, names in os.walk(repo_dir):
        dirs[:] = sorted(name for name in dirs if name != ".git")
        for filename in sorted(names):
            path = Path(root) / filename
            try:
                if not path.is_file():
                    continue
                rel = path.relative_to(repo_dir).as_posix()
                # Generated slide repositories use ASCII paths. Reject control
                # characters rather than creating an ambiguous fast-import stream.
                if any(ch in rel for ch in ("\n", "\r", "\x00")):
                    raise GitError(f"Git icin gecersiz dosya adi: {rel!r}")
                files.append((path, rel, path.stat().st_size))
            except OSError:
                continue
    return files


def _repo_statistics(repo_dir: Path) -> tuple[int, int]:
    files = _repo_files(repo_dir)
    return len(files), sum(size for _path, _rel, size in files)


def run_git(
    args: list[str],
    cwd: Path,
    *,
    token: str | None = None,
    username: str | None = None,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    git = find_git()
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    process = subprocess.run(
        [git, *args],
        cwd=str(cwd),
        env=_git_environment(token, username),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        encoding="utf-8",
        errors="replace",
        creationflags=creationflags,
    )
    if check and process.returncode != 0:
        raise GitError(f"git {' '.join(args)} basarisiz:\n{process.stdout}")
    return process


def _run_git_streaming(
    args: list[str],
    cwd: Path,
    *,
    token: str | None = None,
    username: str | None = None,
    progress=None,
    line_callback=None,
    heartbeat_callback=None,
    heartbeat_seconds: float = 5.0,
) -> subprocess.CompletedProcess[str]:
    """Run Git while keeping the GUI alive with concise heartbeat updates."""
    git = find_git()
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    process = subprocess.Popen(
        [git, *args],
        cwd=str(cwd),
        env=_git_environment(token, username),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        creationflags=creationflags,
    )
    if process.stdout is None:
        raise GitError("Git ciktisi okunamadi.")

    chunks: queue.Queue[bytes | None] = queue.Queue()

    def reader() -> None:
        try:
            while True:
                chunk = process.stdout.read(4096)
                if not chunk:
                    break
                chunks.put(chunk)
        finally:
            chunks.put(None)

    threading.Thread(target=reader, daemon=True).start()
    started = time.monotonic()
    last_heartbeat = started
    text_buffer = ""
    output_parts: list[str] = []
    output_chars = 0
    reader_finished = False

    def handle_line(line: str) -> None:
        cleaned = line.strip()
        if cleaned and line_callback:
            line_callback(cleaned, time.monotonic() - started)

    while True:
        try:
            item = chunks.get(timeout=0.5)
            if item is None:
                reader_finished = True
            else:
                decoded = item.decode("utf-8", errors="replace")
                if output_chars < 2_000_000:
                    remaining = 2_000_000 - output_chars
                    kept = decoded[:remaining]
                    output_parts.append(kept)
                    output_chars += len(kept)
                text_buffer += decoded.replace("\r", "\n")
                while "\n" in text_buffer:
                    line, text_buffer = text_buffer.split("\n", 1)
                    handle_line(line)
        except queue.Empty:
            pass

        now = time.monotonic()
        if progress and heartbeat_callback and now - last_heartbeat >= heartbeat_seconds:
            message, percent = heartbeat_callback(now - started)
            progress(message, percent)
            last_heartbeat = now

        if reader_finished and process.poll() is not None:
            break

    if text_buffer.strip():
        handle_line(text_buffer)
    returncode = process.wait()
    stdout = "".join(output_parts)
    result = subprocess.CompletedProcess([git, *args], returncode, stdout, None)
    if returncode != 0:
        raise GitError(f"git {' '.join(args)} basarisiz:\n{stdout}")
    return result


def _has_commit(repo_dir: Path) -> bool:
    result = run_git(["rev-parse", "--verify", "HEAD"], repo_dir, check=False)
    return result.returncode == 0 and bool(result.stdout.strip())


def _fast_import_initial_commit(
    repo_dir: Path,
    settings: Settings,
    message: str,
    progress=None,
) -> None:
    """Create the first commit directly as a Git pack, without slow git add."""
    files = _repo_files(repo_dir)
    total_files = len(files)
    total_bytes = sum(size for _path, _rel, size in files)
    if not files:
        raise GitError("Git reposuna eklenecek dosya bulunamadi.")

    if progress:
        progress(
            f"Hizli Git paketi basladi: {total_files:,} dosya, {_format_size(total_bytes)}",
            0,
        )

    git = find_git()
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    process = subprocess.Popen(
        [git, "fast-import", "--quiet"],
        cwd=str(repo_dir),
        env=_git_environment(),
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        creationflags=creationflags,
    )
    if process.stdin is None:
        raise GitError("Git fast-import girisi acilamadi.")

    started = time.monotonic()
    processed_bytes = 0
    # At most about 20 progress lines per large repository.
    report_every = max(250, total_files // 20)
    timestamp = int(time.time())
    commit_message = message.encode("utf-8")
    identity_name = settings.commit_name.replace("\n", " ").replace("\r", " ")
    identity_email = settings.commit_email.replace("\n", " ").replace("\r", " ")

    def write(data: bytes) -> None:
        try:
            process.stdin.write(data)
        except (BrokenPipeError, OSError) as exc:
            raise GitError(f"Git hizli paket aktarimi kesildi: {exc}") from exc

    try:
        write(b"commit refs/heads/main\n")
        write(f"author {identity_name} <{identity_email}> {timestamp} +0000\n".encode("utf-8"))
        write(f"committer {identity_name} <{identity_email}> {timestamp} +0000\n".encode("utf-8"))
        write(f"data {len(commit_message)}\n".encode("ascii"))
        write(commit_message)
        write(b"\n")
        write(b"deleteall\n")

        for index, (path, rel, size) in enumerate(files, start=1):
            # The generated repository paths contain no spaces, but fast-import
            # also accepts ordinary spaces after the mode/dataref fields.
            write(f"M 100644 inline {rel}\n".encode("utf-8"))
            write(f"data {size}\n".encode("ascii"))
            with path.open("rb") as handle:
                while True:
                    chunk = handle.read(1024 * 1024)
                    if not chunk:
                        break
                    write(chunk)
            write(b"\n")
            processed_bytes += size

            if progress and (
                index == total_files
                or index % report_every == 0
                or time.monotonic() - started < 1 and index == 1
            ):
                elapsed = time.monotonic() - started
                percent = index / total_files * 100
                progress(
                    f"Hizli Git paketi: %{percent:.0f} | {index:,}/{total_files:,} dosya | "
                    f"{_format_size(processed_bytes)} | {_format_duration(elapsed)}",
                    min(99.0, percent),
                )

        write(b"done\n")
        process.stdin.close()
        output = process.stdout.read() if process.stdout is not None else b""
        returncode = process.wait()
        if returncode != 0:
            detail = output.decode("utf-8", errors="replace")
            raise GitError(f"Git fast-import basarisiz:\n{detail}")
    finally:
        if process.poll() is None:
            try:
                process.kill()
            except OSError:
                pass

    # fast-import updates the branch but not the working-tree index. Build the
    # index directly from the new tree without re-hashing all JPEG files.
    run_git(["reset", "--mixed", "--no-refresh", "HEAD"], repo_dir)

    if progress:
        progress(
            f"Hizli Git paketi tamamlandi: {total_files:,} dosya | "
            f"sure {_format_duration(time.monotonic() - started)}",
            100,
        )


def _stage_compact(repo_dir: Path, progress=None) -> None:
    """Stage updates without --verbose; verbose output was a major small-file cost."""
    total_files, total_bytes = _repo_statistics(repo_dir)
    started = time.monotonic()
    if progress:
        progress(
            f"Git indeksleniyor: {total_files:,} dosya, {_format_size(total_bytes)}",
            None,
        )

    _run_git_streaming(
        ["add", "-A"],
        repo_dir,
        progress=progress,
        heartbeat_callback=lambda elapsed: (
            f"Git indeksleniyor | {total_files:,} dosya | gecen {_format_duration(elapsed)} | git.exe etkin",
            None,
        ),
        heartbeat_seconds=5.0,
    )
    if progress:
        progress(
            f"Git indeksleme tamamlandi: {total_files:,} dosya | "
            f"sure {_format_duration(time.monotonic() - started)}",
            100,
        )


def _push_with_progress(
    repo_dir: Path,
    settings: Settings,
    token: str,
    progress=None,
) -> None:
    last_detail = "GitHub baglantisi kuruluyor"
    last_percent: float | None = None
    last_report_phase = ""
    last_report_raw = -10
    percent_pattern = re.compile(r"(Counting|Compressing|Writing) objects:\s+(\d+)%", re.IGNORECASE)

    def on_line(line: str, elapsed: float) -> None:
        nonlocal last_detail, last_percent, last_report_phase, last_report_raw
        if not line:
            return
        last_detail = line[-180:]
        match = percent_pattern.search(line)
        if not match:
            return
        phase = match.group(1).lower()
        raw = int(match.group(2))
        if phase == "counting":
            last_percent = 5 + raw * 0.15
        elif phase == "compressing":
            last_percent = 20 + raw * 0.30
        else:
            last_percent = 50 + raw * 0.48

        # Log only phase changes and 5-percent steps instead of every percent.
        should_report = phase != last_report_phase or raw >= last_report_raw + 5 or raw == 100
        if should_report and progress:
            phase_tr = {
                "counting": "sayiliyor",
                "compressing": "sikistiriliyor",
                "writing": "gonderiliyor",
            }.get(phase, phase)
            progress(
                f"GitHub: {phase_tr} %{raw} | gecen {_format_duration(elapsed)}",
                min(98.0, last_percent),
            )
            last_report_phase = phase
            last_report_raw = raw

    def heartbeat(elapsed: float):
        return (
            f"GitHub yuklemesi suruyor | gecen {_format_duration(elapsed)} | git.exe etkin",
            last_percent,
        )

    push_args = ["-c", "credential.helper=", "push", "--progress", "-u", "origin", "main"]

    def do_push() -> None:
        _run_git_streaming(
            push_args,
            repo_dir,
            token=token,
            username=settings.github_username,
            progress=progress,
            line_callback=on_line,
            heartbeat_callback=heartbeat,
            heartbeat_seconds=5.0,
        )

    try:
        do_push()
    except GitError as exc:
        detail = str(exc).lower()
        non_fast_forward = any(
            marker in detail
            for marker in (
                "fetch first",
                "non-fast-forward",
                "rejected",
                "remote contains work that you do not have locally",
            )
        )
        if not non_fast_forward:
            raise
        if progress:
            progress(
                "GitHub'da daha yeni bir commit bulundu; uzak degisiklikler guvenli sekilde aliniyor",
                None,
            )
        # Never force-push the gallery. Fetch the newest remote commit and replay
        # the locally generated commit on top of it. This preserves README,
        # SCREEN.PNG and update-channel commits that may have arrived meanwhile.
        run_git(
            ["-c", "credential.helper=", "fetch", "origin", "main"],
            repo_dir,
            token=token,
            username=settings.github_username,
        )
        rebase = run_git(["rebase", "FETCH_HEAD"], repo_dir, check=False)
        if rebase.returncode != 0:
            run_git(["rebase", "--abort"], repo_dir, check=False)
            raise GitError(
                "GitHub'daki yeni degisiklikler otomatik birlestirilemedi. "
                "Force push yapilmadi; yerel veriler korunuyor.\n" + rebase.stdout
            ) from exc
        if progress:
            progress("Uzak degisiklikler alindi; GitHub yuklemesi yeniden deneniyor", None)
        do_push()
    if progress:
        progress("GitHub yuklemesi tamamlandi", 100)


def _configure_repo(repo_dir: Path, repo_name: str, settings: Settings) -> None:
    run_git(["config", "user.name", settings.commit_name], repo_dir)
    run_git(["config", "user.email", settings.commit_email], repo_dir)
    run_git(["config", "core.longpaths", "true"], repo_dir)
    run_git(["config", "core.preloadindex", "true"], repo_dir)
    run_git(["config", "core.fscache", "true"], repo_dir)
    run_git(["config", "core.untrackedCache", "true"], repo_dir)
    run_git(["config", "index.threads", "true"], repo_dir)
    run_git(["config", "index.version", "4"], repo_dir)
    # JPEG tiles are already compressed and rarely delta-compress well. Avoid
    # expensive pairwise delta searches and use light zlib compression.
    run_git(["config", "pack.window", "0"], repo_dir)
    run_git(["config", "pack.depth", "0"], repo_dir)
    run_git(["config", "pack.compression", "1"], repo_dir)
    run_git(["config", "core.compression", "1"], repo_dir)
    run_git(["config", "pack.threads", "0"], repo_dir)
    run_git(["config", "gc.auto", "0"], repo_dir)
    remote = f"https://github.com/{settings.github_username}/{repo_name}.git"
    current_remote = run_git(["remote", "get-url", "origin"], repo_dir, check=False)
    if current_remote.returncode == 0:
        run_git(["remote", "set-url", "origin", remote], repo_dir)
    else:
        run_git(["remote", "add", "origin", remote], repo_dir)


def prepare_and_push(
    repo_dir: Path,
    repo_name: str,
    settings: Settings,
    token: str,
    message: str,
    progress=None,
) -> str:
    repo_dir.mkdir(parents=True, exist_ok=True)
    if not (repo_dir / ".git").exists():
        run_git(["init", "-b", "main"], repo_dir)
    _configure_repo(repo_dir, repo_name, settings)

    initial_repo = not _has_commit(repo_dir)
    if initial_repo and getattr(settings, "fast_initial_import", True):
        _fast_import_initial_commit(repo_dir, settings, message, progress)
    else:
        _stage_compact(repo_dir, progress)
        status = run_git(["status", "--porcelain"], repo_dir)
        if status.stdout.strip():
            if progress:
                progress("Git commit olusturuluyor", None)
            _run_git_streaming(
                ["commit", "-m", message],
                repo_dir,
                progress=progress,
                heartbeat_callback=lambda elapsed: (
                    f"Git commit olusturuluyor | gecen {_format_duration(elapsed)} | git.exe etkin",
                    None,
                ),
            )

    run_git(["branch", "-M", "main"], repo_dir)
    if progress:
        progress("GitHub'a yukleme hazirlaniyor", None)
    _push_with_progress(repo_dir, settings, token, progress)
    return run_git(["rev-parse", "HEAD"], repo_dir).stdout.strip()


def trigger_pages_retry_commit(
    repo_dir: Path,
    repo_name: str,
    settings: Settings,
    token: str,
    message: str,
    progress=None,
) -> str:
    """Push a tiny empty commit to retrigger branch-based GitHub Pages.

    No slide tile is re-indexed or uploaded again. The local and remote HEAD remain
    identical, so normal verified cleanup can still run after Pages is reachable.
    """
    if not (repo_dir / ".git").exists():
        raise GitError(f"Pages yeniden denemesi icin yerel Git deposu yok: {repo_dir}")
    _configure_repo(repo_dir, repo_name, settings)
    remote = run_git(["rev-parse", "HEAD"], repo_dir).stdout.strip()
    if not remote:
        raise GitError("Pages yeniden denemesi icin yerel commit bulunamadi.")
    if progress:
        progress(f"{repo_name}: GitHub Pages icin kucuk yeniden deneme commit'i olusturuluyor", None)
    run_git(["commit", "--allow-empty", "-m", message], repo_dir)
    _push_with_progress(repo_dir, settings, token, progress)
    return run_git(["rev-parse", "HEAD"], repo_dir).stdout.strip()
