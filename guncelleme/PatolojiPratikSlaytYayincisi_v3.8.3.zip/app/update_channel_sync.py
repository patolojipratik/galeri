from __future__ import annotations

"""Kurulan guncellemeyi ana galeri reposundaki guncelleme kanalina esitle.

Bu ozellik yalnizca bu bilgisayarda hedef GitHub hesabi icin kayitli token
varsa calisir. Kullanici verisi veya slayt repolariyla ilgilenmez. Basarisizlik
ana programin acilmasini engellemez.
"""

import hashlib
import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Any


def _version_tuple(value: str) -> tuple[int, ...]:
    import re
    nums = [int(x) for x in re.findall(r"\d+", str(value))]
    return tuple(nums or [0])


def _manifest_version(path: Path) -> str:
    import zipfile
    try:
        with zipfile.ZipFile(path) as z:
            raw = json.loads(z.read("update-package.json").decode("utf-8"))
        return str(raw.get("version") or "0")
    except Exception:
        return "0"


def _current_version(root: Path) -> str:
    try:
        version_path = root / "_sistem" / "guncelleme" / "version.json"
        if not version_path.exists():
            version_path = root / "version.json"
        raw = json.loads(version_path.read_text(encoding="utf-8"))
        return str(raw.get("version") or "0")
    except Exception:
        return "0"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _find_package(root: Path) -> Path | None:
    current = _current_version(root)
    candidates: list[Path] = []
    for folder in (root / "guncelleme" / "uygulandi", root / "guncelleme"):
        if folder.exists():
            candidates.extend(p for p in folder.glob("*.zip") if p.is_file())
    exact = [p for p in candidates if _manifest_version(p) == current]
    if exact:
        return max(exact, key=lambda p: p.stat().st_mtime)
    return max(candidates, key=lambda p: (_version_tuple(_manifest_version(p)), p.stat().st_mtime), default=None)


def _token_available(root: Path) -> bool:
    username = "patolojipratik"
    try:
        settings = json.loads((root / "config" / "settings.json").read_text(encoding="utf-8"))
        username = str(settings.get("github_username") or username).strip()
    except Exception:
        pass
    try:
        from .token_store import get_token
        return bool((get_token(username) or "").strip())
    except Exception:
        return False


def _log(root: Path, message: str) -> None:
    path = root / "logs" / "update_channel_sync.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(f"{datetime.now().isoformat(timespec='seconds')} {message}\n")


def _worker(root: Path) -> None:
    try:
        if not _token_available(root):
            return
        package = _find_package(root)
        if not package:
            return
        digest = _sha256(package)
        marker = root / "guncelleme" / ".kanal_yayin.json"
        if marker.exists():
            try:
                raw: dict[str, Any] = json.loads(marker.read_text(encoding="utf-8"))
                if raw.get("sha256") == digest and raw.get("ok") is True:
                    return
            except Exception:
                pass
        import importlib.util
        publisher_path = root / "_sistem" / "araclar" / "guncelleme_yayinla.py"
        spec = importlib.util.spec_from_file_location("patoloji_update_publisher", publisher_path)
        if spec is None or spec.loader is None:
            raise RuntimeError("Guncelleme yayinlama araci bulunamadi")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        publish = module.publish
        result = publish(package)
        marker.write_text(
            json.dumps(
                {
                    "ok": True,
                    "version": _manifest_version(package),
                    "sha256": digest,
                    "published_at": datetime.now().isoformat(timespec="seconds"),
                    "result": result,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
        _log(root, result)
    except Exception as exc:
        _log(root, f"Otomatik guncelleme kanali esitleme atlandi/basarisiz: {type(exc).__name__}: {exc}")


def schedule_update_channel_sync(root_widget) -> None:
    """Publish the installed update only when the main GUI is idle.

    v3.8.0 could publish the update channel at the same time as the main gallery,
    creating two valid commits against the same remote head. The main gallery
    push then saw ``fetch first``. We now wait until the GUI worker is idle and
    allow only one background sync thread per process. Git push itself also has
    a safe non-fast-forward retry as a second line of defence.
    """
    try:
        app_root = Path(__file__).resolve().parents[1]
    except Exception:
        return

    def try_start() -> None:
        try:
            if bool(getattr(root_widget, "_update_channel_sync_running", False)):
                return
            worker = getattr(root_widget, "worker", None)
            if worker is not None and worker.is_alive():
                root_widget.after(5000, try_start)
                return
            setattr(root_widget, "_update_channel_sync_running", True)

            def run() -> None:
                try:
                    _worker(app_root)
                finally:
                    try:
                        root_widget.after(0, lambda: setattr(root_widget, "_update_channel_sync_running", False))
                    except Exception:
                        pass

            threading.Thread(target=run, daemon=True).start()
        except Exception:
            pass

    # Let startup scanning/recovery finish first.
    try:
        root_widget.after(15000, try_start)
    except Exception:
        pass
