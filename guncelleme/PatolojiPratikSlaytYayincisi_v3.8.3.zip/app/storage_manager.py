from __future__ import annotations

import ctypes
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

APP_ROOT = Path(__file__).resolve().parents[1]
SYSTEM_DIR = APP_ROOT / "_sistem"
LOCATIONS_FILE = SYSTEM_DIR / "konumlar.json"
SETTINGS_FILE = APP_ROOT / "config" / "settings.json"
SOURCE_NAMES = ("Pratik_slaytlar\u0131", "Pratik_slaytlari", "Pratik_slaytlari")


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _logical_drives() -> list[Path]:
    if os.name != "nt":
        return [APP_ROOT.anchor and Path(APP_ROOT.anchor) or Path("/")]
    try:
        mask = ctypes.windll.kernel32.GetLogicalDrives()
    except Exception:
        return []
    out: list[Path] = []
    for index in range(26):
        if mask & (1 << index):
            out.append(Path(f"{chr(65 + index)}:\\"))
    return out


def _candidate_source_paths(app_root: Path, configured: str = "") -> list[Path]:
    found: list[Path] = []

    def add(path: Path) -> None:
        try:
            resolved = path.resolve()
        except Exception:
            resolved = path
        key = str(resolved).casefold()
        if path.exists() and path.is_dir() and all(str(p).casefold() != key for p in found):
            found.append(path)

    if configured:
        add(Path(configured))

    for name in SOURCE_NAMES:
        add(app_root.parent / name)

    for drive in _logical_drives():
        for name in SOURCE_NAMES:
            add(drive / name)
    return found


def _default_pc_backup() -> Path:
    profile = Path(os.environ.get("USERPROFILE") or Path.home())
    documents = profile / "Documents"
    base = documents if documents.exists() else profile
    return base / "PatolojiPratik_Yedek"


def _choose_folder(title: str, initial: Path | None = None) -> Path | None:
    import tkinter as tk
    from tkinter import filedialog

    root = tk.Tk()
    root.withdraw()
    value = filedialog.askdirectory(title=title, initialdir=str(initial or APP_ROOT.parent))
    root.destroy()
    return Path(value) if value else None


def _ask_source(app_root: Path) -> Path | None:
    import tkinter as tk
    from tkinter import messagebox

    suggested = app_root.parent / "Pratik_slaytlar\u0131"
    root = tk.Tk()
    root.withdraw()
    create_default = messagebox.askyesno(
        "Patoloji Pratik - Kaynak klasoru",
        "Kaynak KFB/SVS klasoru bulunamadi.\n\n"
        f"{suggested}\n\n"
        "Bu klasor olusturulup kullanilsin mi?\n"
        "Hayir derseniz var olan klasoru secebilirsiniz.",
        parent=root,
    )
    root.destroy()
    if create_default:
        suggested.mkdir(parents=True, exist_ok=True)
        return suggested
    return _choose_folder("KFB/SVS kaynak klasorunu secin", app_root.parent)


def _ask_backup(default_path: Path) -> Path | None:
    import tkinter as tk
    from tkinter import messagebox

    root = tk.Tk()
    root.withdraw()
    use_default = messagebox.askyesno(
        "Patoloji Pratik - Guvenlik yedegi",
        "Kucuk sistem yedekleri bilgisayarda da saklanabilir.\n"
        "Kaynak SVS/KFB dosyalari bu yedege alinmaz.\n\n"
        f"Onerilen klasor:\n{default_path}\n\n"
        "Bu konum kullanilsin mi?",
        parent=root,
    )
    root.destroy()
    if use_default:
        try:
            default_path.mkdir(parents=True, exist_ok=True)
            return default_path
        except Exception:
            pass
    return _choose_folder("Bilgisayardaki guvenlik yedegi klasorunu secin", default_path.parent)


def prepare_paths(app_root: Path | None = None, interactive: bool = True) -> dict[str, str]:
    root = Path(app_root or APP_ROOT).resolve()
    raw = _read_json(root / "config" / "settings.json")
    locations = _read_json(root / "_sistem" / "konumlar.json")
    changed = False

    current_work = str(raw.get("work_root") or "")
    if current_work != str(root):
        raw["work_root"] = str(root)
        changed = True

    configured_source = str(raw.get("source_dir") or locations.get("source_dir") or "").strip()
    candidates = _candidate_source_paths(root, configured_source)
    source: Path | None = candidates[0] if candidates else None
    if source is None and interactive:
        source = _ask_source(root)
    if source is not None:
        if str(raw.get("source_dir") or "") != str(source):
            raw["source_dir"] = str(source)
            changed = True

    backup_value = str(locations.get("pc_backup_dir") or "").strip()
    backup = Path(backup_value) if backup_value else _default_pc_backup()
    if backup_value and not backup.exists() and interactive:
        backup = _ask_backup(_default_pc_backup()) or backup
    elif not backup_value:
        try:
            backup.mkdir(parents=True, exist_ok=True)
        except Exception:
            if interactive:
                backup = _ask_backup(_default_pc_backup()) or backup

    if changed or not (root / "config" / "settings.json").exists():
        _write_json(root / "config" / "settings.json", raw)

    locations.update(
        {
            "app_root": str(root),
            "source_dir": str(source) if source is not None else configured_source,
            "pc_backup_dir": str(backup),
            "last_checked": datetime.now().isoformat(timespec="seconds"),
        }
    )
    _write_json(root / "_sistem" / "konumlar.json", locations)
    return {k: str(v) for k, v in locations.items() if isinstance(v, (str, int, float, bool))}


def configure_locations(parent=None) -> dict[str, str]:
    import tkinter as tk
    from tkinter import messagebox

    root = APP_ROOT
    locations = _read_json(LOCATIONS_FILE)
    current_source = Path(str(locations.get("source_dir") or root.parent))
    source = _choose_folder("KFB/SVS kaynak klasorunu secin", current_source)
    if source is None:
        source = current_source if current_source.exists() else None

    current_backup = Path(str(locations.get("pc_backup_dir") or _default_pc_backup()))
    backup = _choose_folder("Bilgisayardaki guvenlik yedegi klasorunu secin", current_backup)
    if backup is None:
        backup = current_backup
    backup.mkdir(parents=True, exist_ok=True)

    raw = _read_json(SETTINGS_FILE)
    raw["work_root"] = str(root)
    if source is not None:
        raw["source_dir"] = str(source)
    _write_json(SETTINGS_FILE, raw)

    locations.update(
        {
            "app_root": str(root),
            "source_dir": str(source) if source is not None else "",
            "pc_backup_dir": str(backup),
            "last_checked": datetime.now().isoformat(timespec="seconds"),
        }
    )
    _write_json(LOCATIONS_FILE, locations)

    try:
        messagebox.showinfo(
            "Konumlar kaydedildi",
            f"Program: {root}\nKaynak: {locations.get('source_dir','')}\nPC yedegi: {backup}",
            parent=parent,
        )
    except Exception:
        pass
    return {k: str(v) for k, v in locations.items() if isinstance(v, (str, int, float, bool))}
