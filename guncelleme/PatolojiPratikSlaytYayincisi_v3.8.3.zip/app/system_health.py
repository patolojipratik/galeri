from __future__ import annotations

import json
import os
import shutil
import sys
import urllib.request
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]


def _read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _find_git() -> str:
    direct = shutil.which("git")
    if direct:
        return direct
    candidates = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Git" / "cmd" / "git.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Git" / "cmd" / "git.exe",
    ]
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    if local:
        candidates.extend(sorted(local.glob("GitHubDesktop/app-*/resources/app/git/cmd/git.exe"), reverse=True))
    for item in candidates:
        if item.exists():
            return str(item)
    return ""


def _http_ok(url: str, timeout: float = 6.0) -> tuple[bool, str]:
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "PatolojiPratik-Health/1.0"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status == 200, f"HTTP {response.status}"
    except Exception as exc:
        return False, str(exc)


def run_checks() -> list[tuple[str, bool, str]]:
    settings = _read_json(APP_ROOT / "config" / "settings.json")
    locations = _read_json(APP_ROOT / "_sistem" / "konumlar.json")
    version = _read_json(APP_ROOT / "_sistem" / "guncelleme" / "version.json")
    if not version:
        version = _read_json(APP_ROOT / "version.json")

    out: list[tuple[str, bool, str]] = []
    out.append(("Python", sys.version_info >= (3, 10), sys.version.split()[0]))
    venv_python = APP_ROOT / ".venv" / "Scripts" / "python.exe"
    out.append(("Python ortami", venv_python.exists(), str(venv_python)))
    git = _find_git()
    out.append(("Git", bool(git), git or "Bulunamadi"))

    source = Path(str(settings.get("source_dir") or locations.get("source_dir") or ""))
    out.append(("Kaynak slayt klasoru", source.exists() and source.is_dir(), str(source)))
    out.append(("Program klasoru", APP_ROOT.exists(), str(APP_ROOT)))

    slides = APP_ROOT / "data" / "slides.csv"
    out.append(("slides.csv", slides.exists() and slides.stat().st_size > 0, str(slides)))

    backup = Path(str(locations.get("pc_backup_dir") or "")) if locations.get("pc_backup_dir") else None
    out.append(("PC guvenlik yedegi", bool(backup and backup.exists()), str(backup or "Ayarlanmadi")))

    try:
        free = shutil.disk_usage(APP_ROOT).free
        free_gb = free / (1024 ** 3)
        out.append(("Disk bos alani", free_gb >= 10, f"{free_gb:.1f} GB"))
    except Exception as exc:
        out.append(("Disk bos alani", False, str(exc)))

    username = str(settings.get("github_username") or "patolojipratik")
    try:
        from .token_store import get_token
        token = (get_token(username) or "").strip()
    except Exception:
        token = ""
    out.append(("GitHub token", bool(token), username if token else "Kayitli token bulunamadi"))

    repo = str(settings.get("gallery_repo") or "galeri")
    gallery_url = f"https://{username}.github.io/{repo}/"
    ok, detail = _http_ok(gallery_url)
    out.append(("Ana galeri web", ok, f"{gallery_url} - {detail}"))

    manifest_url = str(settings.get("update_manifest_url") or "").strip()
    if not manifest_url:
        manifest_url = f"https://raw.githubusercontent.com/{username}/{repo}/main/guncelleme/latest.json"
    ok, detail = _http_ok(manifest_url)
    out.append(("Guncelleme kanali", ok, f"{manifest_url} - {detail}"))

    out.append(("Uygulama surumu", bool(version.get("version")), str(version.get("label") or version.get("version") or "Bilinmiyor")))
    return out


def format_checks(checks: list[tuple[str, bool, str]]) -> str:
    lines = []
    for name, ok, detail in checks:
        mark = "OK" if ok else "DIKKAT"
        lines.append(f"[{mark:6}] {name}: {detail}")
    return "\n".join(lines)
