from __future__ import annotations

import json
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]
SYSTEM_DIR = APP_ROOT / "_sistem"
LOCATIONS_FILE = SYSTEM_DIR / "konumlar.json"
STATE_FILE = SYSTEM_DIR / "yedek_durumu.json"
LOCAL_BACKUP_ROOT = APP_ROOT / "_arsiv" / "kurtarma"


def _read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def backup_root() -> Path:
    """Return the preferred PC-side backup location.

    If it is unavailable, the SSD-local recovery area is used. A successful
    safety backup is mirrored to the SSD-local area as a second small copy.
    """
    locations = _read_json(LOCATIONS_FILE)
    value = str(locations.get("pc_backup_dir") or "").strip()
    if value:
        path = Path(value)
        try:
            path.mkdir(parents=True, exist_ok=True)
            return path
        except Exception:
            pass
    LOCAL_BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    return LOCAL_BACKUP_ROOT


def _critical_files() -> list[tuple[Path, str]]:
    files = [
        (APP_ROOT / "config" / "settings.json", "config/settings.json"),
        (APP_ROOT / "data" / "slides.csv", "data/slides.csv"),
        (APP_ROOT / "data" / "slides.pending.csv", "data/slides.pending.csv"),
        (SYSTEM_DIR / "guncelleme" / "version.json", "_sistem/guncelleme/version.json"),
        (SYSTEM_DIR / "konumlar.json", "_sistem/konumlar.json"),
        (APP_ROOT / "BURADAN_BASLAYIN.txt", "BURADAN_BASLAYIN.txt"),
    ]
    return [(src, rel) for src, rel in files if src.exists() and src.is_file()]


def _copy_backup(target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for source, rel in _critical_files():
        destination = target / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def _same_path(a: Path, b: Path) -> bool:
    try:
        return a.resolve() == b.resolve()
    except Exception:
        return str(a).casefold() == str(b).casefold()


def create_safety_backup(reason: str = "manual") -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    primary_root = backup_root()
    primary = primary_root / "otomatik" / stamp
    _copy_backup(primary)

    LOCAL_BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    local_copy = LOCAL_BACKUP_ROOT / "otomatik" / stamp
    mirrored = False
    if not _same_path(primary_root, LOCAL_BACKUP_ROOT):
        try:
            _copy_backup(local_copy)
            mirrored = True
        except Exception:
            mirrored = False

    state = _read_json(STATE_FILE)
    state.update(
        {
            "last_backup": datetime.now().isoformat(timespec="seconds"),
            "last_backup_path": str(primary),
            "last_backup_reason": reason,
            "last_backup_local_path": str(local_copy) if mirrored else str(primary),
            "last_backup_mirrored_to_ssd": mirrored,
        }
    )
    _write_json(STATE_FILE, state)
    _prune_backups(primary_root / "otomatik", keep=30)
    if not _same_path(primary_root, LOCAL_BACKUP_ROOT):
        _prune_backups(LOCAL_BACKUP_ROOT / "otomatik", keep=30)
    return primary


def _prune_backups(folder: Path, keep: int = 30) -> None:
    if not folder.exists():
        return
    dirs = sorted((p for p in folder.iterdir() if p.is_dir()), key=lambda p: p.name, reverse=True)
    for old in dirs[keep:]:
        shutil.rmtree(old, ignore_errors=True)


def backup_status() -> dict:
    state = _read_json(STATE_FILE)
    primary = backup_root()
    return {
        "last_backup": str(state.get("last_backup") or "Henuz yok"),
        "last_backup_path": str(state.get("last_backup_path") or ""),
        "last_backup_local_path": str(state.get("last_backup_local_path") or ""),
        "mirrored": bool(state.get("last_backup_mirrored_to_ssd")),
        "pc_backup_root": str(primary),
        "ssd_backup_root": str(LOCAL_BACKUP_ROOT),
        "last_recovery_zip": str(state.get("last_recovery_zip") or "Henuz yok"),
        "last_recovery_zip_path": str(state.get("last_recovery_zip_path") or ""),
    }


def maybe_daily_backup() -> Path | None:
    state = _read_json(STATE_FILE)
    today = datetime.now().date().isoformat()
    last = str(state.get("last_backup") or "")[:10]
    if last == today:
        return None
    try:
        return create_safety_backup("daily")
    except Exception:
        return None


def create_recovery_zip() -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = backup_root() / "kurtarma"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"PatolojiPratik_Kurtarma_{stamp}.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for source, rel in _critical_files():
            archive.write(source, rel)
        docs = APP_ROOT / "_belgeler"
        if docs.exists():
            for source in docs.rglob("*"):
                if source.is_file():
                    archive.write(source, str(Path("_belgeler") / source.relative_to(docs)))
        info = (
            "PATOLOJI PRATIK KURTARMA PAKETI\n"
            "\n"
            "Bu ZIP kaynak KFB/SVS dosyalarini ve GitHub tokenini ICERMEZ.\n"
            "Yeni kurulumda once program dosyalarini kurun, sonra config ve data\n"
            "dosyalarini ayni konumlara geri kopyalayin.\n"
            "\n"
            f"Olusturma: {datetime.now().isoformat(timespec='seconds')}\n"
            f"Kaynak sistem: {APP_ROOT}\n"
        )
        archive.writestr("KURTARMA_BILGISI.txt", info.encode("utf-8"))

    # Keep a second copy on the SSD-local recovery area when the primary target
    # is the PC backup directory.
    LOCAL_BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    local_folder = LOCAL_BACKUP_ROOT / "kurtarma"
    local_folder.mkdir(parents=True, exist_ok=True)
    if not _same_path(folder, local_folder):
        try:
            shutil.copy2(target, local_folder / target.name)
        except Exception:
            pass

    state = _read_json(STATE_FILE)
    state.update(
        {
            "last_recovery_zip": datetime.now().isoformat(timespec="seconds"),
            "last_recovery_zip_path": str(target),
        }
    )
    _write_json(STATE_FILE, state)
    return target
