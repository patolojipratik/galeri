from __future__ import annotations

"""Patoloji Pratik uygulama paketi.

Ana masaustu arayuzu baslatilirken tek bir idempotent bootstrap calisir:
- gorunen surumu _sistem/guncelleme/version.json ile esler,
- README korumasini, Baslik/Tani web gorunumunu ve viewer korumalarini kurar,
- modern gorunum ile Rehberler/Bakim ve sistem dugmelerini ekler,
- kurulan guncellemeyi uygun bilgisayarda GitHub kanalina esitlemeyi planlar.

Komut satiri araclari bu GUI bootstrap'ini otomatik olarak almaz.
"""

import json
import sys
from pathlib import Path

_GUI_BOOTSTRAPPED = False


def _running_main_gui() -> bool:
    try:
        return Path(sys.argv[0]).name.lower() == "baslat.py"
    except Exception:
        return False


def _sync_display_version() -> None:
    try:
        from . import config as _config

        root = Path(__file__).resolve().parents[1]
        version_file = root / "_sistem" / "guncelleme" / "version.json"
        if not version_file.exists():
            version_file = root / "version.json"
        if not version_file.exists():
            return
        raw = json.loads(version_file.read_text(encoding="utf-8"))
        label = str(raw.get("label") or raw.get("version") or "").strip()
        if label:
            _config.APP_VERSION = label
    except Exception:
        pass


def bootstrap_main_gui() -> None:
    """Install GUI helpers exactly once for the real desktop application."""
    global _GUI_BOOTSTRAPPED
    if _GUI_BOOTSTRAPPED:
        return
    _GUI_BOOTSTRAPPED = True

    _sync_display_version()

    try:
        from .gallery_readme_guard import install_gallery_readme_guard
        install_gallery_readme_guard()
    except Exception:
        pass
    try:
        from .gallery_display_guard import install_gallery_display_guard
        install_gallery_display_guard()
    except Exception:
        pass
    try:
        from .viewer_repair import install_viewer_html_guard
        install_viewer_html_guard()
    except Exception:
        pass
    try:
        from .ui_enhancer import install_ui_enhancer
        install_ui_enhancer()
    except Exception:
        pass


if _running_main_gui():
    bootstrap_main_gui()
