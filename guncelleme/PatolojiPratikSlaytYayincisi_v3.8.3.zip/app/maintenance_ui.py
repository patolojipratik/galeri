from __future__ import annotations

import subprocess
import threading
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import messagebox, ttk

APP_ROOT = Path(__file__).resolve().parents[1]


def _python() -> Path:
    candidate = APP_ROOT / ".venv" / "Scripts" / "python.exe"
    return candidate if candidate.exists() else Path(__import__("sys").executable)


def _run_tool(script: Path, *args: str) -> None:
    if not script.exists():
        raise RuntimeError(f"Araç bulunamadı: {script}")
    flags = subprocess.CREATE_NO_WINDOW if __import__("os").name == "nt" else 0
    subprocess.Popen([str(_python()), str(script), *args], cwd=str(APP_ROOT), creationflags=flags)


def _open_docs() -> None:
    local = APP_ROOT / "_belgeler" / "REHBERLER.md"
    if local.exists():
        try:
            __import__("os").startfile(str(local))
            return
        except Exception:
            pass
    webbrowser.open("https://github.com/patolojipratik/galeri/blob/main/REHBERLER.md")


class MaintenanceWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Patoloji Pratik - Bakım ve Sistem")
        self.geometry("900x690")
        self.minsize(780, 590)
        self.transient(parent)

        container = ttk.Frame(self, padding=18)
        container.pack(fill="both", expand=True)
        ttk.Label(container, text="Bakım ve Sistem", font=("Segoe UI", 17, "bold")).pack(anchor="w")
        ttk.Label(
            container,
            text="Konum, yedek, kurtarma, web, güncelleme ve sistem denetimleri. Günlük slayt işlemlerinden ayrıdır.",
        ).pack(anchor="w", pady=(4, 10))

        status = ttk.LabelFrame(container, text="Yedek ve günlük durumu", padding=10)
        status.pack(fill="x", pady=(0, 10))
        self.status_var = tk.StringVar(value="Durum okunuyor...")
        ttk.Label(status, textvariable=self.status_var).pack(side="left", fill="x", expand=True)
        ttk.Button(status, text="Şimdi yedekle", command=self.backup).pack(side="right", padx=(8, 0))
        ttk.Button(status, text="Yenile", command=self.refresh_status).pack(side="right")

        buttons = ttk.Frame(container)
        buttons.pack(fill="x")
        specs = [
            ("Sistem sağlık kontrolü", self.health),
            ("Konumlar ve ilk kurulum", self.locations),
            ("Kurtarma ZIP'i oluştur", self.recovery),
            ("Web görüntülerini kontrol et", self.web_check),
            ("Web görüntülerini onar", self.web_repair),
            ("Güncelleme kanalını eşitle", self.update_sync),
            ("Yerel temizlik önizleme", self.cleanup_preview),
            ("Kök klasörü sadeleştir", self.root_layout),
            ("Eski logları temizle", self.cleanup_logs),
            ("Rehberler", _open_docs),
        ]
        for i, (text, command) in enumerate(specs):
            ttk.Button(buttons, text=text, command=command).grid(row=i // 3, column=i % 3, padx=4, pady=4, sticky="ew")
        for i in range(3):
            buttons.columnconfigure(i, weight=1)

        ttk.Separator(container).pack(fill="x", pady=13)
        self.output = tk.Text(container, wrap="word", font=("Consolas", 9), padx=9, pady=9)
        self.output.pack(fill="both", expand=True)
        self._set(
            "Hazır. Sistem sağlık kontrolü ile genel durumu görebilir; yedek, kurtarma ve web işlemlerini buradan yönetebilirsiniz."
        )
        self.refresh_status()

    def _set(self, text: str) -> None:
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text)

    def _thread(self, func) -> None:
        self._set("Çalışıyor...")

        def worker():
            try:
                value = func()
                text = str(value)
            except Exception as exc:
                text = f"HATA: {type(exc).__name__}: {exc}"
            self.after(0, lambda: self._set(text))

        threading.Thread(target=worker, daemon=True).start()

    def refresh_status(self) -> None:
        try:
            from .backup_manager import backup_status
            from .log_manager import log_status

            b = backup_status()
            l = log_status()
            mirrored = " + SSD kopyası" if b.get("mirrored") else ""
            self.status_var.set(
                f"Son güvenlik yedeği: {b.get('last_backup', 'Henüz yok')}{mirrored}   |   "
                f"app.log: {l.get('app_log_size_text', '0 B')} (otomatik sınır {l.get('rotation_limit_text', '5 MB')})"
            )
        except Exception as exc:
            self.status_var.set(f"Durum okunamadı: {exc}")

    def health(self) -> None:
        from .system_health import format_checks, run_checks
        self._thread(lambda: format_checks(run_checks()))

    def locations(self) -> None:
        from .storage_manager import configure_locations
        value = configure_locations(self)
        self._set("Konumlar kaydedildi.\n\n" + "\n".join(f"{k}: {v}" for k, v in value.items()))
        self.refresh_status()

    def backup(self) -> None:
        from .backup_manager import create_safety_backup, backup_status
        try:
            path = create_safety_backup("manual")
            status = backup_status()
            extra = "\nAyrıca SSD içindeki _arsiv/kurtarma alanına küçük kopya alındı." if status.get("mirrored") else ""
            self._set(f"Güvenlik yedeği oluşturuldu:\n{path}{extra}\n\nKaynak KFB/SVS ve GitHub tokeni bu yedeğe alınmaz.")
            self.refresh_status()
        except Exception as exc:
            messagebox.showerror("Yedek hatası", str(exc), parent=self)

    def recovery(self) -> None:
        from .backup_manager import create_recovery_zip
        try:
            path = create_recovery_zip()
            self._set(
                f"Kurtarma ZIP'i oluşturuldu:\n{path}\n\n"
                "Token ve kaynak slaytlar bu ZIP'e alınmaz. Mümkünse ZIP'in bir kopyasını farklı fiziksel diskte saklayın."
            )
            self.refresh_status()
        except Exception as exc:
            messagebox.showerror("Kurtarma ZIP hatası", str(exc), parent=self)

    def web_check(self) -> None:
        from .viewer_repair import verify_all

        def work():
            lines = []
            result = verify_all(from_number=76, progress=lambda text: lines.append(str(text)))
            return "\n".join(lines + ["", str(result)])

        self._thread(work)

    def web_repair(self) -> None:
        try:
            from .viewer_repair import repair_in_background
            repair_in_background(self.parent, from_number=76)
            self._set("Web görüntüleyici onarımı arka planda başlatıldı.")
        except Exception as exc:
            messagebox.showerror("Web onarım hatası", str(exc), parent=self)

    def update_sync(self) -> None:
        script = APP_ROOT / "_sistem" / "araclar" / "guncelleme_kanalini_esitle.py"
        try:
            _run_tool(script)
            self._set("Güncelleme kanalı eşitleme aracı başlatıldı. Sonuç logs klasörüne yazılır.")
        except Exception as exc:
            messagebox.showerror("Güncelleme kanalı", str(exc), parent=self)

    def root_layout(self) -> None:
        try:
            from .root_layout_manager import migrate
            result = migrate(self)
            self._set(
                "Kök klasör düzeni uygulandı.\n\n"
                f"Taşınan: {len(result.get('moved', []))}\n"
                f"Taşınamayan: {len(result.get('left', []))}\n\n"
                "Bundan sonra kökte BASLAT.bat kullanın. Programı kapatıp yeniden açın."
            )
        except Exception as exc:
            messagebox.showerror("Kök klasör düzeni", str(exc), parent=self)

    def cleanup_preview(self) -> None:
        script = APP_ROOT / "_sistem" / "araclar" / "yerel_temizlik.py"
        try:
            result = subprocess.run(
                [str(_python()), str(script)],
                cwd=str(APP_ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=120,
            )
            self._set(result.stdout)
        except Exception as exc:
            messagebox.showerror("Temizlik önizleme", str(exc), parent=self)

    def cleanup_logs(self) -> None:
        try:
            from .log_manager import cleanup_old_logs, log_status, rotate_app_log
            before = log_status()
            # Rotating a currently-open Windows log may fail. That is safe; the
            # startup path will retry before the logger is opened next time.
            rotate_result = rotate_app_log()
            clean = cleanup_old_logs()
            after = log_status()
            self._set(
                f"Önce: app.log {before.get('app_log_size_text')}\n"
                f"Döndürme: {rotate_result.get('message')}\n"
                f"Temizlik: {clean.get('message')}\n"
                f"Şimdi: app.log {after.get('app_log_size_text')}\n\n"
                "Aktif app.log zorla silinmez. Açık olduğu için döndürülemediyse bir sonraki BASLAT sırasında otomatik denenir."
            )
            self.refresh_status()
        except Exception as exc:
            messagebox.showerror("Log temizliği", str(exc), parent=self)


def open_maintenance(parent) -> None:
    existing = getattr(parent, "_maintenance_window", None)
    try:
        if existing is not None and existing.winfo_exists():
            existing.lift()
            existing.focus_force()
            return
    except Exception:
        pass
    window = MaintenanceWindow(parent)
    parent._maintenance_window = window
