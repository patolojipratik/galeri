from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = APP_ROOT / "logs"
APP_LOG = LOG_DIR / "app.log"
DEFAULT_MAX_BYTES = 5 * 1024 * 1024
DEFAULT_KEEP = 3


def _size_text(value: int) -> str:
    units = ["B", "KB", "MB", "GB"]
    amount = float(max(0, value))
    for unit in units:
        if amount < 1024 or unit == units[-1]:
            return f"{amount:.1f} {unit}" if unit != "B" else f"{int(amount)} B"
        amount /= 1024
    return f"{value} B"


def rotate_app_log(max_bytes: int = DEFAULT_MAX_BYTES, keep: int = DEFAULT_KEEP) -> dict:
    """Rotate logs/app.log before the main application opens.

    The active app.log is never deleted. Rotation is best-effort: on Windows an
    already-open file may not be renameable, so failures are reported and the
    application is still allowed to start.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    result = {"rotated": False, "size": 0, "message": "app.log yok"}
    if not APP_LOG.exists():
        return result
    try:
        size = APP_LOG.stat().st_size
    except OSError as exc:
        result["message"] = f"app.log boyutu okunamadi: {exc}"
        return result
    result["size"] = size
    if size <= max_bytes:
        result["message"] = f"app.log {_size_text(size)}; sinir asilmadi"
        return result

    keep = max(1, int(keep))
    try:
        oldest = LOG_DIR / f"app.log.{keep}"
        oldest.unlink(missing_ok=True)
        for index in range(keep - 1, 0, -1):
            source = LOG_DIR / f"app.log.{index}"
            target = LOG_DIR / f"app.log.{index + 1}"
            if source.exists():
                source.replace(target)
        APP_LOG.replace(LOG_DIR / "app.log.1")
        result["rotated"] = True
        result["message"] = f"app.log {_size_text(size)} oldugu icin donduruldu; son {keep} eski log tutuluyor"
    except OSError as exc:
        result["message"] = f"app.log su anda dondurulemedi: {exc}. Bir sonraki baslangicta tekrar denenecek."
    return result


def cleanup_old_logs(keep_app_rotations: int = DEFAULT_KEEP, keep_days: int = 30) -> dict:
    """Remove stale log files but preserve the active app.log and startup.log."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    removed: list[str] = []
    bytes_removed = 0

    # First enforce the numbered app.log rotation count.
    for item in LOG_DIR.glob("app.log.*"):
        suffix = item.name.rsplit(".", 1)[-1]
        if suffix.isdigit() and int(suffix) > keep_app_rotations:
            try:
                bytes_removed += item.stat().st_size
                item.unlink()
                removed.append(item.name)
            except OSError:
                pass

    # Remove other old *.log files, except the live app/startup logs and update sync log.
    cutoff = datetime.now().timestamp() - max(1, int(keep_days)) * 86400
    protected = {"app.log", "startup.log", "update_channel_sync.log"}
    for item in LOG_DIR.glob("*.log"):
        if item.name in protected:
            continue
        try:
            if item.stat().st_mtime < cutoff:
                bytes_removed += item.stat().st_size
                item.unlink()
                removed.append(item.name)
        except OSError:
            pass

    return {
        "removed": removed,
        "bytes_removed": bytes_removed,
        "message": f"{len(removed)} eski log temizlendi, {_size_text(bytes_removed)} bosaltildi. Aktif app.log korunuyor.",
    }


def log_status() -> dict:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    current = APP_LOG.stat().st_size if APP_LOG.exists() else 0
    rotated = []
    for item in sorted(LOG_DIR.glob("app.log.*"), key=lambda p: p.name):
        if item.is_file():
            try:
                rotated.append((item.name, item.stat().st_size))
            except OSError:
                pass
    return {
        "app_log_size": current,
        "app_log_size_text": _size_text(current),
        "rotated": rotated,
        "rotation_limit_text": _size_text(DEFAULT_MAX_BYTES),
    }
