@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
set "REPAIR="

if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys" >nul 2>nul
  if not errorlevel 1 goto run
  set "REPAIR=--repair-venv"
)

echo Patoloji Pratik ilk kurulum kontrolu...
set "PYEXE="
set "PYARGS="
where py >nul 2>nul
if not errorlevel 1 (
  set "PYEXE=py"
  set "PYARGS=-3"
  goto setup
)
where python >nul 2>nul
if not errorlevel 1 (
  set "PYEXE=python"
  goto setup
)

echo.
echo Python 3.10 veya daha yeni bir surum bulunamadi.
where winget >nul 2>nul
if errorlevel 1 goto no_python
choice /C EH /N /M "Python 3.12 winget ile kurulsun mu? [E=Evet, H=Hayir]: "
if errorlevel 2 goto no_python
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto no_python
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
  set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  set "PYARGS="
) else (
  set "PYEXE=py"
  set "PYARGS=-3.12"
)

goto setup

:no_python
echo Python kurulumu tamamlanamadi.
echo https://www.python.org/downloads/windows/ adresinden Python 3.10+ kurun.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1

:setup
"%PYEXE%" %PYARGS% "_sistem\ilk_kurulum.py" --root "%ROOT%" %REPAIR%
if errorlevel 1 (
  echo.
  echo Ilk kurulum tamamlanamadi.
  pause
  exit /b 1
)

:run
rem Kok klasor sadelestirme burada otomatik yapilmaz.
rem Kullanici arayuzunde onay verildiginde guvenli olarak uygulanir.
".venv\Scripts\python.exe" "_sistem\guncelleme\guncelleme_bootstrap.py" --app-root "%ROOT%"
if errorlevel 1 (
  echo.
  echo Program baslatilamadi. Ayrinti: logs\updater.log
  pause
  exit /b 1
)
endlocal
