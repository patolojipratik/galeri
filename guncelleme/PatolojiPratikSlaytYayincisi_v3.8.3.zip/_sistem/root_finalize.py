from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SYSTEM = ROOT / "_sistem"
ARCHIVE = ROOT / "_arsiv"
DOCS = ROOT / "_belgeler"
STATE = SYSTEM / "kok_duzeni.json"
LOG = ROOT / "logs" / "kok_duzeni.log"

KEEP_FILES = {"BASLAT.bat", "BURADAN_BASLAYIN.txt", ".gitignore"}
KEEP_DIRS = {
    ".venv", "app", "config", "data", "github", "guncelleme", "logs", "repos", "work",
    "_sistem", "_belgeler", "_arsiv",
}
DOC_NAMES = {
    "AGENTS.md", "GUNCELLEME_SISTEMI_README.md", "HARICI_SSD_DEVAM_REHBERI.md",
    "KENDI_SISTEMINI_KUR.md", "KURULUM_GUNCELLEME_KURTARMA_REHBERI_TR.md",
    "YEREL_KLASOR_TEMIZLIK_REHBERI_TR.md", "YONETICI_REHBERI_TR.md",
}

def _log(text: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"{datetime.now().isoformat(timespec='seconds')} {text}\
")

def _unique_target(path: Path) -> Path:
    if not path.exists():
        return path
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return path.with_name(f"{path.stem}_{stamp}{path.suffix}")

def _move(source: Path, destination: Path) -> bool:
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination = _unique_target(destination)
        shutil.move(str(source), str(destination))
        _log(f"TASINDI {source.name} -> {destination}")
        return True
    except Exception as exc:
        _log(f"ATLANDI {source}: {type(exc).__name__}: {exc}")
        return False

def finalize() -> dict[str, list[str]]:
    SYSTEM.mkdir(parents=True, exist_ok=True)
    ARCHIVE.mkdir(parents=True, exist_ok=True)
    DOCS.mkdir(parents=True, exist_ok=True)
    moved: list[str] = []
    left: list[str] = []

    cache = ROOT / "__pycache__"
    if cache.exists():
        shutil.rmtree(cache, ignore_errors=True)

    public_release = ROOT / "public_release"
    if public_release.exists():
        if _move(public_release, ARCHIVE / "public_release"):
            moved.append("public_release")
        else:
            left.append("public_release")

    legacy = ARCHIVE / "kok_eski_dosyalar"
    releases = ARCHIVE / "gecmis_surumler"
    legacy.mkdir(parents=True, exist_ok=True)
    releases.mkdir(parents=True, exist_ok=True)

    for item in list(ROOT.iterdir()):
        if item.is_dir():
            if item.name in KEEP_DIRS:
                continue
            # Unknown top-level folders are never moved automatically.
            left.append(item.name)
            continue
        if item.name in KEEP_FILES:
            continue

        low = item.name.lower()
        # Keep a runnable copy of the current main script and requirements under _sistem.
        if low == "baslat.py":
            try:
                shutil.copy2(item, SYSTEM / "baslat.py")
            except Exception as exc:
                left.append(item.name); _log(f"KOPYA HATASI {item}: {exc}"); continue
        elif low == "requirements.txt":
            try:
                shutil.copy2(item, SYSTEM / "requirements.txt")
            except Exception:
                pass
        elif low == "version.json":
            try:
                target = SYSTEM / "guncelleme" / "version.json"
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target)
            except Exception:
                pass

        if item.name in DOC_NAMES:
            destination = DOCS / item.name
        elif low.startswith("surum_notlari_v") or low.startswith("test_raporu_v") or low.endswith("_v18.txt") or low.endswith("_v19.txt"):
            destination = releases / item.name
        else:
            destination = legacy / item.name

        if _move(item, destination):
            moved.append(item.name)
        else:
            left.append(item.name)

    state = {
        "done": not bool(left),
        "moved": moved,
        "left": left,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    STATE.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\
", encoding="utf-8")
    return state

if __name__ == "__main__":
    print(json.dumps(finalize(), ensure_ascii=False, indent=2))
