from __future__ import annotations

import argparse
import subprocess
import sys
import venv
import shutil
import os
from datetime import datetime
from pathlib import Path


def run(args: list[str]) -> None:
    subprocess.check_call(args)



def find_git() -> str:
    direct = shutil.which("git")
    if direct:
        return direct
    candidates = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Git" / "cmd" / "git.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Git" / "cmd" / "git.exe",
    ]
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    if local:
        candidates.extend(sorted(local.glob("GitHubDesktop/app-*/resources/app/git/cmd/git.exe"), reverse=True))
    for item in candidates:
        if item.exists():
            return str(item)
    return ""


def ensure_git() -> None:
    if find_git():
        return
    if os.name != "nt":
        return
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk(); root.withdraw()
        answer = messagebox.askyesno(
            "Patoloji Pratik - Git",
            "Git bulunamadi. GitHub yayinlari icin Git gereklidir.\n\nwinget ile Git kurulsun mu?",
            parent=root,
        )
        root.destroy()
    except Exception:
        answer = False
    if answer and shutil.which("winget"):
        subprocess.call([
            "winget", "install", "-e", "--id", "Git.Git",
            "--accept-package-agreements", "--accept-source-agreements",
        ])
        return
    try:
        os.startfile("https://git-scm.com/download/win")
    except Exception:
        pass

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--repair-venv", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if sys.version_info < (3, 10):
        raise SystemExit("Python 3.10 veya daha yeni surum gereklidir.")

    venv_dir = root / ".venv"
    if args.repair_venv and venv_dir.exists():
        archive = root / "_arsiv" / ("venv_eski_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        archive.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(venv_dir), str(archive))
    if not (venv_dir / "Scripts" / "python.exe").exists():
        print("Sanal Python ortami olusturuluyor...")
        venv.EnvBuilder(with_pip=True).create(venv_dir)

    python = venv_dir / "Scripts" / "python.exe"
    requirements = root / "_sistem" / "requirements.txt"
    if not requirements.exists():
        requirements = root / "requirements.txt"
    if requirements.exists():
        print("Bagimliliklar kontrol ediliyor...")
        run([str(python), "-m", "pip", "install", "-r", str(requirements)])

    sys.path.insert(0, str(root))
    try:
        from app.storage_manager import prepare_paths
        prepare_paths(root, interactive=True)
    except Exception as exc:
        print(f"Konum ayari daha sonra sorulacak: {exc}")
    ensure_git()
    print("Ilk kurulum hazir.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
