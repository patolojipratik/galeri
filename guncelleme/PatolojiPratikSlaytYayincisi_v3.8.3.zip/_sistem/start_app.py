from __future__ import annotations

import runpy
import sys
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "_sistem" / "baslat.py"
if not SCRIPT.exists():
    SCRIPT = ROOT / "baslat.py"


def main() -> int:
    log = ROOT / "logs" / "startup.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    old_argv0 = sys.argv[0]
    try:
        if not SCRIPT.exists():
            raise RuntimeError(f"Ana program bulunamadi: {SCRIPT}")

        # IMPORTANT: argv[0] must look like the real main GUI before importing
        # any app.* module. app/__init__.py uses it to install the version/UI
        # bootstrap. Older start_app imported app.log_manager first, so the app
        # package was cached as a non-GUI process; the visible program then kept
        # the legacy 3.6.5 title and did not receive the Rehberler/Bakim buttons.
        sys.argv[0] = str(SCRIPT)
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))

        try:
            import app
            bootstrap = getattr(app, "bootstrap_main_gui", None)
            if callable(bootstrap):
                bootstrap()
        except Exception:
            # The core application must still start if an optional UI helper
            # cannot be loaded.
            pass

        try:
            from app.log_manager import rotate_app_log
            rotate_app_log()
        except Exception:
            pass

        runpy.run_path(str(SCRIPT), run_name="__main__")
        return 0
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 0
        return int(code or 0)
    except Exception as exc:
        text = (
            f"{datetime.now().isoformat(timespec='seconds')}\n"
            f"{type(exc).__name__}: {exc}\n\n"
            + traceback.format_exc()
        )
        log.write_text(text, encoding="utf-8")
        try:
            import tkinter as tk
            from tkinter import messagebox
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(
                "Patoloji Pratik baslatma hatasi",
                f"Program acilirken hata olustu.\n\n{type(exc).__name__}: {exc}\n\nAyrinti: {log}",
                parent=root,
            )
            root.destroy()
        except Exception:
            pass
        return 1
    finally:
        sys.argv[0] = old_argv0


if __name__ == "__main__":
    raise SystemExit(main())
