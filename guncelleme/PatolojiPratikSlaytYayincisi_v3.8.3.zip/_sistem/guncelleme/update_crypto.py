from __future__ import annotations

"""Small, dependency-free Ed25519 helper used by the update system.

The implementation follows the public-domain reference formulas from RFC 8032.
Keys and signatures are encoded with URL-safe base64 without padding.
"""

import base64
import hashlib
import secrets
from pathlib import Path

_Q = 2**255 - 19
_L = 2**252 + 27742317777372353535851937790883648493
_D = (-121665 * pow(121666, _Q - 2, _Q)) % _Q
_I = pow(2, (_Q - 1) // 4, _Q)


def _b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64d(text: str) -> bytes:
    raw = text.strip().encode("ascii")
    raw += b"=" * ((4 - len(raw) % 4) % 4)
    return base64.urlsafe_b64decode(raw)


def _xrecover(y: int) -> int:
    xx = (y * y - 1) * pow(_D * y * y + 1, _Q - 2, _Q)
    x = pow(xx, (_Q + 3) // 8, _Q)
    if (x * x - xx) % _Q != 0:
        x = (x * _I) % _Q
    if x & 1:
        x = _Q - x
    return x


_BY = (4 * pow(5, _Q - 2, _Q)) % _Q
_BX = _xrecover(_BY)
_B = (_BX, _BY, 1, (_BX * _BY) % _Q)


def _edwards_add(p: tuple[int, int, int, int], q: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    x1, y1, z1, t1 = p
    x2, y2, z2, t2 = q
    a = ((y1 - x1) * (y2 - x2)) % _Q
    b = ((y1 + x1) * (y2 + x2)) % _Q
    c = (2 * _D * t1 * t2) % _Q
    d = (2 * z1 * z2) % _Q
    e = (b - a) % _Q
    f = (d - c) % _Q
    g = (d + c) % _Q
    h = (b + a) % _Q
    return (e * f % _Q, g * h % _Q, f * g % _Q, e * h % _Q)


def _scalarmult(p: tuple[int, int, int, int], n: int) -> tuple[int, int, int, int]:
    q = (0, 1, 1, 0)
    while n > 0:
        if n & 1:
            q = _edwards_add(q, p)
        p = _edwards_add(p, p)
        n >>= 1
    return q


def _encodepoint(p: tuple[int, int, int, int]) -> bytes:
    x, y, z, _t = p
    zi = pow(z, _Q - 2, _Q)
    x = x * zi % _Q
    y = y * zi % _Q
    value = y | ((x & 1) << 255)
    return value.to_bytes(32, "little")


def _is_on_curve(p: tuple[int, int, int, int]) -> bool:
    x, y, z, t = p
    return (
        (x * y - z * t) % _Q == 0
        and (y * y - x * x - z * z - _D * t * t) % _Q == 0
    )


def _decodepoint(data: bytes) -> tuple[int, int, int, int]:
    if len(data) != 32:
        raise ValueError("Ed25519 noktasi 32 bayt olmali")
    value = int.from_bytes(data, "little")
    y = value & ((1 << 255) - 1)
    if y >= _Q:
        raise ValueError("Gecersiz Ed25519 noktasi")
    x = _xrecover(y)
    if (x & 1) != (value >> 255):
        x = _Q - x
    p = (x, y, 1, x * y % _Q)
    if not _is_on_curve(p):
        raise ValueError("Nokta egri uzerinde degil")
    return p


def generate_keypair() -> tuple[str, str]:
    seed = secrets.token_bytes(32)
    return private_to_public(_b64e(seed)), _b64e(seed)


def private_to_public(private_key: str) -> str:
    seed = _b64d(private_key)
    if len(seed) != 32:
        raise ValueError("Ozel anahtar 32 bayt olmali")
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return _b64e(_encodepoint(_scalarmult(_B, a)))


def sign(message: bytes, private_key: str) -> str:
    seed = _b64d(private_key)
    if len(seed) != 32:
        raise ValueError("Ozel anahtar 32 bayt olmali")
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    prefix = h[32:]
    public = _b64d(private_to_public(private_key))
    r = int.from_bytes(hashlib.sha512(prefix + message).digest(), "little") % _L
    encoded_r = _encodepoint(_scalarmult(_B, r))
    k = int.from_bytes(hashlib.sha512(encoded_r + public + message).digest(), "little") % _L
    s = (r + k * a) % _L
    return _b64e(encoded_r + s.to_bytes(32, "little"))


def verify(message: bytes, signature: str, public_key: str) -> bool:
    try:
        sig = _b64d(signature)
        public = _b64d(public_key)
        if len(sig) != 64 or len(public) != 32:
            return False
        encoded_r = sig[:32]
        s = int.from_bytes(sig[32:], "little")
        if s >= _L:
            return False
        a_point = _decodepoint(public)
        r_point = _decodepoint(encoded_r)
        k = int.from_bytes(hashlib.sha512(encoded_r + public + message).digest(), "little") % _L
        left = _encodepoint(_scalarmult(_B, s))
        right = _encodepoint(_edwards_add(r_point, _scalarmult(a_point, k)))
        return secrets.compare_digest(left, right)
    except Exception:
        return False


def save_key(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value.strip() + "\n", encoding="ascii")


def load_key(path: Path) -> str:
    value = path.read_text(encoding="ascii").strip()
    if not value:
        raise ValueError(f"Anahtar bos: {path}")
    return value
