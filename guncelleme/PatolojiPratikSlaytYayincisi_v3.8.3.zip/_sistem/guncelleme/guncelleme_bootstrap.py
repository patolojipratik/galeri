from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--app-root", required=True)
    args = parser.parse_args()
    app_root = Path(args.app_root).resolve()

    try:
        sys.path.insert(0, str(app_root))
        from app.storage_manager import prepare_paths
        prepare_paths(app_root, interactive=True)
    except Exception as exc:
        logs = app_root / "logs"
        logs.mkdir(parents=True, exist_ok=True)
        with (logs / "updater.log").open("a", encoding="utf-8") as f:
            f.write(f"Konum kontrolu atlandi: {exc}\n")

    updater = HERE / "baslat_guncelleyici.py"
    if not updater.exists():
        print(f"Guncelleyici bulunamadi: {updater}")
        return 2

    temp_dir = Path(tempfile.mkdtemp(prefix="patoloji_pratik_updater_"))
    try:
        shutil.copy2(updater, temp_dir / updater.name)
        for name in ("update_crypto.py", "update_trusted_public.key"):
            source = HERE / name
            if source.exists():
                shutil.copy2(source, temp_dir / name)
        cmd = [sys.executable, str(temp_dir / updater.name), "--app-root", str(app_root)]
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        return subprocess.call(cmd, cwd=str(app_root), creationflags=creationflags)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
