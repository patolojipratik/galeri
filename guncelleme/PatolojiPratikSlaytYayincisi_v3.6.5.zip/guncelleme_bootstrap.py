from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent
UPDATER = APP_ROOT / "baslat_guncelleyici.py"


def main() -> int:
    if not UPDATER.exists():
        print(f"Guncelleyici bulunamadi: {UPDATER}")
        return 2
    temp_dir = Path(tempfile.mkdtemp(prefix="patoloji_pratik_updater_"))
    try:
        temp_updater = temp_dir / UPDATER.name
        shutil.copy2(UPDATER, temp_updater)
        for name in ("update_crypto.py", "update_trusted_public.key"):
            source = APP_ROOT / name
            if source.exists():
                shutil.copy2(source, temp_dir / name)
        cmd = [sys.executable, str(temp_updater), "--app-root", str(APP_ROOT)]
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        return subprocess.call(cmd, cwd=str(APP_ROOT), creationflags=creationflags)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
