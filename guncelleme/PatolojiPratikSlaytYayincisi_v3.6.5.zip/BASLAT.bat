@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Python ortami bulunamadi.
  echo Once KURULUM.bat veya GUNCELLE_VE_BASLAT.bat calistirin.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" guncelleme_bootstrap.py
if errorlevel 1 (
  echo.
  echo Program baslatilamadi. Ayrinti: logs\updater.log
  pause
  exit /b 1
)
endlocal
