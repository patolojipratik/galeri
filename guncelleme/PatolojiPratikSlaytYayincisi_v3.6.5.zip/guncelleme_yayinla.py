from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import tkinter as tk
from tkinter import filedialog, messagebox

from update_crypto import load_key, private_to_public, sign

APP_ROOT = Path(__file__).resolve().parent
MANAGED_START = "<!-- PATOLOJI-UPDATE-START -->"
MANAGED_END = "<!-- PATOLOJI-UPDATE-END -->"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON nesnesi bekleniyordu: {path}")
    return value


def settings() -> dict[str, Any]:
    path = APP_ROOT / "config" / "settings.json"
    return read_json(path) if path.exists() else {}


def token_for(username: str) -> str:
    try:
        sys.path.insert(0, str(APP_ROOT))
        from app.token_store import get_token  # type: ignore
        value = get_token(username)
        if value:
            return value.strip()
    except Exception:
        pass
    try:
        import keyring
        value = keyring.get_password("patoloji-pratik-github-yayinlama", username)
        if value:
            return value.strip()
    except Exception:
        pass
    raise RuntimeError("GitHub tokeni bulunamadi. Once GITHUB_BAGLA.bat calistirin.")


def find_git() -> str:
    direct = shutil.which("git")
    if direct:
        return direct
    candidates = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Git" / "cmd" / "git.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Git" / "cmd" / "git.exe",
    ]
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    if local:
        candidates.extend(sorted(local.glob("GitHubDesktop/app-*/resources/app/git/cmd/git.exe"), reverse=True))
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    raise RuntimeError("git.exe bulunamadi")


def git_env(username: str, token: str, askpass: Path) -> dict[str, str]:
    env = os.environ.copy()
    env.update(
        {
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_ASKPASS": str(askpass),
            "GITHUB_USERNAME": username,
            "GITHUB_TOKEN": token,
        }
    )
    return env


def run_git(args: list[str], cwd: Path, env: dict[str, str]) -> str:
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    result = subprocess.run(
        [find_git(), *args],
        cwd=str(cwd),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=flags,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} basarisiz:\n{result.stdout}")
    return result.stdout


def validate_package(path: Path) -> tuple[dict[str, Any], str]:
    if not path.exists() or path.suffix.lower() != ".zip":
        raise ValueError("Gecerli bir ZIP paketi secin")
    with zipfile.ZipFile(path) as archive:
        try:
            manifest = json.loads(archive.read("update-package.json").decode("utf-8"))
        except KeyError as exc:
            raise ValueError("ZIP icinde update-package.json yok") from exc
        if not isinstance(manifest, dict):
            raise ValueError("update-package.json gecersiz")
        files = manifest.get("files")
        if not isinstance(files, dict) or not files:
            raise ValueError("Paket dosya listesi eksik")
        for name, expected in files.items():
            try:
                data = archive.read(str(name))
            except KeyError as exc:
                raise ValueError(f"Pakette eksik dosya: {name}") from exc
            if hashlib.sha256(data).hexdigest() != str(expected).lower():
                raise ValueError(f"Paket ici SHA-256 hatasi: {name}")
        try:
            notes = archive.read("SURUM_NOTLARI.md").decode("utf-8")
        except KeyError:
            notes = f"# {manifest.get('label') or manifest.get('version')}\n\nGuncelleme paketi.\n"
    version = str(manifest.get("version") or "").strip()
    if not version:
        raise ValueError("Paket surumu eksik")
    return manifest, notes


def choose_zip() -> Path | None:
    root = tk.Tk()
    root.withdraw()
    value = filedialog.askopenfilename(
        title="Yayinlanacak Patoloji Pratik guncelleme ZIP'ini secin",
        initialdir=str(APP_ROOT / "guncelleme"),
        filetypes=[("ZIP paketi", "*.zip")],
    )
    root.destroy()
    return Path(value) if value else None


def update_readme(existing: str, version: str, package_name: str) -> str:
    section = (
        f"{MANAGED_START}\n"
        "## Güncel masaüstü sürümü\n\n"
        f"**{version}**\n\n"
        f"- [Güncelleme paketini indir](guncelleme/{package_name})\n"
        f"- [SHA-256](guncelleme/{package_name}.sha256.txt)\n"
        "- [Sürüm notları](guncelleme/SURUM_NOTLARI.md)\n"
        "- [Harici SSD ile devam etme](HARICI_SSD_DEVAM_REHBERI.md)\n"
        "- [Kendi sistemine uyarlama](KENDI_SISTEMINI_KUR.md)\n\n"
        "Güncelleme ZIP'i kullanıcı verisi, GitHub tokeni, kaynak KFB/SVS dosyaları, "
        "`slides.csv`, `config`, `repos`, `work`, `logs` veya `.venv` içermez.\n"
        f"{MANAGED_END}"
    )
    pattern = re.compile(re.escape(MANAGED_START) + r".*?" + re.escape(MANAGED_END), re.DOTALL)
    if pattern.search(existing):
        return pattern.sub(section, existing)
    return existing.rstrip() + "\n\n" + section + "\n"


def publish(package: Path) -> str:
    manifest, notes = validate_package(package)
    version = str(manifest["version"])
    config = settings()
    username = str(config.get("github_username") or "patolojipratik").strip()
    repo = str(config.get("gallery_repo") or "galeri").strip()
    token = token_for(username)

    private_path = APP_ROOT / "config" / "update_signing_private.key"
    public_path = APP_ROOT / "update_trusted_public.key"
    if not private_path.exists():
        raise RuntimeError(
            "Guncelleme imzalama anahtari bulunamadi. "
            "Yayinlayici anahtar paketini bu bilgisayara kurun."
        )
    private = load_key(private_path)
    trusted = load_key(public_path)
    if private_to_public(private) != trusted:
        raise RuntimeError("Ozel imzalama anahtari bu kurulumun guvenilir acik anahtariyla eslesmiyor")

    digest = sha256(package)
    signature = sign(digest.encode("ascii"), private)
    release = {
        "schema": 1,
        "version": version,
        "title": str(manifest.get("label") or version),
        "package": package.name,
        "sha256": digest,
        "signature": signature,
        "release_notes": "SURUM_NOTLARI.md",
        "mandatory": bool(manifest.get("mandatory", False)),
        "published_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }

    temp_root = Path(tempfile.mkdtemp(prefix="patoloji_pratik_publish_"))
    try:
        askpass = temp_root / ("askpass.cmd" if os.name == "nt" else "askpass.sh")
        if os.name == "nt":
            askpass.write_text(
                "@echo off\n"
                "echo %~1 | findstr /I \"Username\" >nul\n"
                "if not errorlevel 1 (echo %GITHUB_USERNAME%) else (echo %GITHUB_TOKEN%)\n",
                encoding="utf-8",
            )
        else:
            askpass.write_text(
                "#!/bin/sh\ncase \"$1\" in *Username*) echo \"$GITHUB_USERNAME\";; *) echo \"$GITHUB_TOKEN\";; esac\n",
                encoding="utf-8",
            )
            askpass.chmod(0o700)
        env = git_env(username, token, askpass)
        repo_dir = temp_root / "galeri"
        remote = f"https://github.com/{username}/{repo}.git"
        run_git(["clone", "--depth=1", "--branch", "main", remote, str(repo_dir)], temp_root, env)

        update_dir = repo_dir / "guncelleme"
        update_dir.mkdir(parents=True, exist_ok=True)
        for old in update_dir.glob("*.zip"):
            if old.name != package.name:
                old.unlink(missing_ok=True)
        for old in update_dir.glob("*.zip.sha256.txt"):
            if old.name != package.name + ".sha256.txt":
                old.unlink(missing_ok=True)
        shutil.copy2(package, update_dir / package.name)
        (update_dir / (package.name + ".sha256.txt")).write_text(
            f"{digest}  {package.name}\n", encoding="ascii"
        )
        (update_dir / (package.name + ".sig")).write_text(signature + "\n", encoding="ascii")
        (update_dir / "latest.json").write_text(
            json.dumps(release, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        (update_dir / "SURUM_NOTLARI.md").write_text(notes, encoding="utf-8")

        for doc in ("HARICI_SSD_DEVAM_REHBERI.md", "KENDI_SISTEMINI_KUR.md"):
            source = APP_ROOT / doc
            if source.exists():
                shutil.copy2(source, repo_dir / doc)
        readme = repo_dir / "README.md"
        existing = readme.read_text(encoding="utf-8") if readme.exists() else "# Patoloji Pratik Slaytları\n"
        readme.write_text(update_readme(existing, version, package.name), encoding="utf-8")

        run_git(["add", "README.md", "HARICI_SSD_DEVAM_REHBERI.md", "KENDI_SISTEMINI_KUR.md", "guncelleme"], repo_dir, env)
        status = run_git(["status", "--porcelain"], repo_dir, env).strip()
        if not status:
            return "GitHub'daki guncelleme zaten ayni surumde."
        run_git(["config", "user.name", str(config.get("commit_name") or "Patoloji Pratik")], repo_dir, env)
        email = str(config.get("commit_email") or f"{username}@users.noreply.github.com")
        run_git(["config", "user.email", email], repo_dir, env)
        run_git(["commit", "-m", f"Guncelleme {version} yayinlandi"], repo_dir, env)
        run_git(["push", "origin", "main"], repo_dir, env)
        return f"Guncelleme yayinlandi: {username}/{repo}/guncelleme/{package.name}"
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", nargs="?")
    args = parser.parse_args()
    package = Path(args.package).resolve() if args.package else choose_zip()
    if package is None:
        return 0
    try:
        result = publish(package)
        print(result)
        if os.name == "nt":
            root = tk.Tk(); root.withdraw(); messagebox.showinfo("Guncelleme yayini", result); root.destroy()
        return 0
    except Exception as exc:
        print(f"HATA: {exc}")
        if os.name == "nt":
            root = tk.Tk(); root.withdraw(); messagebox.showerror("Guncelleme yayini hatasi", str(exc)); root.destroy()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
