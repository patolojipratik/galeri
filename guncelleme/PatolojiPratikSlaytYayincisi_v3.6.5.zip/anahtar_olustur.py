from __future__ import annotations

import argparse
from pathlib import Path
from update_crypto import generate_keypair, save_key


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    private_path = root / "config" / "update_signing_private.key"
    public_path = root / "update_trusted_public.key"
    if (private_path.exists() or public_path.exists()) and not args.force:
        print("Anahtar zaten var. Degistirmek mevcut kullanicilarin yeni guncellemeleri reddetmesine yol acar.")
        print("Gercekten yeni ve bagimsiz bir sistem kuruyorsaniz --force kullanin.")
        return 2
    public, private = generate_keypair()
    save_key(private_path, private)
    save_key(public_path, public)
    save_key(root / "config" / "update_signing_public.key", public)
    print("Yeni guncelleme imzalama anahtari olusturuldu.")
    print(f"OZEL ANAHTARI YEDEKLEYIN: {private_path}")
    print("Bu dosyayi GitHub'a veya kullanicilara vermeyin.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
