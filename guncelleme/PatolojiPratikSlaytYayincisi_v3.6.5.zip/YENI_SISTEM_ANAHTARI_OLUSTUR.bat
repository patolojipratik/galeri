@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Python ortami bulunamadi.
  pause
  exit /b 1
)
echo Bu islem yalnizca YENI ve BAGIMSIZ bir sistem kurarken kullanilir.
echo Mevcut Patoloji Pratik sisteminde anahtari degistirmeyin.
choice /M "Yeni anahtar olusturulsun mu"
if errorlevel 2 exit /b 0
".venv\Scripts\python.exe" anahtar_olustur.py --force
pause
endlocal
