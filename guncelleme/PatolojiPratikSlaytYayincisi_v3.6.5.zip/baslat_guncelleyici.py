from __future__ import annotations

import argparse
import compileall
import py_compile
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from update_crypto import load_key, verify

UPDATER_VERSION = "1.0.0"
MAX_PACKAGE_BYTES = 250 * 1024 * 1024
PROTECTED_PREFIXES = (
    "config/",
    "data/",
    "repos/",
    "work/",
    "logs/",
    ".venv/",
    "guncelleme/yedek/",
    "guncelleme/uygulandi/",
)
PROTECTED_EXACT = {
    "baslat.bat",
    "update_trusted_public.key",
    "config/settings.json",
    "data/slides.csv",
    "data/slides.pending.csv",
}


@dataclass(frozen=True)
class Candidate:
    version: str
    label: str
    package_url: str | None
    package_path: Path | None
    sha256: str | None
    signature: str | None
    notes_url: str | None
    mandatory: bool


def _version_tuple(value: str) -> tuple[int, ...]:
    numbers = [int(x) for x in re.findall(r"\d+", str(value))]
    return tuple(numbers or [0])


def _safe_rel(name: str) -> str:
    normalized = name.replace("\\", "/").lstrip("/")
    path = PurePosixPath(normalized)
    if not normalized or path.is_absolute() or ".." in path.parts:
        raise ValueError(f"Gecersiz paket yolu: {name!r}")
    if any(part in {"", "."} for part in path.parts):
        raise ValueError(f"Gecersiz paket yolu: {name!r}")
    return path.as_posix()


def _is_protected(rel: str) -> bool:
    low = rel.lower()
    return low in PROTECTED_EXACT or any(low.startswith(prefix) for prefix in PROTECTED_PREFIXES)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_read(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON nesnesi bekleniyordu: {path}")
    return value


def _remote_json(url: str, timeout: float = 8.0) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": f"PatolojiPratik-Updater/{UPDATER_VERSION}"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}")
        payload = response.read(2 * 1024 * 1024)
    value = json.loads(payload.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("latest.json bir JSON nesnesi olmali")
    return value


def _download(url: str, target: Path, expected_sha: str | None) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(target.suffix + ".part")
    request = urllib.request.Request(
        url,
        headers={"User-Agent": f"PatolojiPratik-Updater/{UPDATER_VERSION}"},
    )
    digest = hashlib.sha256()
    total = 0
    try:
        with urllib.request.urlopen(request, timeout=30) as response, temp.open("wb") as handle:
            if response.status != 200:
                raise RuntimeError(f"HTTP {response.status}")
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_PACKAGE_BYTES:
                    raise RuntimeError("Guncelleme paketi izin verilen boyutu asti")
                digest.update(chunk)
                handle.write(chunk)
        actual = digest.hexdigest()
        if expected_sha and actual.lower() != expected_sha.lower():
            raise RuntimeError("Indirilen ZIP SHA-256 dogrulamasi basarisiz")
        temp.replace(target)
    finally:
        temp.unlink(missing_ok=True)


def _load_local_version(app_root: Path) -> str:
    version_file = app_root / "version.json"
    if version_file.exists():
        try:
            return str(_json_read(version_file).get("version") or "0")
        except Exception:
            pass
    config_file = app_root / "app" / "config.py"
    if config_file.exists():
        match = re.search(
            r'^APP_VERSION\s*=\s*["\']([^"\']+)["\']',
            config_file.read_text(encoding="utf-8", errors="replace"),
            flags=re.MULTILINE,
        )
        if match:
            return match.group(1)
    return "0"


def _settings(app_root: Path) -> dict[str, Any]:
    path = app_root / "config" / "settings.json"
    if not path.exists():
        return {}
    try:
        return _json_read(path)
    except Exception:
        return {}


def _manifest_url(app_root: Path) -> str:
    settings = _settings(app_root)
    configured = str(settings.get("update_manifest_url") or "").strip()
    if configured:
        return configured
    username = str(settings.get("github_username") or "patolojipratik").strip()
    repo = str(settings.get("gallery_repo") or "galeri").strip()
    return f"https://raw.githubusercontent.com/{username}/{repo}/main/guncelleme/latest.json"


def _candidate_from_remote(app_root: Path) -> Candidate | None:
    url = _manifest_url(app_root)
    data = _remote_json(url)
    version = str(data.get("version") or "").strip()
    package = str(data.get("package") or "").strip()
    if not version or not package:
        raise ValueError("latest.json icinde version ve package zorunludur")
    package_url = urllib.parse.urljoin(url, package)
    notes = str(data.get("release_notes") or "").strip()
    return Candidate(
        version=version,
        label=str(data.get("title") or version),
        package_url=package_url,
        package_path=None,
        sha256=str(data.get("sha256") or "").strip() or None,
        signature=str(data.get("signature") or "").strip() or None,
        notes_url=urllib.parse.urljoin(url, notes) if notes else None,
        mandatory=bool(data.get("mandatory", False)),
    )


def _read_package_manifest(zip_path: Path) -> dict[str, Any]:
    with zipfile.ZipFile(zip_path) as archive:
        try:
            raw = archive.read("update-package.json")
        except KeyError as exc:
            raise ValueError("ZIP icinde update-package.json bulunamadi") from exc
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("update-package.json bir JSON nesnesi olmali")
    return value


def _candidate_from_local(path: Path) -> Candidate:
    manifest = _read_package_manifest(path)
    version = str(manifest.get("version") or "").strip()
    if not version:
        raise ValueError("Yerel pakette surum bilgisi yok")
    release_sidecar = path.with_suffix(path.suffix + ".release.json")
    release = _json_read(release_sidecar) if release_sidecar.exists() else {}
    sha_value = str(release.get("sha256") or "").strip() or None
    signature = str(release.get("signature") or "").strip() or None
    sha_sidecar = path.with_name(path.name + ".sha256.txt")
    sig_sidecar = path.with_name(path.name + ".sig")
    if not sha_value and sha_sidecar.exists():
        parts = sha_sidecar.read_text(encoding="ascii", errors="replace").split()
        if parts:
            sha_value = parts[0].strip()
    if not signature and sig_sidecar.exists():
        signature = sig_sidecar.read_text(encoding="ascii", errors="replace").strip() or None
    return Candidate(
        version=version,
        label=str(manifest.get("label") or version),
        package_url=None,
        package_path=path,
        sha256=sha_value,
        signature=signature,
        notes_url=None,
        mandatory=False,
    )


def _discover_local(app_root: Path) -> Candidate | None:
    folder = app_root / "guncelleme"
    folder.mkdir(parents=True, exist_ok=True)
    candidates: list[Candidate] = []
    for path in folder.glob("*.zip"):
        try:
            candidates.append(_candidate_from_local(path))
        except Exception:
            continue
    return max(candidates, key=lambda item: _version_tuple(item.version), default=None)


def _verify_release(zip_path: Path, candidate: Candidate, app_root: Path) -> None:
    actual_sha = _sha256(zip_path)
    if candidate.sha256 and actual_sha.lower() != candidate.sha256.lower():
        raise RuntimeError("Guncelleme ZIP SHA-256 degeri uyusmuyor")
    if not candidate.signature:
        raise RuntimeError(
            "Guncelleme dijital imzasi bulunamadi. ZIP ile birlikte .sig ve "
            ".sha256.txt dosyalarini indirin veya cevrimici guncelleme secenegini kullanin."
        )
    key_path = app_root / "update_trusted_public.key"
    if not key_path.exists():
        raise RuntimeError("Guvenilir guncelleme acik anahtari bulunamadi")
    if not verify(actual_sha.encode("ascii"), candidate.signature, load_key(key_path)):
        raise RuntimeError("Guncelleme dijital imzasi gecersiz")


def _validate_zip(zip_path: Path) -> tuple[dict[str, Any], list[str]]:
    manifest = _read_package_manifest(zip_path)
    files = manifest.get("files")
    if not isinstance(files, dict) or not files:
        raise ValueError("Paket dosya listesi eksik")
    normalized_files: dict[str, str] = {}
    for raw_name, raw_digest in files.items():
        rel = _safe_rel(str(raw_name))
        if _is_protected(rel):
            raise ValueError(f"Paket kullanici verisine dokunmaya calisiyor: {rel}")
        digest = str(raw_digest).lower().strip()
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError(f"Gecersiz dosya ozeti: {rel}")
        normalized_files[rel] = digest

    delete_list: list[str] = []
    for raw_name in manifest.get("delete", []) or []:
        rel = _safe_rel(str(raw_name))
        if _is_protected(rel):
            raise ValueError(f"Paket korunan dosyayi silmeye calisiyor: {rel}")
        delete_list.append(rel)

    with zipfile.ZipFile(zip_path) as archive:
        total = 0
        seen: set[str] = set()
        for info in archive.infolist():
            if info.is_dir():
                continue
            rel = _safe_rel(info.filename)
            total += info.file_size
            if total > MAX_PACKAGE_BYTES:
                raise RuntimeError("Acildiginda paket izin verilen boyutu asiyor")
            if rel == "update-package.json":
                continue
            if rel not in normalized_files:
                raise ValueError(f"Manifestte olmayan dosya: {rel}")
            digest = hashlib.sha256(archive.read(info)).hexdigest()
            if digest != normalized_files[rel]:
                raise RuntimeError(f"Paket ici dosya dogrulamasi basarisiz: {rel}")
            seen.add(rel)
        missing = set(normalized_files) - seen
        if missing:
            raise ValueError(f"Pakette eksik dosya: {sorted(missing)[0]}")
    manifest["files"] = normalized_files
    return manifest, delete_list


def _backup_paths(app_root: Path, rel_paths: list[str], delete_list: list[str]) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = app_root / "guncelleme" / "yedek" / stamp
    backup.mkdir(parents=True, exist_ok=True)
    for rel in sorted(set(rel_paths + delete_list)):
        source = app_root / Path(rel)
        if source.exists() and source.is_file():
            target = backup / Path(rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    slides = app_root / "data" / "slides.csv"
    if slides.exists():
        target = backup / "_kullanici_verisi" / "slides.csv"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(slides, target)
    return backup


def _restore_backup(app_root: Path, backup: Path, rel_paths: list[str], delete_list: list[str]) -> None:
    for rel in sorted(set(rel_paths + delete_list), reverse=True):
        target = app_root / Path(rel)
        saved = backup / Path(rel)
        if saved.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved, target)
        elif target.exists() and target.is_file():
            target.unlink(missing_ok=True)


def _install(zip_path: Path, candidate: Candidate, app_root: Path, log) -> None:
    _verify_release(zip_path, candidate, app_root)
    manifest, delete_list = _validate_zip(zip_path)
    files = list(manifest["files"])
    stage_root = Path(tempfile.mkdtemp(prefix="patoloji_pratik_stage_"))
    try:
        with zipfile.ZipFile(zip_path) as archive:
            for rel in files:
                target = stage_root / Path(rel)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(rel))
        if not compileall.compile_dir(str(stage_root), quiet=1, force=True):
            raise RuntimeError("Guncelleme Python dogrulamasi basarisiz")

        backup = _backup_paths(app_root, files, delete_list)
        log(f"Yedek olusturuldu: {backup}")
        try:
            for rel in files:
                source = stage_root / Path(rel)
                target = app_root / Path(rel)
                target.parent.mkdir(parents=True, exist_ok=True)
                temp_target = target.with_name(target.name + ".new")
                shutil.copy2(source, temp_target)
                os.replace(temp_target, target)
            for rel in delete_list:
                target = app_root / Path(rel)
                if target.is_file():
                    target.unlink(missing_ok=True)
            for rel in files:
                if rel.lower().endswith(".py"):
                    py_compile.compile(str(app_root / Path(rel)), doraise=True)
            version = str(manifest.get("version") or candidate.version)
            (app_root / "version.json").write_text(
                json.dumps(
                    {"version": version, "label": manifest.get("label", version), "updater_version": UPDATER_VERSION},
                    ensure_ascii=False,
                    indent=2,
                ) + "\n",
                encoding="utf-8",
            )
            applied = app_root / "guncelleme" / "uygulandi"
            applied.mkdir(parents=True, exist_ok=True)
            if zip_path.parent == app_root / "guncelleme":
                destination = applied / zip_path.name
                if destination.exists():
                    destination.unlink()
                shutil.move(str(zip_path), destination)
            log(f"Guncelleme uygulandi: {version}")
        except Exception:
            _restore_backup(app_root, backup, files, delete_list)
            raise
    finally:
        shutil.rmtree(stage_root, ignore_errors=True)


def _start_main(app_root: Path) -> None:
    pythonw = app_root / ".venv" / "Scripts" / "pythonw.exe"
    python = pythonw if pythonw.exists() else Path(sys.executable)
    script = app_root / "baslat.py"
    if not script.exists():
        raise RuntimeError(f"Ana program bulunamadi: {script}")
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    subprocess.Popen([str(python), str(script)], cwd=str(app_root), creationflags=creationflags)


class UpdateDialog:
    def __init__(self, root: tk.Tk, current: str, candidate: Candidate):
        self.root = root
        self.result = "continue"
        root.title("Patoloji Pratik - Guncelleme")
        root.resizable(False, False)
        frame = ttk.Frame(root, padding=20)
        frame.grid()
        ttk.Label(frame, text="Yeni surum bulundu", font=("Segoe UI", 14, "bold")).grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(frame, text=f"Mevcut: {current}\nYeni: {candidate.label}", justify="left").grid(row=1, column=0, columnspan=2, sticky="w", pady=(8, 16))
        ttk.Button(frame, text="Guncellemeyi indir ve kur", command=lambda: self._finish("install"), width=33).grid(row=2, column=0, columnspan=2, sticky="ew", pady=3)
        ttk.Button(frame, text="Bilgisayarimdaki ZIP dosyasini sec", command=lambda: self._finish("select"), width=33).grid(row=3, column=0, columnspan=2, sticky="ew", pady=3)
        notes = ttk.Button(frame, text="Surum notlarini ac", command=lambda: self._finish("notes"), width=33)
        notes.grid(row=4, column=0, columnspan=2, sticky="ew", pady=3)
        if not candidate.notes_url:
            notes.state(["disabled"])
        ttk.Button(frame, text="Simdilik mevcut surumle devam et", command=lambda: self._finish("continue"), width=33).grid(row=5, column=0, columnspan=2, sticky="ew", pady=(12, 3))
        if candidate.mandatory:
            root.protocol("WM_DELETE_WINDOW", lambda: None)
        else:
            root.protocol("WM_DELETE_WINDOW", lambda: self._finish("continue"))
        root.update_idletasks()
        x = (root.winfo_screenwidth() - root.winfo_reqwidth()) // 2
        y = (root.winfo_screenheight() - root.winfo_reqheight()) // 2
        root.geometry(f"+{x}+{y}")

    def _finish(self, value: str) -> None:
        self.result = value
        self.root.destroy()


def _choose_action(current: str, candidate: Candidate) -> str:
    root = tk.Tk()
    dialog = UpdateDialog(root, current, candidate)
    root.mainloop()
    return dialog.result


def _select_zip(initial: Path) -> Path | None:
    root = tk.Tk()
    root.withdraw()
    filename = filedialog.askopenfilename(
        title="Patoloji Pratik guncelleme ZIP dosyasini secin",
        initialdir=str(initial),
        filetypes=[("ZIP paketi", "*.zip")],
    )
    root.destroy()
    return Path(filename) if filename else None


def _show_error(text: str) -> None:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror("Patoloji Pratik - Guncelleme hatasi", text)
    root.destroy()


def _open_url(url: str) -> None:
    import webbrowser
    webbrowser.open(url)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--app-root", required=True)
    args = parser.parse_args()
    app_root = Path(args.app_root).resolve()
    logs = app_root / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    log_path = logs / "updater.log"

    def log(message: str) -> None:
        line = f"{datetime.now().isoformat(timespec='seconds')} {message}"
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")

    try:
        current = _load_local_version(app_root)
        local = _discover_local(app_root)
        remote: Candidate | None = None
        try:
            remote = _candidate_from_remote(app_root)
        except (urllib.error.URLError, TimeoutError, OSError, ValueError, RuntimeError) as exc:
            log(f"Cevrimici guncelleme kontrolu atlandi: {exc}")

        available = [item for item in (local, remote) if item and _version_tuple(item.version) > _version_tuple(current)]
        candidate = max(available, key=lambda item: _version_tuple(item.version), default=None)
        if candidate is None:
            _start_main(app_root)
            return 0

        while True:
            action = _choose_action(current, candidate)
            if action == "continue":
                _start_main(app_root)
                return 0
            if action == "notes" and candidate.notes_url:
                _open_url(candidate.notes_url)
                continue
            if action == "select":
                chosen = _select_zip(app_root / "guncelleme")
                if not chosen:
                    continue
                local_candidate = _candidate_from_local(chosen)
                # GitHub'dan elle indirilen ZIP'in yaninda sidecar dosyasi olmayabilir.
                # Ayni surum uzakta ilan edilmisse SHA ve imzayi guvenilir latest.json'dan al.
                trusted_release = remote if remote and remote.version == local_candidate.version else None
                candidate = Candidate(
                    version=local_candidate.version,
                    label=local_candidate.label,
                    package_url=None,
                    package_path=chosen,
                    sha256=(trusted_release.sha256 if trusted_release else local_candidate.sha256),
                    signature=(trusted_release.signature if trusted_release else local_candidate.signature),
                    notes_url=(trusted_release.notes_url if trusted_release else None),
                    mandatory=False,
                )
            zip_path = candidate.package_path
            if zip_path is None:
                filename = Path(urllib.parse.urlparse(candidate.package_url or "update.zip").path).name or "update.zip"
                zip_path = app_root / "guncelleme" / filename
                _download(candidate.package_url or "", zip_path, candidate.sha256)
            _install(zip_path, candidate, app_root, log)
            _start_main(app_root)
            return 0
    except Exception as exc:
        log(f"HATA: {type(exc).__name__}: {exc}")
        _show_error(f"Guncelleme uygulanamadi. Eski dosyalar korundu.\n\n{exc}\n\nAyrinti: {log_path}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
