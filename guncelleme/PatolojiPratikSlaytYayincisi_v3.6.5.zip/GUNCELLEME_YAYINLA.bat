@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Python ortami bulunamadi. Once KURULUM.bat calistirin.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" guncelleme_yayinla.py %*
if errorlevel 1 pause
endlocal
