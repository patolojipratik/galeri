# Güvenli güncelleme sistemi

Bu paket Patoloji Pratik Slayt Yayıncısı'na kullanıcı dostu güncelleme kontrolü ekler.

## İlk kurulum

Bu sürüm bir kez doğrudan `E:\github` üzerine çıkarılır. Sonraki sürümlerde yalnızca `BASLAT.bat` kullanılır.

## Güncelleme deposu

Ana galeri reposunda:

```text
guncelleme/
  latest.json
  PatolojiPratikSlaytYayincisi_vX.Y.Z.zip
  PatolojiPratikSlaytYayincisi_vX.Y.Z.zip.sha256.txt
  PatolojiPratikSlaytYayincisi_vX.Y.Z.zip.sig
  SURUM_NOTLARI.md
```

bulunur.

## Güvenlik

- ZIP SHA-256 ile doğrulanır.
- SHA-256 değeri Ed25519 dijital imzasıyla doğrulanır.
- İmza doğrulanmadan çevrimiçi paket kurulmaz.
- Paket içindeki her dosya ayrıca SHA-256 ile doğrulanır.
- Yol geçişi ve ZIP bombası denetimi yapılır.
- Kullanıcı verisi klasörlerini içeren paket reddedilir.
- Değişecek dosyalar yedeklenir; hata halinde geri alınır.
- Python dosyaları kurulumdan önce ve sonra derlenerek denetlenir.

## Güncelleme yayımlayıcısı

`GUNCELLEME_YAYINLA.bat`, yalnızca özel imzalama anahtarı bulunan bakım bilgisayarında kullanılmalıdır. Harici SSD'yi kullanan normal kullanıcı bu aracı çalıştırmaz.
