# patolojipratik/galeri repo temizlik önerisi

Bu dosya bakım notudur; GitHub'a yüklenmesi zorunlu değildir.

## Kesinlikle kalsın

```text
README.md
index.html
slides.json
.nojekyll
thumbs/
guncelleme/
HARICI_SSD_DEVAM_REHBERI.md
KENDI_SISTEMINI_KUR.md
YONETICI_REHBERI_TR.md
AGENTS.md
```

## Eski yapıda gereksiz / kafa karıştırıcı hale gelenler

### `surum.json` (repo kökü)

Yeni güncelleme sistemi `guncelleme/latest.json` kullanıyor. Kök `surum.json` içinde indirme ve SHA alanları boşsa eski kalıntıdır. Yeni README ve v3.6.7 güncelleme kanalı doğrulandıktan sonra silinmesi önerilir.

### `SURUM_NOTLARI.md` (repo kökü)

Güncel sürüm notlarının kanonik adresi `guncelleme/SURUM_NOTLARI.md` olduğundan kökteki ikinci sürüm notu kopyası gereksizdir. Yeni README yayınlandıktan sonra silinmesi önerilir.

### `indir/`

Yeni güncelleme kanalı `guncelleme/` klasörüdür. `indir/` altında eski uygulama ZIP'leri varsa ve README/başka bir dosya artık onlara bağlantı vermiyorsa klasör kaldırılabilir. Git boş klasör tutmaz; klasör görünmüyorsa ayrıca işlem gerekmez.

## Silmeyin

```text
index.html
slides.json
thumbs/
.nojekyll
guncelleme/latest.json
guncelleme içindeki güncel ZIP / SHA / sürüm notu
```

Bunlar ana galerinin veya güncelleme kanalının parçasıdır.
