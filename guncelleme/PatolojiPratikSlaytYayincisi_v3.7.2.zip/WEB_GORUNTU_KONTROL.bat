@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -m app.viewer_repair --from 76 --verify-web
) else (
  py -3 -m app.viewer_repair --from 76 --verify-web
)
echo.
echo page=true, dzi=true ve tile=true olan slaytlar gercekten webden okunabiliyor.
pause
