from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from guncelleme_yayinla import publish


def version_tuple(value: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", value)) or (0,)


def package_version(path: Path) -> str:
    try:
        with zipfile.ZipFile(path) as z:
            raw = json.loads(z.read("update-package.json").decode("utf-8"))
        return str(raw.get("version") or "0")
    except Exception:
        return "0"


def main() -> int:
    packages: list[Path] = []
    for folder in (ROOT / "guncelleme" / "uygulandi", ROOT / "guncelleme"):
        if folder.exists():
            packages.extend(p for p in folder.glob("*.zip") if p.is_file())
    if not packages:
        print("Yayinlanacak guncelleme ZIP'i bulunamadi.")
        return 1
    package = max(packages, key=lambda p: (version_tuple(package_version(p)), p.stat().st_mtime))
    print(f"Secilen paket: {package}")
    print(publish(package))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
