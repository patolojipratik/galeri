@echo off
setlocal
cd /d "%~dp0"
echo.
echo Bu arac gallery-076 ve sonrasini ayni-origin GitHub Pages yapisina cevirir.
echo Buyuk slaytlar bilgisayarinizdan tekrar yuklenmez; GitHub Actions repodaki tile dosyalarini Pages'e dagitir.
echo.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -m app.viewer_repair --from 76
) else (
  py -3 -m app.viewer_repair --from 76
)
echo.
echo Onarim tetiklendi. GitHub Actions tamamlaninca WEB_GORUNTU_KONTROL.bat ile dogrulayin.
pause
