@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" guncelleme_kanalini_esitle.py
) else (
  py -3 guncelleme_kanalini_esitle.py
)
echo.
pause
