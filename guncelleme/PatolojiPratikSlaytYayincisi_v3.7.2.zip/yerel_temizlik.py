from __future__ import annotations

"""E:\\github icin guvenli temizlik/onizleme araci.

Varsayilan mod SADECE RAPORLAR. --apply verilirse yalnizca onceden tanimlanmis
eski belge/test ciktilarini _arsiv altina tasir ve __pycache__ klasorlerini siler.
Aktif uygulama kodu, config, data, repos, work, .venv, github, guncelleme ana klasoru
ve anahtarlar asla silinmez.
"""

import argparse
import shutil
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent

ARCHIVE_EXACT_FILES = {
    "BOYUT_OTOMATIK_KUCULTME_V19.txt",
    "CSV_KILIDI_YAMASI_V18.txt",
    "ILK_ADIMLAR.txt",
    "README_TR.md",
    "README_GITHUB.md",
    "REPO_TEMIZLIK_ONERISI.md",
    "GUNCELLEME_SISTEMI_README.md",
}
ARCHIVE_GLOBS = (
    "SURUM_NOTLARI_V3_*_FINAL.md",
    "SURUM_NOTLARI_V3_*FINAL.md",
    "TEST_RAPORU_V3_*.txt",
)
ARCHIVE_DIRS = {"public_release"}
PROTECTED_TOP = {
    ".venv", "app", "config", "data", "github", "guncelleme", "logs", "repos", "work",
}


def size_of(path: Path) -> int:
    try:
        if path.is_file():
            return path.stat().st_size
        return sum(p.stat().st_size for p in path.rglob("*") if p.is_file())
    except Exception:
        return 0


def human(n: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(n)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{n} B"


def candidates() -> list[Path]:
    items: dict[str, Path] = {}
    for name in ARCHIVE_EXACT_FILES:
        p = ROOT / name
        if p.exists():
            items[str(p).lower()] = p
    for pattern in ARCHIVE_GLOBS:
        for p in ROOT.glob(pattern):
            if p.name == "SURUM_NOTLARI.md":
                continue
            items[str(p).lower()] = p
    for name in ARCHIVE_DIRS:
        p = ROOT / name
        if p.exists():
            items[str(p).lower()] = p
    return sorted(items.values(), key=lambda p: p.name.lower())


def cache_dirs() -> list[Path]:
    out = []
    for p in ROOT.rglob("__pycache__"):
        try:
            rel = p.relative_to(ROOT)
            if rel.parts and rel.parts[0] in {".venv", "repos", "work", "guncelleme", "_arsiv"}:
                continue
            out.append(p)
        except Exception:
            pass
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true", help="Guvenli adaylari _arsiv altina tasi")
    args = parser.parse_args()

    items = candidates()
    caches = cache_dirs()
    total = sum(size_of(p) for p in items) + sum(size_of(p) for p in caches)
    print("Patoloji Pratik yerel temizlik raporu")
    print(f"Kok: {ROOT}")
    print("\nARSIVE TASINABILIR:")
    if items:
        for p in items:
            print(f"  {p.name:45} {human(size_of(p)):>10}")
    else:
        print("  Yok")
    print("\nSILINMESI GUVENLI CACHE:")
    if caches:
        for p in caches:
            print(f"  {p.relative_to(ROOT)}")
    else:
        print("  Yok")
    print(f"\nToplam aday boyutu: {human(total)}")
    print("\nDOKUNULMAYACAK: app, config, data, repos, work, .venv, github, guncelleme, logs ve anahtarlar.")

    if not args.apply:
        print("\nBu sadece onizlemedir. Degisiklik yapilmadi.")
        return 0

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive = ROOT / "_arsiv" / stamp
    archive.mkdir(parents=True, exist_ok=True)
    for p in items:
        if p.name in PROTECTED_TOP:
            continue
        target = archive / p.name
        if target.exists():
            target = archive / (p.stem + "_2" + p.suffix)
        shutil.move(str(p), str(target))
        print(f"ARSIV: {p.name} -> {target}")
    for p in sorted(caches, key=lambda x: len(x.parts), reverse=True):
        shutil.rmtree(p, ignore_errors=True)
        print(f"CACHE SILINDI: {p.relative_to(ROOT)}")
    print(f"\nTamamlandi. Arsiv: {archive}")
    print("Arsivi bir sure kontrol ettikten sonra baska diske tasiyabilir veya elle silebilirsiniz.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
