@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" yerel_temizlik.py
) else (
  py -3 yerel_temizlik.py
)
echo.
pause
