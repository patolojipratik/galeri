from __future__ import annotations

"""Ana galeri yayininda repo README.md dosyasini korur.

Ana galeri HTML/JSON dosyalari uygulama tarafindan yeniden uretilir, ancak
README.md insan tarafindan yonetilen depo belgesidir. Eski gallery_builder
surumleri build_gallery() sirasinda README.md dosyasini yeniden yazabiliyordu.
Bu katman mevcut README'yi build oncesi saklar ve build sonrasinda aynen geri
koyar. Repo daha once README icermiyorsa uygulamanin otomatik README olusturmasi
da engellenir.
"""

from pathlib import Path
from typing import Any, Callable

_INSTALLED = False


def install_gallery_readme_guard() -> None:
    global _INSTALLED
    if _INSTALLED:
        return

    from . import gallery_builder as gb

    original: Callable[..., Path] = gb.build_gallery
    if getattr(original, "_patoloji_readme_guard", False):
        _INSTALLED = True
        return

    def guarded_build_gallery(settings: Any, progress=None) -> Path:
        repo_dir = settings.repos_dir / settings.gallery_repo
        readme = repo_dir / "README.md"
        existed = readme.exists()
        saved: bytes | None = None
        if existed:
            try:
                saved = readme.read_bytes()
            except OSError:
                saved = None

        result = original(settings, progress)

        try:
            if existed and saved is not None:
                if not readme.exists() or readme.read_bytes() != saved:
                    readme.write_bytes(saved)
                    if progress:
                        progress("Ana galeri README.md korundu", None)
            elif not existed and readme.exists():
                readme.unlink()
                if progress:
                    progress("Ana galeri README.md uygulama tarafindan olusturulmadi", None)
        except OSError as exc:
            if progress:
                progress(f"README.md korunamadi: {exc}", None)
        return result

    guarded_build_gallery._patoloji_readme_guard = True  # type: ignore[attr-defined]
    gb.build_gallery = guarded_build_gallery
    _INSTALLED = True
