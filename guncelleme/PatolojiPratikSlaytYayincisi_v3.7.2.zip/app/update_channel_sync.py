from __future__ import annotations

"""Kurulan guncellemeyi ana galeri reposundaki guncelleme kanalina esitle.

Bu ozellik yalnizca bu bilgisayarda hedef GitHub hesabi icin kayitli token
varsa calisir. Kullanici verisi veya slayt repolariyla ilgilenmez. Basarisizlik
ana programin acilmasini engellemez.
"""

import hashlib
import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Any


def _version_tuple(value: str) -> tuple[int, ...]:
    import re
    nums = [int(x) for x in re.findall(r"\d+", str(value))]
    return tuple(nums or [0])


def _manifest_version(path: Path) -> str:
    import zipfile
    try:
        with zipfile.ZipFile(path) as z:
            raw = json.loads(z.read("update-package.json").decode("utf-8"))
        return str(raw.get("version") or "0")
    except Exception:
        return "0"


def _current_version(root: Path) -> str:
    try:
        raw = json.loads((root / "version.json").read_text(encoding="utf-8"))
        return str(raw.get("version") or "0")
    except Exception:
        return "0"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _find_package(root: Path) -> Path | None:
    current = _current_version(root)
    candidates: list[Path] = []
    for folder in (root / "guncelleme" / "uygulandi", root / "guncelleme"):
        if folder.exists():
            candidates.extend(p for p in folder.glob("*.zip") if p.is_file())
    exact = [p for p in candidates if _manifest_version(p) == current]
    if exact:
        return max(exact, key=lambda p: p.stat().st_mtime)
    return max(candidates, key=lambda p: (_version_tuple(_manifest_version(p)), p.stat().st_mtime), default=None)


def _token_available(root: Path) -> bool:
    username = "patolojipratik"
    try:
        settings = json.loads((root / "config" / "settings.json").read_text(encoding="utf-8"))
        username = str(settings.get("github_username") or username).strip()
    except Exception:
        pass
    try:
        from .token_store import get_token
        return bool((get_token(username) or "").strip())
    except Exception:
        return False


def _log(root: Path, message: str) -> None:
    path = root / "logs" / "update_channel_sync.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(f"{datetime.now().isoformat(timespec='seconds')} {message}\n")


def _worker(root: Path) -> None:
    try:
        if not _token_available(root):
            return
        package = _find_package(root)
        if not package:
            return
        digest = _sha256(package)
        marker = root / "guncelleme" / ".kanal_yayin.json"
        if marker.exists():
            try:
                raw: dict[str, Any] = json.loads(marker.read_text(encoding="utf-8"))
                if raw.get("sha256") == digest and raw.get("ok") is True:
                    return
            except Exception:
                pass
        import sys
        sys.path.insert(0, str(root))
        from guncelleme_yayinla import publish
        result = publish(package)
        marker.write_text(
            json.dumps(
                {
                    "ok": True,
                    "version": _manifest_version(package),
                    "sha256": digest,
                    "published_at": datetime.now().isoformat(timespec="seconds"),
                    "result": result,
                },
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
        _log(root, result)
    except Exception as exc:
        _log(root, f"Otomatik guncelleme kanali esitleme atlandi/basarisiz: {type(exc).__name__}: {exc}")


def schedule_update_channel_sync(root_widget) -> None:
    try:
        app_root = Path(__file__).resolve().parents[1]
        root_widget.after(2500, lambda: threading.Thread(target=_worker, args=(app_root,), daemon=True).start())
    except Exception:
        pass
