from __future__ import annotations

"""Ana galeri kartlarinda Baslik/Tani alanlarini anlamsal sirada gosterir.

Eski gallery_builder surumleri kart ana basligi olarak `diagnosis` alanini
kullaniyordu. Masaustu editorundeki alanlar ise ayri ayri Baslik ve Tani'dir.
Bu koruma build_gallery() tamamlandiktan sonra yalnizca uretilen index.html
sunum kodunu duzeltir:

- kart ana satiri: Baslik
- ikinci satir: Tani (Basliktan farkliysa)
- ucuncu satir: Organ / sistem
- ayrinti paneli: Baslik -> Tani -> Organ -> Aciklama
- buyuk onizleme basligi: Baslik; alt satir: Tani + Organ

slides.json, CSV veya kullanici verisi degistirilmez.
"""

import re
from pathlib import Path
from typing import Any, Callable

_INSTALLED = False
_MARKER = "PATOLOJI-TITLE-DIAGNOSIS-V1"

_INFO_FUNCTION = r'''function infoContent(x){
 const tags=String(x.tags||'').split(',').map(t=>t.trim()).filter(Boolean);
 const title=(x.title||x.diagnosis||'Başlık bilgisi bekleniyor').trim();
 const diagnosis=(x.diagnosis||'').trim();
 const titleRow=`<div class="detail-row"><span class="detail-label">Başlık</span>${esc(title)}</div>`;
 const diagnosisRow=diagnosis&&diagnosis!==title?`<div class="detail-row"><span class="detail-label">Tanı</span>${esc(diagnosis)}</div>`:'';
 const organRow=x.organ?`<div class="detail-row"><span class="detail-label">Organ / sistem</span>${esc(x.organ)}</div>`:'';
 const description=x.description?`<div class="detail-row"><span class="detail-label">Açıklama</span>${esc(x.description)}</div>`:'<div class="detail-row"><span class="detail-label">Açıklama</span>Henüz açıklama eklenmemiş.</div>';
 const tagBlock=tags.length?`<div class="tags">${tags.map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div>`:'';
 return `${titleRow}${diagnosisRow}${organRow}${description}${tagBlock}`;
}
'''

_DRAW_FUNCTION = r'''function draw(){
 const term=q.value.toLocaleLowerCase('tr');
 const rows=all.filter(x=>JSON.stringify(x).toLocaleLowerCase('tr').includes(term));
 count.textContent=rows.length+' slayt';
 grid.innerHTML=rows.length?rows.map((x,i)=>{
  const title=(x.title||x.diagnosis||'Başlık bilgisi bekleniyor').trim();
  const diagnosis=(x.diagnosis||'').trim();
  const small=x.small_thumbnail_url||x.thumbnail_url;
  const diagnosisLine=diagnosis&&diagnosis!==title?`<div class="diagnosis-sub">${esc(diagnosis)}</div>`:'';
  return `<article class="card"><a class="thumb-link" href="${esc(x.page_url)}" title="Sanal mikroskobu aç"><img class="small-thumb" loading="lazy" decoding="async" src="${esc(small)}" alt="${esc(title)}"></a><div class="text"><div class="slide-title">${esc(title)}</div>${diagnosisLine}<div class="organ">${esc(x.organ||'')}</div></div><button class="expand-button" type="button" data-preview-index="${i}" aria-label="Ayrıntıları ve büyük ön izlemeyi aç" title="Ayrıntıları aç"><span aria-hidden="true">🔽</span></button></article>`;
 }).join(''):'<div class="empty">Aramayla eşleşen slayt bulunamadı.</div>';
 grid.querySelectorAll('[data-preview-index]').forEach((button,i)=>{button.dataset.itemId=rows[i].gallery_id||String(i)});
}
'''


def patch_gallery_index_text(text: str) -> tuple[str, bool]:
    if _MARKER in text:
        return text, False

    changed = False

    # Kart stilleri. Eski .diagnosis sinifi yerinde kalabilir; yeni siniflar
    # daha sonra eklenerek geriye donuk HTML ile de uyumlu olunur.
    style_add = (
        ".slide-title{font-size:18px;font-weight:750;line-height:1.28}"
        ".diagnosis-sub{color:#344b63;margin-top:6px;line-height:1.4;font-size:14px}"
    )
    if "</style>" in text and ".slide-title{" not in text:
        text = text.replace("</style>", style_add + "\n</style>", 1)
        changed = True

    # Ayrinti panelini butun olarak degistir. Bu, builder'in onceki
    # diagnosis-first uygulamasindan bagimsiz ve idempotenttir.
    pattern = re.compile(r"function infoContent\(x\)\{.*?\n\}\n(?=function draw\(\)\{)", re.S)
    text2, count = pattern.subn(_INFO_FUNCTION, text, count=1)
    if count:
        text = text2
        changed = True

    # Kartlari Baslik -> Tani -> Organ olarak ciz.
    pattern = re.compile(r"function draw\(\)\{.*?\n\}\n(?=function stagePoint\()", re.S)
    text2, count = pattern.subn(_DRAW_FUNCTION, text, count=1)
    if count:
        text = text2
        changed = True

    # Buyuk onizleme basligini da Baslik yap. Tani ve organ alt satirda.
    old = (
        "activeItem=x;lastFocused=trigger;modalTitle.textContent=x.diagnosis||x.title||'Tanı bilgisi bekleniyor';"
        "modalOrgan.textContent=x.organ||'';modalInfo.innerHTML=infoContent(x);"
        "modalImage.alt=(x.diagnosis||x.title||'')+' büyük ön izleme';"
    )
    new = (
        "activeItem=x;lastFocused=trigger;"
        "const previewTitle=x.title||x.diagnosis||'Başlık bilgisi bekleniyor';"
        "const previewDiagnosis=(x.diagnosis&&x.diagnosis!==previewTitle)?x.diagnosis:'';"
        "modalTitle.textContent=previewTitle;"
        "modalOrgan.textContent=[previewDiagnosis,x.organ||''].filter(Boolean).join(' • ');"
        "modalInfo.innerHTML=infoContent(x);modalImage.alt=previewTitle+' büyük ön izleme';"
    )
    if old in text:
        text = text.replace(old, new, 1)
        changed = True
    else:
        # Biraz farkli builder surumleri icin sinirli regex fallback.
        preview_pattern = re.compile(
            r"activeItem=x;lastFocused=trigger;modalTitle\.textContent=x\.diagnosis\|\|x\.title\|\|'[^']*';"
            r"modalOrgan\.textContent=x\.organ\|\|'';modalInfo\.innerHTML=infoContent\(x\);"
            r"modalImage\.alt=\(x\.diagnosis\|\|x\.title\|\|''\)\+'[^']*';"
        )
        text2, count = preview_pattern.subn(new, text, count=1)
        if count:
            text = text2
            changed = True

    if changed:
        marker = f"<!-- {_MARKER} -->\n"
        if "</head>" in text:
            text = text.replace("</head>", marker + "</head>", 1)
        else:
            text = marker + text
    return text, changed


def patch_gallery_index(path: Path, progress=None) -> bool:
    if not path.exists():
        return False
    original = path.read_text(encoding="utf-8", errors="replace")
    patched, changed = patch_gallery_index_text(original)
    if changed:
        path.write_text(patched, encoding="utf-8", newline="\n")
        if progress:
            progress("Ana galeri: Başlık/Tanı gösterim sırası düzeltildi", None)
    return changed


def install_gallery_display_guard() -> None:
    global _INSTALLED
    if _INSTALLED:
        return

    from . import gallery_builder as gb

    original: Callable[..., Path] = gb.build_gallery
    if getattr(original, "_patoloji_display_guard", False):
        _INSTALLED = True
        return

    def guarded_build_gallery(settings: Any, progress=None) -> Path:
        result = original(settings, progress)
        try:
            repo_dir = settings.repos_dir / settings.gallery_repo
            patch_gallery_index(repo_dir / "index.html", progress=progress)
        except Exception as exc:
            if progress:
                progress(f"Ana galeri Başlık/Tanı görünümü düzeltilemedi: {exc}", None)
        return result

    guarded_build_gallery._patoloji_display_guard = True  # type: ignore[attr-defined]
    gb.build_gallery = guarded_build_gallery
    _INSTALLED = True
