from __future__ import annotations

"""GitHub Pages sanal mikroskop goruntuleyici onarimi - v3.7.1.

076 ve sonrasi icin kullanilan hafif Pages yapisinda tile'lar raw.githubusercontent.com
uzerinden okunuyordu. HTML JavaScript hatasi 3.7.0'da duzeltildi; ancak bazi
tarayicilarda/ortamlarda sayfa yine karanlik kalabildi. 3.7.1, bu repolari tekrar
ayni-origin (same-origin) Deep Zoom yapisina cevirir:

- index.html -> tileSources: 'slide.dzi'
- Pages workflow -> slide_files klasorunu da Pages artifact'ine dahil eder
- kullanicinin bilgisayarindan buyuk tile dosyalari yeniden yuklenmez; GitHub
  Actions repoda zaten bulunan dosyalardan Pages artifact'ini olusturur.

Ayrica yeni olusturulan lightweight index/workflow dosyalarini yazim aninda full
Pages bicimine ceviren dar kapsamli bir koruma kurar.
"""

import argparse
import base64
import csv
import json
import os
import re
import threading
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any

APP_ROOT = Path(__file__).resolve().parents[1]
LIGHT_MARKER = "patoloji-lightweight-pages-v1"
FULL_MARKER = "patoloji-full-pages-v1"
DEFAULT_FROM = 76
_INSTALLED = False
_ORIGINAL_WRITE_TEXT = None
_ORIGINAL_WRITE_BYTES = None

FULL_PAGES_WORKFLOW = r'''name: Pages dagitimi

"on":
  push:
    branches: ["main"]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

jobs:
  deploy:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    environment:
      name: github-pages
    steps:
      - name: Pages dosyalarini al
        uses: actions/checkout@v6
        with:
          fetch-depth: 1

      - name: Pages ayarlarini oku
        uses: actions/configure-pages@v6

      - name: Pages paketini hazirla
        shell: bash
        run: |
          set -euo pipefail
          test -f index.html
          test -f slide.dzi
          test -d slide_files
          rm -rf _pages_site
          mkdir -p _pages_site
          cp index.html slide.dzi _pages_site/
          cp -a slide_files _pages_site/
          test -f thumbnail.jpg && cp thumbnail.jpg _pages_site/ || true
          test -f label.jpg && cp label.jpg _pages_site/ || true
          test -f metadata.json && cp metadata.json _pages_site/ || true
          test -f .nojekyll && cp .nojekyll _pages_site/ || true
          echo "Pages paketi hazir. Tile sayisi:"
          find _pages_site/slide_files -type f | wc -l
          du -sh _pages_site

      - name: Pages artifact'ini yukle
        id: upload
        uses: actions/upload-pages-artifact@v5
        with:
          path: _pages_site
          include-hidden-files: true

      - name: Pages'e dagit
        id: deployment
        uses: actions/deploy-pages@v5
'''


def _settings_dict() -> dict[str, Any]:
    path = APP_ROOT / "config" / "settings.json"
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _setting(name: str, default: str) -> str:
    cfg = _settings_dict()
    value = str(cfg.get(name) or "").strip()
    if value:
        return value
    try:
        from . import config as app_config
        settings = app_config.Settings.load()
        value = str(getattr(settings, name, "") or "").strip()
        if value:
            return value
    except Exception:
        pass
    return default


def _token_for(username: str) -> str:
    try:
        from .token_store import get_token
        value = get_token(username)
        if value:
            return value.strip()
    except Exception:
        pass
    try:
        import keyring
        value = keyring.get_password("patoloji-pratik-github-yayinlama", username)
        if value:
            return value.strip()
    except Exception:
        pass
    raise RuntimeError("GitHub tokeni bulunamadi. Once GITHUB_BAGLA.bat calistirin.")


def convert_index_to_full_pages(text: str) -> tuple[str, bool]:
    """Lightweight/raw tile viewer'i ayni-origin slide.dzi viewer'a cevir."""
    original = text
    if LIGHT_MARKER not in text and "raw.githubusercontent.com" not in text:
        return text, False

    text = text.replace(LIGHT_MARKER, FULL_MARKER)
    # Lightweight kurulumdaki explicit DziTileSource satirini kaldir.
    text = re.sub(
        r"\s*const\s+tileSource\s*=\s*new\s+OpenSeadragon\.DziTileSource\(\{.*?\}\);\s*",
        "\n",
        text,
        flags=re.S,
    )
    text = text.replace("tileSources:tileSource", "tileSources:'slide.dzi'")
    text = text.replace('tileSources: tileSource', "tileSources: 'slide.dzi'")
    # Guvenli bir ek kontrol: raw URL kaldiysa tileSources satirini klasik yap.
    if "raw.githubusercontent.com" in text:
        text = re.sub(
            r"tileSources\s*:\s*new\s+OpenSeadragon\.DziTileSource\(\{.*?\}\)",
            "tileSources:'slide.dzi'",
            text,
            flags=re.S,
        )
    return text, text != original


def convert_workflow_to_full_pages(text: str) -> tuple[str, bool]:
    low = text.lower()
    if "hafif pages" in low or "yalnizca pages kabugunu" in low or (
        "sparse-checkout" in low and "slide_files" not in text
    ):
        eol = "\r\n" if "\r\n" in text else "\n"
        return FULL_PAGES_WORKFLOW.replace("\n", eol), True
    return text, False


def install_viewer_html_guard() -> None:
    """Yeni viewer/workflow dosyalari yazilirken lightweight yapisini engelle."""
    global _INSTALLED, _ORIGINAL_WRITE_TEXT, _ORIGINAL_WRITE_BYTES
    if _INSTALLED:
        return
    _INSTALLED = True
    _ORIGINAL_WRITE_TEXT = Path.write_text
    _ORIGINAL_WRITE_BYTES = Path.write_bytes

    def _fix(path: Path, data: str) -> str:
        if path.name.lower() == "index.html":
            data, _ = convert_index_to_full_pages(data)
        elif path.name.lower() in {"pages.yml", "pages.yaml"} and path.parent.name == "workflows":
            data, _ = convert_workflow_to_full_pages(data)
        return data

    def guarded_write_text(self: Path, data: str, *args, **kwargs):
        if isinstance(data, str):
            data = _fix(self, data)
        return _ORIGINAL_WRITE_TEXT(self, data, *args, **kwargs)

    def guarded_write_bytes(self: Path, data: bytes, *args, **kwargs):
        if isinstance(data, (bytes, bytearray)):
            try:
                text = bytes(data).decode("utf-8")
                fixed = _fix(self, text)
                if fixed != text:
                    data = fixed.encode("utf-8")
            except Exception:
                pass
        return _ORIGINAL_WRITE_BYTES(self, data, *args, **kwargs)

    Path.write_text = guarded_write_text
    Path.write_bytes = guarded_write_bytes


def _api(method: str, url: str, token: str, payload: dict[str, Any] | None = None) -> Any:
    body = None
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "Patoloji-Pratik-Viewer-Repair/3.7.1",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            raw = response.read()
            if not raw:
                return {}
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        raise RuntimeError(f"GitHub API HTTP {exc.code}: {detail[:700]}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"GitHub baglantisi kurulamadi: {exc}") from exc


def _repo_ids_from_csv(from_number: int, to_number: int | None) -> list[str]:
    path = APP_ROOT / "data" / "slides.csv"
    ids: set[str] = set()
    if path.exists():
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                for row in csv.DictReader(handle):
                    gallery_id = str(row.get("gallery_id") or row.get("repo") or "").strip()
                    match = re.fullmatch(r"gallery-(\d+)", gallery_id)
                    if not match:
                        continue
                    number = int(match.group(1))
                    if number < from_number or (to_number is not None and number > to_number):
                        continue
                    ids.add(f"gallery-{number:03d}")
        except Exception:
            pass
    return sorted(ids, key=lambda value: int(value.split("-")[-1]))


def _get_file(username: str, repo: str, path: str, token: str) -> tuple[str | None, str | None]:
    url = f"https://api.github.com/repos/{username}/{repo}/contents/{path}?ref=main"
    try:
        data = _api("GET", url, token)
    except RuntimeError as exc:
        if "HTTP 404" in str(exc):
            return None, None
        raise
    if not isinstance(data, dict) or "content" not in data or "sha" not in data:
        return None, None
    content = base64.b64decode(str(data["content"]).replace("\n", "")).decode("utf-8")
    return content, str(data["sha"])


def _put_file(username: str, repo: str, path: str, token: str, content: str, sha: str | None, message: str) -> None:
    url = f"https://api.github.com/repos/{username}/{repo}/contents/{path}"
    payload: dict[str, Any] = {
        "message": message,
        "content": base64.b64encode(content.encode("utf-8")).decode("ascii"),
        "branch": "main",
    }
    if sha:
        payload["sha"] = sha
    _api("PUT", url, token, payload)


def _dispatch_pages(username: str, repo: str, token: str) -> None:
    url = f"https://api.github.com/repos/{username}/{repo}/actions/workflows/pages.yml/dispatches"
    _api("POST", url, token, {"ref": "main"})


def _probe_url(url: str, token: str = "") -> bool:
    headers = {"User-Agent": "Patoloji-Pratik-Viewer-Repair/3.7.1", "Range": "bytes=0-31"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return 200 <= int(getattr(response, "status", 200)) < 300
    except Exception:
        return False


def repair_repository(username: str, repo: str, token: str, dry_run: bool = False) -> dict[str, Any]:
    index, index_sha = _get_file(username, repo, "index.html", token)
    if index is None:
        return {"repo": repo, "status": "index_yok", "changed": False}

    new_index, index_changed = convert_index_to_full_pages(index)
    workflow, workflow_sha = _get_file(username, repo, ".github/workflows/pages.yml", token)
    if workflow is None:
        new_workflow, workflow_changed = FULL_PAGES_WORKFLOW, True
    else:
        new_workflow, workflow_changed = convert_workflow_to_full_pages(workflow)

    already_full = FULL_MARKER in new_index and "tileSources:'slide.dzi'" in new_index
    if dry_run:
        return {
            "repo": repo,
            "status": "onarim_gerekli" if (index_changed or workflow_changed) else "tam",
            "changed": bool(index_changed or workflow_changed),
            "full": already_full,
        }

    if index_changed:
        _put_file(username, repo, "index.html", token, new_index, index_sha, "Sanal mikroskop ayni-origin Pages goruntuleyici")
    if workflow_changed:
        _put_file(username, repo, ".github/workflows/pages.yml", token, new_workflow, workflow_sha, "Pages tile dosyalariyla birlikte yayinlanacak")

    # Dosya degismese bile kullanici onarim istediyse Pages'i yeniden calistir.
    _dispatch_pages(username, repo, token)
    return {
        "repo": repo,
        "status": "pages_baslatildi",
        "changed": bool(index_changed or workflow_changed),
        "full": True,
    }


def verify_repository(username: str, repo: str) -> dict[str, Any]:
    page = f"https://{username}.github.io/{repo}/"
    dzi = page + "slide.dzi"
    tile = page + "slide_files/0/0_0.jpeg"
    return {
        "repo": repo,
        "page": _probe_url(page),
        "dzi": _probe_url(dzi),
        "tile": _probe_url(tile),
    }


def repair_all(from_number: int = DEFAULT_FROM, to_number: int | None = None, dry_run: bool = False, progress=None) -> dict[str, Any]:
    username = _setting("github_username", "patolojipratik")
    token = _token_for(username)
    repos = _repo_ids_from_csv(from_number, to_number)
    results = []
    for i, repo in enumerate(repos, 1):
        if progress:
            progress(f"{repo} kontrol ediliyor ({i}/{len(repos)})", i / max(1, len(repos)))
        try:
            results.append(repair_repository(username, repo, token, dry_run=dry_run))
        except Exception as exc:
            results.append({"repo": repo, "status": "hata", "error": str(exc), "changed": False})
    log_dir = APP_ROOT / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report = {"time": stamp, "from": from_number, "to": to_number, "dry_run": dry_run, "results": results}
    (log_dir / f"web_goruntu_onarim_{stamp}.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def verify_all(from_number: int = DEFAULT_FROM, to_number: int | None = None, progress=None) -> dict[str, Any]:
    username = _setting("github_username", "patolojipratik")
    repos = _repo_ids_from_csv(from_number, to_number)
    results = []
    for i, repo in enumerate(repos, 1):
        if progress:
            progress(f"{repo} web kontrolu ({i}/{len(repos)})", i / max(1, len(repos)))
        results.append(verify_repository(username, repo))
    return {"results": results}


def repair_in_background(root, from_number: int = DEFAULT_FROM) -> None:
    from tkinter import messagebox

    def worker():
        try:
            report = repair_all(from_number=from_number)
            failed = [x for x in report["results"] if x.get("status") == "hata"]
            started = [x for x in report["results"] if x.get("status") == "pages_baslatildi"]
            msg = f"{len(started)} repo icin Pages onarimi baslatildi."
            if failed:
                msg += f"\n{len(failed)} repoda hata var; logs klasorune bakiniz."
            msg += "\n\nPages buyuk slaytlarda birkaç dakika, bazen daha uzun surebilir."
            root.after(0, lambda: messagebox.showinfo("Web goruntuleyici onarimi", msg))
        except Exception as exc:
            root.after(0, lambda: messagebox.showerror("Web goruntuleyici onarimi", str(exc)))

    threading.Thread(target=worker, daemon=True).start()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="from_number", type=int, default=DEFAULT_FROM)
    parser.add_argument("--to", dest="to_number", type=int)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--verify-web", action="store_true")
    args = parser.parse_args()
    if args.verify_web:
        report = verify_all(args.from_number, args.to_number)
    else:
        report = repair_all(args.from_number, args.to_number, dry_run=args.check)
    for item in report["results"]:
        print(json.dumps(item, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
