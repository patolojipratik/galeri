from __future__ import annotations

import json
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import ttk

_INSTALLED = False
_ORIGINAL_MAINLOOP = None

BG = "#f4f7fb"
HEADER = "#123154"
HEADER_BADGE = "#1d4f7f"
TEXT = "#0f2742"
MUTED = "#61758d"
BORDER = "#d8e2ec"
PRIMARY = "#1f6fba"
PRIMARY_ACTIVE = "#195f9f"
SECONDARY = "#ffffff"
SECONDARY_ACTIVE = "#edf4fb"
HELP = "#0f766e"
HELP_ACTIVE = "#0b625c"
FINISH = "#d97706"
FINISH_ACTIVE = "#b96305"
DANGER = "#c43d3d"
DANGER_ACTIVE = "#a83232"


def _version_label(root: tk.Misc) -> str:
    try:
        app_root = Path(__file__).resolve().parents[1]
        raw = json.loads((app_root / "version.json").read_text(encoding="utf-8"))
        return str(raw.get("label") or raw.get("version") or "").strip()
    except Exception:
        return ""


def _walk(widget: tk.Misc):
    yield widget
    for child in widget.winfo_children():
        yield from _walk(child)


def _text(widget: tk.Misc) -> str:
    try:
        return str(widget.cget("text") or "").strip()
    except Exception:
        return ""


def _open_usage(root: tk.Misc) -> None:
    username = "patolojipratik"
    repo = "galeri"
    try:
        settings = getattr(root, "settings", None)
        username = str(getattr(settings, "github_username", username) or username)
        repo = str(getattr(settings, "gallery_repo", repo) or repo)
    except Exception:
        pass
    url = f"https://github.com/{username}/{repo}/blob/main/HARICI_SSD_DEVAM_REHBERI.md"
    webbrowser.open(url)


def _repair_web_viewers(root: tk.Misc) -> None:
    try:
        from .viewer_repair import repair_in_background
        repair_in_background(root, from_number=76)
    except Exception as exc:
        try:
            from tkinter import messagebox
            messagebox.showerror("Web goruntuleyici onarimi", str(exc))
        except Exception:
            pass


def _configure_styles(root: tk.Misc) -> None:
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    style.configure(".", font=("Segoe UI", 9))
    style.configure("TLabel", background=BG, foreground=TEXT)
    style.configure("App.TFrame", background=BG)
    style.configure("Header.TFrame", background=HEADER)
    style.configure(
        "HeaderTitle.TLabel",
        background=HEADER,
        foreground="white",
        font=("Segoe UI", 20, "bold"),
    )
    style.configure(
        "HeaderSub.TLabel",
        background=HEADER,
        foreground="#cfdeed",
        font=("Segoe UI", 9),
    )
    style.configure(
        "Primary.TButton",
        font=("Segoe UI", 10, "bold"),
        padding=(17, 10),
        background=PRIMARY,
        foreground="white",
        borderwidth=0,
        focusthickness=1,
        focuscolor=PRIMARY,
    )
    style.map(
        "Primary.TButton",
        background=[("active", PRIMARY_ACTIVE), ("pressed", PRIMARY_ACTIVE)],
        foreground=[("disabled", "#c8d5e3")],
    )
    style.configure(
        "Secondary.TButton",
        font=("Segoe UI", 9),
        padding=(11, 7),
        background=SECONDARY,
        foreground=TEXT,
        bordercolor=BORDER,
        lightcolor=BORDER,
        darkcolor=BORDER,
        borderwidth=1,
    )
    style.map("Secondary.TButton", background=[("active", SECONDARY_ACTIVE)])
    style.configure(
        "Help.TButton",
        font=("Segoe UI", 9, "bold"),
        padding=(12, 7),
        background=HELP,
        foreground="white",
        borderwidth=0,
    )
    style.map("Help.TButton", background=[("active", HELP_ACTIVE)])
    style.configure(
        "Finish.TButton",
        font=("Segoe UI", 10, "bold"),
        padding=(14, 10),
        background=FINISH,
        foreground="white",
        borderwidth=0,
    )
    style.map("Finish.TButton", background=[("active", FINISH_ACTIVE)])
    style.configure(
        "Danger.TButton",
        font=("Segoe UI", 9, "bold"),
        padding=(12, 7),
        background=DANGER,
        foreground="white",
        borderwidth=0,
    )
    style.map("Danger.TButton", background=[("active", DANGER_ACTIVE)])

    style.configure(
        "Treeview",
        background="white",
        fieldbackground="white",
        foreground="#18324d",
        bordercolor=BORDER,
        rowheight=29,
        font=("Segoe UI", 9),
    )
    style.map(
        "Treeview",
        background=[("selected", "#dbeafe")],
        foreground=[("selected", "#0f2742")],
    )
    style.configure(
        "Treeview.Heading",
        background="#e9eff6",
        foreground="#17324d",
        font=("Segoe UI", 9, "bold"),
        padding=(6, 7),
        bordercolor=BORDER,
    )
    style.map("Treeview.Heading", background=[("active", "#dde8f3")])
    style.configure("TNotebook", background=BG, borderwidth=0)
    style.configure(
        "TNotebook.Tab",
        padding=(14, 7),
        font=("Segoe UI", 9, "bold"),
        background="#e5ebf2",
        foreground="#476078",
    )
    style.map(
        "TNotebook.Tab",
        background=[("selected", "white"), ("active", "#eef3f8")],
        foreground=[("selected", TEXT)],
    )
    style.configure(
        "Horizontal.TProgressbar",
        troughcolor="#dfe7ef",
        background="#4b83bd",
        bordercolor="#dfe7ef",
        lightcolor="#4b83bd",
        darkcolor="#4b83bd",
        thickness=8,
    )


def _restyle_legacy_backgrounds(root: tk.Misc) -> None:
    for widget in _walk(root):
        try:
            widget.configure(cursor="hand2" if isinstance(widget, ttk.Button) else widget.cget("cursor"))
        except Exception:
            pass

        if isinstance(widget, (tk.Frame, tk.Label)):
            try:
                bg = str(widget.cget("bg")).lower()
                if bg in {"#eef2f7", "#f0f0f0", "systembuttonface"}:
                    widget.configure(bg=BG)
                    if isinstance(widget, tk.Label):
                        widget.configure(fg=TEXT)
            except Exception:
                pass
        elif isinstance(widget, ttk.Label):
            try:
                bg = str(widget.cget("background")).lower()
                if bg == "#eef2f7":
                    widget.configure(background=BG, foreground=TEXT)
            except Exception:
                pass


def _style_header_badge(root: tk.Misc) -> None:
    for widget in _walk(root):
        if isinstance(widget, tk.Label):
            try:
                textvariable = str(widget.cget("textvariable") or "")
                text = _text(widget)
                bg = str(widget.cget("bg")).lower()
                if "github" in text.lower() or (textvariable and bg in {"#1b426d", "#1d4f7f"}):
                    widget.configure(
                        bg=HEADER_BADGE,
                        fg="white",
                        font=("Segoe UI", 9, "bold"),
                        padx=13,
                        pady=7,
                        relief="flat",
                    )
            except Exception:
                pass


def _style_cards(root: tk.Misc) -> None:
    palettes = {
        "Toplam": ("#ffffff", "#64748b", TEXT, BORDER),
        "Toplam slayt": ("#ffffff", "#64748b", TEXT, BORDER),
        "Yayında": ("#eefaf2", "#43845b", "#166534", "#c7ead2"),
        "Bekleyen": ("#f5f8fc", "#667b91", TEXT, "#d9e3ed"),
        "İşlenecek": ("#f5f8fc", "#667b91", TEXT, "#d9e3ed"),
        "Yayın bekliyor": ("#f2faf7", "#4f7f70", "#116149", "#cde9df"),
        "Hata": ("#fff7f7", "#a45a5a", "#9f2d2d", "#efd0d0"),
        "İşlem hatası": ("#f2faf7", "#4f7f70", "#116149", "#cde9df"),
        "Sıradaki": ("#ffffff", "#64748b", TEXT, BORDER),
        "Sıradaki işlem": ("#ffffff", "#64748b", TEXT, BORDER),
    }
    for widget in list(_walk(root)):
        if not isinstance(widget, tk.Label):
            continue
        label = _text(widget)
        if label not in palettes:
            continue
        parent = widget.master
        if not isinstance(parent, tk.Frame):
            continue
        bg, muted, strong, border = palettes[label]
        try:
            parent.configure(
                bg=bg,
                bd=0,
                relief="flat",
                highlightthickness=1,
                highlightbackground=border,
                highlightcolor=border,
                padx=14,
                pady=9,
            )
        except Exception:
            pass
        for child in parent.winfo_children():
            if isinstance(child, tk.Label):
                try:
                    child.configure(bg=bg)
                    if child is widget:
                        child.configure(fg=muted, font=("Segoe UI", 9))
                    else:
                        child.configure(fg=strong)
                except Exception:
                    pass


def _style_panels(root: tk.Misc) -> None:
    for widget in _walk(root):
        if not isinstance(widget, tk.Label):
            continue
        text = _text(widget)
        if text == "Yayın denetimi":
            parent = widget.master
            if isinstance(parent, tk.Frame):
                try:
                    parent.configure(
                        bg="white",
                        bd=0,
                        relief="flat",
                        highlightthickness=1,
                        highlightbackground=BORDER,
                        highlightcolor=BORDER,
                    )
                    widget.configure(bg="white", fg=TEXT, font=("Segoe UI", 9, "bold"))
                    for child in parent.winfo_children():
                        if isinstance(child, tk.Label) and child is not widget:
                            child.configure(bg="white", fg=MUTED)
                except Exception:
                    pass
        elif text == "GÜVENLE KAPATABİLİRSİNİZ":
            parent = widget.master
            if isinstance(parent, tk.Frame):
                try:
                    parent.configure(
                        bd=0,
                        relief="flat",
                        highlightthickness=1,
                        highlightbackground="#b9ddc5",
                        highlightcolor="#b9ddc5",
                    )
                except Exception:
                    pass


def _stripe_trees(root: tk.Misc) -> None:
    for widget in _walk(root):
        if not isinstance(widget, ttk.Treeview):
            continue
        try:
            widget.tag_configure("ui_even", background="#ffffff")
            widget.tag_configure("ui_odd", background="#f7fafc")
            for index, item in enumerate(widget.get_children("")):
                tags = tuple(widget.item(item, "tags") or ())
                stripe = "ui_even" if index % 2 == 0 else "ui_odd"
                if stripe not in tags:
                    widget.item(item, tags=tags + (stripe,))
        except Exception:
            pass


def _add_help_button(root: tk.Misc) -> None:
    existing = []
    github_button = None
    for widget in _walk(root):
        if isinstance(widget, ttk.Button):
            text = _text(widget)
            existing.append(text.casefold())
            if text.casefold() in {"github bağlantısı", "github bağla", "github bagla"}:
                github_button = widget

    parent = github_button.master if github_button is not None else None
    if parent is None:
        return

    try:
        info = github_button.pack_info() if github_button is not None else {}
        side = info.get("side", "left")
    except Exception:
        side = "left"

    if not any("kullanım rehberi" in text or "kullanim rehberi" in text for text in existing):
        button = ttk.Button(
            parent,
            text="Kullanım rehberi",
            command=lambda: _open_usage(root),
            style="Help.TButton",
            cursor="hand2",
        )
        button.pack(side=side, padx=3)

    if not any("web görüntülerini onar" in text or "web goruntulerini onar" in text for text in existing):
        repair_button = ttk.Button(
            parent,
            text="Web görüntülerini onar",
            command=lambda: _repair_web_viewers(root),
            style="Secondary.TButton",
            cursor="hand2",
        )
        repair_button.pack(side=side, padx=3)


def apply_ui_enhancements(root: tk.Misc) -> None:
    try:
        root.configure(bg=BG)
    except Exception:
        pass

    label = _version_label(root)
    if label:
        try:
            root.title(f"Patoloji Pratik Slayt Yayıncısı - {label}")
        except Exception:
            pass

    _configure_styles(root)
    _restyle_legacy_backgrounds(root)
    _style_header_badge(root)
    _style_cards(root)
    _style_panels(root)
    _stripe_trees(root)
    _add_help_button(root)
    try:
        from .update_channel_sync import schedule_update_channel_sync
        schedule_update_channel_sync(root)
    except Exception:
        pass


def install_ui_enhancer() -> None:
    global _INSTALLED, _ORIGINAL_MAINLOOP
    if _INSTALLED:
        return
    _INSTALLED = True
    _ORIGINAL_MAINLOOP = tk.Misc.mainloop

    def enhanced_mainloop(self, n=0):
        try:
            apply_ui_enhancements(self)
        except Exception:
            # UI iyilestirmesi cekirdek programa hicbir zaman engel olmamali.
            pass
        return _ORIGINAL_MAINLOOP(self, n)

    tk.Misc.mainloop = enhanced_mainloop
