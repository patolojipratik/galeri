@echo off
setlocal
cd /d "%~dp0"
echo ONEMLI: Program kapali olmali. Once YEREL_TEMIZLIK_ONIZLE.bat ile listeyi gorun.
echo Bu islem aktif app/config/data/repos/work/.venv/guncelleme klasorlerine dokunmaz.
echo.
choice /C EH /N /M "E=Eski belge ve testleri _arsiv klasorune tasi, H=Hayir: "
if errorlevel 2 exit /b 0
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" yerel_temizlik.py --apply
) else (
  py -3 yerel_temizlik.py --apply
)
echo.
pause
