@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Bu dosya artik gerekli degil. Guncelleme kontrolu BASLAT.bat icine alindi.
echo BASLAT.bat calistiriliyor...
call BASLAT.bat
