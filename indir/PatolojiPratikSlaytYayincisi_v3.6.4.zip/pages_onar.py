"""Yayini tamamlanmamis slayt repolarinin Pages dagitimini onarir.

Kullanim:
    PAGES_ONAR.bat                       -> onarim gereken tum slaytlar
    PAGES_ONAR.bat gallery-073 gallery-074 gallery-075

Bu islem sanal slaydi yeniden donusturmez. Karolar zaten GitHub'da oldugu icin
yalnizca Pages dagitimi yeniden yapilir; yerel klasor silinmis olsa bile calisir.
"""

from __future__ import annotations

import sys

from app.config import load_settings
from app.github_api import GitHubAPI, GitHubError
from app.pages_repair import repair_all
from app.token_store import get_token


def progress(message: str, percent: int | None = None) -> None:
    print(message, flush=True)


def main() -> int:
    settings = load_settings()
    token = get_token(settings.github_username)
    if not token:
        print("GitHub tokeni bulunamadi. Once GITHUB_BAGLA.bat calistirin.")
        return 1

    api = GitHubAPI(token, settings.github_username)
    try:
        scopes = api.token_scopes()
    except Exception:
        scopes = ""
    if scopes:
        print(f"Token yetkileri: {scopes}")
        if "workflow" not in scopes:
            print(
                "UYARI: Token'da 'workflow' yetkisi gorunmuyor. Workflow dosyasi "
                "yazilamazsa onarim bu adimda duracak ve ne yapmaniz gerektigini "
                "yazacak."
            )
    print()

    targets = [a.strip() for a in sys.argv[1:] if a.strip()]
    if targets:
        print("Onarilacak: " + ", ".join(targets))
    else:
        print("Onarim gereken slaytlar taraniyor...")
    print()

    try:
        summary = repair_all(settings, api, targets or None, progress)
    except GitHubError as exc:
        print(f"\nHATA: {exc}")
        return 1

    print()
    print(
        f"Toplam: {summary['toplam']}  |  Basarili: {summary['basarili']}  "
        f"|  Basarisiz: {summary['basarisiz']}"
    )
    return 0 if summary["basarisiz"] == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
