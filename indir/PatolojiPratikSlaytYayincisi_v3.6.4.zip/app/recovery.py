from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path

from .cleanup import finish_interrupted_cleanup
from .config import Settings
from .github_api import GitHubAPI, page_probe_once
from .git_ops import run_git
from .inventory import load_rows, update_row
from .pages_retry import (
    check_or_retry_pages,
    finalize_page_verified,
    mark_pages_pending,
    was_published_recently,
)
from .receipts import load_receipt


REQUIRED_CONVERSION_FILES = (
    "index.html",
    "slide.dzi",
    "slide_files",
    "thumbnail.jpg",
    "metadata.json",
    ".conversion_complete.json",
)


def conversion_complete(repo_dir: Path) -> bool:
    for name in REQUIRED_CONVERSION_FILES:
        path = repo_dir / name
        if name == "slide_files":
            if not path.is_dir():
                return False
        elif not path.exists():
            return False
    return True


def _remove_readonly(func, path, exc_info) -> None:
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except OSError:
        raise exc_info[1]


def _safe_partial_path(settings: Settings, gallery_id: str) -> Path:
    repo_dir = (settings.repos_dir / gallery_id).resolve()
    root = settings.repos_dir.resolve()
    if repo_dir.parent != root:
        raise RuntimeError(f"Guvenli olmayan klasor yolu: {repo_dir}")
    if not gallery_id.startswith(settings.repo_prefix) or gallery_id == settings.gallery_repo:
        raise RuntimeError(f"Silinmeye uygun olmayan repo adi: {gallery_id}")
    return repo_dir


def remove_partial_repo(settings: Settings, gallery_id: str, progress=None) -> None:
    repo_dir = _safe_partial_path(settings, gallery_id)
    if not repo_dir.exists():
        return
    if progress:
        progress(f"{gallery_id}: yarim kalan yerel cikti siliniyor", None)
    shutil.rmtree(repo_dir, onerror=_remove_readonly)


def _local_head(repo_dir: Path) -> str:
    if not (repo_dir / ".git").exists():
        return ""
    result = run_git(["rev-parse", "HEAD"], repo_dir, check=False)
    return result.stdout.strip() if result.returncode == 0 else ""


def recover_interrupted(
    settings: Settings,
    api: GitHubAPI,
    token: str,
    progress=None,
) -> dict[str, int]:
    """Repair states left by a crash or power loss.

    Partial conversions are deliberately deleted and restarted from the source slide. Completed conversions
    are preserved. A Git push is treated as complete only when the remote main SHA
    matches the local commit or a previously written verification receipt.
    """
    rows = load_rows(settings)
    result = {
        "partial_deleted": 0,
        "converted_recovered": 0,
        "published_recovered": 0,
        "pages_pending_found": 0,
        "pages_retried": 0,
        "pages_verified": 0,
        "cleanup_finished": 0,
    }

    for row in rows:
        gallery_id = row.get("gallery_id", "")
        if not gallery_id:
            continue
        status = row.get("status", "")
        local_status = row.get("local_status", "")
        repo_dir = settings.repos_dir / gallery_id

        if status == "published":
            receipt = load_receipt(settings, gallery_id)
            receipt_stage = str(receipt.get("stage") or "")
            should_audit = (
                receipt_stage != "page_verified"
                and was_published_recently(
                    row,
                    int(getattr(settings, "pages_recent_audit_hours", 48)),
                )
            )
            if should_audit:
                page_url = row.get("page_url") or settings.page_url(gallery_id)
                page_probe = page_probe_once(page_url)
                if page_probe == "reachable":
                    try:
                        remote_sha = api.get_branch_sha(gallery_id, "main")
                        finalize_page_verified(
                            settings,
                            row,
                            remote_sha=remote_sha,
                            page_url=page_url,
                            note="Acilis kontrolunde GitHub Pages yayini dogrulandi.",
                        )
                        result["pages_verified"] += 1
                    except Exception:
                        pass
                elif page_probe == "not_ready":
                    local_sha = _local_head(repo_dir)
                    remote_sha = str(receipt.get("remote_sha") or row.get("last_verified_sha") or "")
                    if not remote_sha:
                        try:
                            remote_sha = api.get_branch_sha(gallery_id, "main")
                        except Exception:
                            remote_sha = ""
                    row = mark_pages_pending(
                        settings,
                        gallery_id,
                        page_url=page_url,
                        local_sha=local_sha or str(receipt.get("local_sha") or ""),
                        remote_sha=remote_sha,
                        note=(
                            "Yeni yayin Pages tarafinda acilmadi. Repo korunarak otomatik "
                            "yeniden deneme kuyruguna alindi."
                        ),
                        initial_delay=False,
                    )
                    status = "pages_pending"
                    result["pages_pending_found"] += 1
            if status == "published":
                if local_status == "cleanup_in_progress":
                    finish_interrupted_cleanup(settings, gallery_id, progress)
                    result["cleanup_finished"] += 1
                continue

        if status in ("pages_pending", "pages_error"):
            state, _updated = check_or_retry_pages(
                settings,
                api,
                token,
                row,
                progress=progress,
                wait_seconds=0,
                allow_trigger=True,
                force_trigger=True,
            )
            if state == "verified":
                result["pages_verified"] += 1
                result["published_recovered"] += 1
            elif state == "triggered":
                result["pages_retried"] += 1
            continue

        if status in ("converting", "conversion_error"):
            if conversion_complete(repo_dir):
                update_row(
                    settings,
                    gallery_id,
                    status="converted",
                    phase="converted",
                    recovery_note="Kesinti sonrasi tamamlanmis donusum bulundu.",
                    error="",
                )
                result["converted_recovered"] += 1
            else:
                if repo_dir.exists():
                    remove_partial_repo(settings, gallery_id, progress)
                    result["partial_deleted"] += 1
                update_row(
                    settings,
                    gallery_id,
                    status="pending",
                    phase="pending",
                    local_status="partial_removed",
                    recovery_note="Yarim DZI silindi; aktif slayt kaynaktan bastan donusturulecek.",
                    error="",
                )
            continue

        if status == "uploading":
            receipt = load_receipt(settings, gallery_id)
            receipt_sha = str(receipt.get("remote_sha") or "")
            local_sha = _local_head(repo_dir)
            remote_sha = ""
            try:
                if api.repo_exists(gallery_id):
                    remote_sha = api.get_branch_sha(gallery_id, "main")
            except Exception:
                remote_sha = ""

            verified_sha = ""
            if receipt_sha and remote_sha and receipt_sha.lower() == remote_sha.lower():
                verified_sha = remote_sha
            elif local_sha and remote_sha and local_sha.lower() == remote_sha.lower():
                verified_sha = remote_sha

            if verified_sha:
                if settings.pages_workflow_deploy:
                    from .pages_deploy import (
                        dispatch as _dispatch,
                        ensure_lightweight_pages_remote,
                    )

                    # Buyuk karolari Pages paketine koymadan hafif goruntuleyici
                    # ve workflow'u uzaktan hazirla.
                    ensure_lightweight_pages_remote(api, gallery_id, settings, progress)
                    page_url = settings.page_url(gallery_id)
                    try:
                        _dispatch(api, gallery_id)
                    except Exception:
                        # Bekleyen yayin kontrolu daha sonra yeniden deneyecek.
                        pass
                else:
                    page_url = api.enable_pages(gallery_id)
                api.set_repo_homepage(gallery_id, page_url)
                pending = mark_pages_pending(
                    settings,
                    gallery_id,
                    page_url=page_url,
                    local_sha=local_sha or verified_sha,
                    remote_sha=verified_sha,
                    note=(
                        "Kesinti sonrasi GitHub commit dogrulandi; Pages tarayicidan "
                        "dogrulanana kadar repo korunuyor."
                    ),
                    initial_delay=False,
                )
                state, _updated = check_or_retry_pages(
                    settings,
                    api,
                    token,
                    pending,
                    progress=progress,
                    wait_seconds=0,
                    allow_trigger=True,
                    force_trigger=True,
                )
                if state == "verified":
                    result["published_recovered"] += 1
                    result["pages_verified"] += 1
                elif state == "triggered":
                    result["pages_retried"] += 1
            elif conversion_complete(repo_dir):
                update_row(
                    settings,
                    gallery_id,
                    status="converted",
                    phase="converted",
                    recovery_note="Yarim kalan yukleme yeniden denenecek.",
                    error="",
                )
                result["converted_recovered"] += 1
            else:
                if repo_dir.exists():
                    remove_partial_repo(settings, gallery_id, progress)
                    result["partial_deleted"] += 1
                update_row(
                    settings,
                    gallery_id,
                    status="pending",
                    phase="pending",
                    local_status="partial_removed",
                    recovery_note="Yukleme sirasinda eksik yerel cikti bulundu; bastan donusturulecek.",
                    error="",
                )
            continue

        if status == "upload_error" and not conversion_complete(repo_dir):
            if repo_dir.exists():
                remove_partial_repo(settings, gallery_id, progress)
                result["partial_deleted"] += 1
            update_row(
                settings,
                gallery_id,
                status="pending",
                phase="pending",
                local_status="partial_removed",
                recovery_note="Eksik yukleme ciktilari silindi; bastan donusturulecek.",
                error="",
            )

    if progress:
        progress(
            "Kesinti kontrolu tamamlandi: "
            f"{result['partial_deleted']} yarim cikti silindi, "
            f"{result['converted_recovered']} donusum kurtarildi, "
            f"{result['published_recovered']} yayin dogrulandi, "
            f"{result['pages_retried']} Pages yeniden tetiklendi, "
            f"{result['pages_pending_found']} yeni Pages bekleme kaydi bulundu.",
            100,
        )
    return result
