from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import requests

from .config import Settings
from .github_api import GitHubAPI, GitHubError

STATE_FILENAME = "main_gallery_publish.json"
MAX_AUTOMATIC_RETRIES = 4
ACTIVE_STATUSES = {"queued", "in_progress", "waiting", "pending", "requested"}
FAILURE_CONCLUSIONS = {
    "failure",
    "cancelled",
    "timed_out",
    "startup_failure",
    "action_required",
    "stale",
}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds")


def _parse_iso(value: str) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def state_path(settings: Settings) -> Path:
    return settings.data_dir / STATE_FILENAME


def load_state(settings: Settings) -> dict[str, Any]:
    path = state_path(settings)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {}
    return data if isinstance(data, dict) else {}


def save_state(settings: Settings, state: dict[str, Any]) -> None:
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    path = state_path(settings)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def clear_state(settings: Settings) -> None:
    try:
        state_path(settings).unlink(missing_ok=True)
    except OSError:
        pass


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _next_retry_at(retry_count: int) -> str:
    # 15, 30, 60, 60 dakika. Aynı hatada peş peşe Actions koşusu başlatılmaz.
    minutes = min(60, 15 * (2 ** max(0, retry_count - 1)))
    return _iso(_now() + timedelta(minutes=minutes))


def mark_main_gallery_pending(
    settings: Settings,
    head_sha: str,
    page_url: str,
    slides_json_path: Path,
) -> dict[str, Any]:
    state: dict[str, Any] = {
        "status": "pending",
        "repo": settings.gallery_repo,
        "head_sha": str(head_sha or ""),
        "page_url": str(page_url or f"https://{settings.github_username}.github.io/{settings.gallery_repo}/"),
        "slides_sha256": _sha256_file(slides_json_path),
        "created_at": _iso(_now()),
        "updated_at": _iso(_now()),
        "retry_count": 0,
        "next_retry_at": _iso(_now() + timedelta(minutes=15)),
        "last_error": "",
        "run_id": 0,
        "run_url": "",
    }
    save_state(settings, state)
    return state


def main_gallery_is_pending(settings: Settings) -> bool:
    return bool(load_state(settings))


def main_gallery_status_text(settings: Settings) -> str:
    state = load_state(settings)
    if not state:
        return "Ana galeri yayını güncel."
    status = str(state.get("status") or "pending")
    retries = int(state.get("retry_count") or 0)
    if status == "running":
        return "Ana galeri GitHub Pages üzerinde yayımlanıyor."
    if status == "attention":
        return (
            "Ana galeri GitHub'a gönderildi ancak GitHub Actions geçici olarak tamamlayamadı. "
            "Dosyalar güvende; Ana galeriyi yayımla düğmesiyle yeniden başlatılabilir."
        )
    if retries:
        return (
            f"Ana galeri GitHub'a gönderildi; web yayını bekliyor. "
            f"GitHub geçici servis hatası nedeniyle {retries} otomatik deneme yapıldı."
        )
    return "Ana galeri GitHub'a gönderildi; web yayını doğrulanıyor."


def _public_gallery_matches(state: dict[str, Any], timeout_seconds: int = 15) -> str:
    """Return match, not_ready, or unavailable."""
    page_url = str(state.get("page_url") or "").strip()
    expected = str(state.get("slides_sha256") or "").strip().lower()
    if not page_url or not expected:
        return "not_ready"
    url = urljoin(page_url.rstrip("/") + "/", "slides.json")
    try:
        response = requests.get(
            url,
            params={"v": int(time.time())},
            timeout=max(5, int(timeout_seconds)),
            headers={"Cache-Control": "no-cache", "User-Agent": "PatolojiPratik-Gallery/3.6.4"},
        )
    except requests.RequestException:
        return "unavailable"
    if response.status_code == 200:
        actual = hashlib.sha256(response.content).hexdigest().lower()
        return "match" if actual == expected else "not_ready"
    if response.status_code in (408, 425, 429) or response.status_code >= 500:
        return "unavailable"
    return "not_ready"


def _retry_due(state: dict[str, Any], *, force: bool) -> bool:
    if force:
        return True
    due = _parse_iso(str(state.get("next_retry_at") or ""))
    return due is None or _now() >= due


def service_main_gallery_once(
    settings: Settings,
    api: GitHubAPI,
    token: str,
    progress=None,
    *,
    force: bool = False,
) -> tuple[str, dict[str, Any]]:
    """Check the central gallery deployment and safely retry transient Actions failures.

    Returns one of: idle, verified, running, pending, triggered, attention, unavailable.
    No slide repository or source file is ever deleted here.
    """
    del token  # Token is already held by the GitHubAPI session.
    state = load_state(settings)
    if not state:
        return "idle", {}

    probe = _public_gallery_matches(state)
    if probe == "match":
        clear_state(settings)
        if progress:
            progress("Ana galeri web yayını doğrulandı", 100)
        return "verified", {}

    repo = str(state.get("repo") or settings.gallery_repo)
    head_sha = str(state.get("head_sha") or "")
    run: dict[str, Any] = {}
    try:
        run = api.latest_pages_workflow_state(repo, head_sha=head_sha)
    except Exception as exc:
        state["last_error"] = f"GitHub Actions durumu alınamadı: {exc}"
        state["updated_at"] = _iso(_now())
        save_state(settings, state)
        if progress:
            progress("Ana galeri yayını kontrol edilemedi; internet/GitHub düzelince yeniden bakılacak", None)
        return "unavailable", state

    run_status = str(run.get("status") or "").lower()
    conclusion = str(run.get("conclusion") or "").lower()
    run_id = int(run.get("id") or 0)
    state["run_id"] = run_id
    state["run_url"] = str(run.get("html_url") or "")
    state["updated_at"] = _iso(_now())

    if run_status in ACTIVE_STATUSES:
        state["status"] = "running"
        state["last_error"] = ""
        save_state(settings, state)
        if progress:
            progress(f"Ana galeri yayını GitHub'da sürüyor ({run_status})", None)
        return "running", state

    if conclusion == "success":
        state["status"] = "pending"
        state["last_error"] = "Workflow tamamlandı; CDN güncellemesi bekleniyor."
        if not state.get("next_retry_at"):
            state["next_retry_at"] = _next_retry_at(max(1, int(state.get("retry_count") or 0)))
        save_state(settings, state)
        if progress:
            progress("Ana galeri workflow'u tamamlandı; web önbelleğinin güncellenmesi bekleniyor", None)
        return "pending", state

    if not _retry_due(state, force=force):
        state["status"] = "pending"
        if conclusion:
            state["last_error"] = f"GitHub Actions sonucu: {conclusion}"
        save_state(settings, state)
        return "pending", state

    retry_count = int(state.get("retry_count") or 0)
    if retry_count >= MAX_AUTOMATIC_RETRIES and not force:
        state["status"] = "attention"
        state["last_error"] = (
            state.get("last_error")
            or "GitHub Actions birden fazla otomatik denemede tamamlanamadı."
        )
        state["next_retry_at"] = ""
        save_state(settings, state)
        if progress:
            progress("Ana galeri dosyaları güvende; GitHub Actions geçici sorunu devam ediyor", 100)
        return "attention", state

    triggered = False
    method = ""
    if run_id and (conclusion in FAILURE_CONCLUSIONS or run_status == "completed"):
        try:
            triggered = api.rerun_failed_workflow(repo, run_id)
            if triggered:
                method = "başarısız GitHub Actions işi yeniden çalıştırıldı"
        except GitHubError:
            triggered = False

    if not triggered:
        # Actions rerun yetkisi/yolu kullanılamazsa yalnızca birkaç baytlık bir
        # idari commit yeni Pages koşusu başlatır. Galeri içeriği yeniden yüklenmez.
        try:
            stamp = _iso(_now()) + "\n"
            new_sha = api.upsert_text_file(
                repo,
                ".main-gallery-retry.txt",
                stamp,
                "Ana galeri Pages yeniden denemesi",
            )
            if new_sha:
                state["head_sha"] = new_sha
                triggered = True
                method = "küçük yeniden deneme commit'i gönderildi"
        except Exception as exc:
            state["last_error"] = f"GitHub yeniden denemesi başlatılamadı: {exc}"

    retry_count += 1
    state["retry_count"] = retry_count
    state["status"] = "running" if triggered else "pending"
    state["next_retry_at"] = _next_retry_at(retry_count)
    state["updated_at"] = _iso(_now())
    if triggered:
        state["last_error"] = ""
        if progress:
            progress(f"Ana galeri: {method}; sonucu arka planda izlenecek", None)
        save_state(settings, state)
        return "triggered", state

    save_state(settings, state)
    if progress:
        progress("Ana galeri yeniden denemesi başlatılamadı; dosyalar korundu", None)
    return "pending", state


def adopt_existing_main_gallery_failure(
    settings: Settings,
    api: GitHubAPI,
    progress=None,
) -> bool:
    """Start tracking a failed/running central-gallery publish created by an older app.

    This migration is intentionally conservative: it only creates state when the
    local generated slides.json exists and the newest Pages run for remote main is
    active or failed. A public gallery that already matches is immediately cleared.
    """
    if load_state(settings):
        return False
    slides_path = settings.repos_dir / settings.gallery_repo / "slides.json"
    if not slides_path.exists():
        return False
    try:
        head_sha = api.get_branch_sha(settings.gallery_repo)
        run = api.latest_pages_workflow_state(settings.gallery_repo, head_sha=head_sha)
    except Exception:
        return False
    run_status = str(run.get("status") or "").lower()
    conclusion = str(run.get("conclusion") or "").lower()
    if run_status not in ACTIVE_STATUSES and conclusion not in FAILURE_CONCLUSIONS:
        return False
    page_url = f"https://{settings.github_username}.github.io/{settings.gallery_repo}/"
    try:
        pages = api.get_pages(settings.gallery_repo) or {}
        page_url = str(pages.get("html_url") or page_url)
    except Exception:
        pass
    state = mark_main_gallery_pending(settings, head_sha, page_url, slides_path)
    state["run_id"] = int(run.get("id") or 0)
    state["run_url"] = str(run.get("html_url") or "")
    state["status"] = "running" if run_status in ACTIVE_STATUSES else "pending"
    state["last_error"] = (
        "GitHub Actions geçici hizmet hatasıyla tamamlanamadı."
        if conclusion in FAILURE_CONCLUSIONS
        else "GitHub Pages yayını sürüyor."
    )
    save_state(settings, state)
    if _public_gallery_matches(state) == "match":
        clear_state(settings)
        return False
    if progress:
        progress("Önceki ana galeri Pages hatası bulundu; otomatik izlemeye alındı", None)
    return True
