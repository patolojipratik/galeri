"""Dagitimi tamamlanmamis slayt repolarini onarir.

Onemli: Bu islem sanal slaydi YENIDEN DONUSTURMEZ. Karolar zaten GitHub'a
yuklenmis durumdadir; eksik olan yalnizca Pages dagitimidir. Bu yuzden yerel
`repos\\gallery-XXX` klasoru silinmis olsa bile onarim calisir.

Yapilan is:
  1. Pages kaynagi branch yerine workflow moduna alinir.
  2. `.github/workflows/pages.yml` dosyasi Contents API ile repoya yazilir.
  3. Workflow tetiklenir, sonucu izlenir, basarisiz olursa yeniden denenir.
  4. Sayfa tarayicidan dogrulanir ve envanter guncellenir.
"""

from __future__ import annotations

from .config import Settings
from .github_api import GitHubAPI, GitHubError, page_is_reachable
from .inventory import load_rows
from .pages_deploy import (
    WORKFLOW_SCOPE_HINT,
    deploy_with_retry,
    ensure_lightweight_pages_remote,
)
from .pages_retry import finalize_page_verified, schedule_next_retry


def candidates(settings: Settings) -> list[dict[str, str]]:
    """Onarilmasi gereken slayt satirlari.

    v3.4.1'in normal bekleme durumu `pages_pending`'dir; onarimin asil hedefi
    odur. `upload_error` satirlari dogrudan aday yapilmaz, cunku o durumda
    karolarin GitHub'a tam gitmis olmasi garanti degildir; yalnizca uzakta
    `slide.dzi` ve `index.html` gorulurse aday sayilir.
    """
    result: list[dict[str, str]] = []
    for row in load_rows(settings):
        status = str(row.get("status") or "")
        if status in ("pages_pending", "pages_error"):
            result.append(row)
        elif status == "published" and not str(row.get("page_url") or "").strip():
            result.append(row)
    return result


def upload_error_candidates(
    settings: Settings,
    api: GitHubAPI,
) -> list[dict[str, str]]:
    """Yuklemesi yarim gorunen ama uzakta icerigi tam olan satirlar.

    Bunlar ancak GitHub'da `slide.dzi` ve `index.html` dogrulandiktan sonra
    Pages onarimina alinir; aksi halde slaydin yeniden yuklenmesi gerekir.
    """
    result: list[dict[str, str]] = []
    for row in load_rows(settings):
        if str(row.get("status") or "") != "upload_error":
            continue
        gallery_id = str(row.get("gallery_id") or "")
        if not gallery_id or not api.repo_exists(gallery_id):
            continue
        try:
            has_dzi = api.get_repo_file(gallery_id, "slide.dzi") is not None
            has_index = api.get_repo_file(gallery_id, "index.html") is not None
        except GitHubError:
            continue
        if has_dzi and has_index:
            result.append(row)
    return result


def repair_one(
    settings: Settings,
    api: GitHubAPI,
    gallery_id: str,
    progress=None,
    stop_requested=None,
) -> bool:
    """Tek repoyu onar.

    Basarili sayilmasi icin hem workflow'un basariyla bitmesi hem de sayfanin
    tarayicidan gercekten acilmasi gerekir. Aksi halde satir `pages_pending`
    olarak birakilir; boylece otomatik yeniden deneme kuyrugundan dusmez ve
    dogrulanmamis slayt ana galeriye girmez.
    """
    if progress:
        progress(f"{gallery_id}: Pages dagitimi onariliyor", 0)
    if not api.repo_exists(gallery_id):
        if progress:
            progress(f"{gallery_id}: GitHub'da repo bulunamadi, atlaniyor", 100)
        return False

    # Karolari yeniden donusturmeden Pages artifact'ini kucult: index/thumbnail
    # dagitilir, karolar GitHub reposundan talep edildikce okunur.
    ensure_lightweight_pages_remote(api, gallery_id, settings, progress)
    ok, run_url = deploy_with_retry(api, gallery_id, settings, progress, stop_requested)

    page_url = settings.page_url(gallery_id)
    reachable = False
    if ok:
        reachable = page_is_reachable(page_url, settings.verify_pages_seconds, progress)

    if ok and reachable:
        row = next(
            (item for item in load_rows(settings) if item.get("gallery_id") == gallery_id),
            {"gallery_id": gallery_id},
        )
        remote_sha = api.get_branch_sha(gallery_id, "main")
        finalize_page_verified(
            settings,
            row,
            remote_sha=remote_sha,
            page_url=page_url,
            note="Pages onarimi tamamlandi ve yayin tarayicidan dogrulandi.",
        )
        if progress:
            progress(f"{gallery_id}: yayin dogrulandi - {page_url}", 100)
        return True

    if ok and not reachable:
        note = "Workflow tamamlandi ancak sayfa henuz cevap vermedi; bekleme suruyor."
    else:
        note = f"Pages dagitimi tamamlanamadi. Kosu kaydi: {run_url or '-'}"

    schedule_next_retry(settings, gallery_id, note, progress)
    if progress:
        progress(f"{gallery_id}: dogrulanmadi, bekleyen yayin kuyrugunda birakildi", 100)
    return False


def repair_all(
    settings: Settings,
    api: GitHubAPI,
    gallery_ids: list[str] | None = None,
    progress=None,
    stop_requested=None,
) -> dict[str, int]:
    """Birden cok repoyu sirayla onar."""
    if gallery_ids:
        # Elle yazilan repo adlarini yalnizca yerel envanterde bulunan, beklenen
        # gallery-XXX bicimindeki slayt kayitlariyla sinirla. Bir yazim hatasi
        # ana galeriye veya baska bir repoya istek gondermemelidir.
        inventory_ids = {
            str(row.get("gallery_id") or "")
            for row in load_rows(settings)
            if str(row.get("gallery_id") or "")
        }
        targets = []
        seen: set[str] = set()
        for raw_id in gallery_ids:
            gallery_id = str(raw_id or "").strip()
            valid_shape = (
                gallery_id.startswith(settings.repo_prefix)
                and gallery_id != settings.gallery_repo
                and gallery_id[len(settings.repo_prefix):].isdigit()
            )
            if not valid_shape or gallery_id not in inventory_ids:
                if progress:
                    progress(
                        f"{gallery_id or '-'}: envanterde guvenli bir slayt kaydi degil; atlandi",
                        100,
                    )
                continue
            if gallery_id not in seen:
                seen.add(gallery_id)
                targets.append(gallery_id)
    else:
        rows = candidates(settings)
        # upload_error ancak uzakta hem slide.dzi hem index.html dogrulanirsa
        # Pages onarimina dahil edilir; yarim yukleme asla yayinlanmaz.
        rows.extend(upload_error_candidates(settings, api))
        seen: set[str] = set()
        targets = []
        for row in rows:
            gallery_id = str(row.get("gallery_id") or "")
            if gallery_id and gallery_id not in seen:
                seen.add(gallery_id)
                targets.append(gallery_id)

    summary = {"toplam": len(targets), "basarili": 0, "basarisiz": 0}
    if not targets:
        if progress:
            progress("Onarim gerektiren slayt bulunamadi.", 100)
        return summary

    for gallery_id in targets:
        if stop_requested is not None and stop_requested():
            break
        try:
            if repair_one(settings, api, gallery_id, progress, stop_requested):
                summary["basarili"] += 1
            else:
                summary["basarisiz"] += 1
        except Exception as exc:
            summary["basarisiz"] += 1
            # Hata ne olursa olsun repo ve yerel cikti korunur. Kayit
            # pages_pending kalir ve acilista/sonraki kontrolde yeniden denenir.
            schedule_next_retry(
                settings,
                gallery_id,
                f"Pages onarimi gecici olarak basarisiz: {exc}",
                progress,
            )
            if progress:
                progress(f"{gallery_id}: onarim hatasi - repo korundu; {exc}", 100)
            # Yetki hatasi tum repolarda ayni olacagi icin dongu durdurulur.
            if WORKFLOW_SCOPE_HINT[:40] in str(exc):
                break
    return summary
