from __future__ import annotations

import traceback
from pathlib import Path

from .cleanup import cleanup_all_published, cleanup_published_repo
from .config import Settings
from .gallery_builder import publish_gallery
from .github_api import GitHubAPI
from .git_ops import prepare_and_push
from .inventory import increment_attempt, load_rows, next_row, scan_sources, update_row
from .kfb_converter import convert_slide
from .main_gallery_retry import service_main_gallery_once
from .pages_deploy import dispatch, ensure_workflow_pages, write_workflow
from .pages_retry import check_or_retry_pages, mark_pages_pending, pending_page_rows
from .receipts import write_receipt
from .slide_manager import recover_pending_deletions
from .recovery import recover_interrupted, remove_partial_repo
from .token_store import get_token
from .utils import directory_size, sha256_file


class Pipeline:
    def __init__(self, settings: Settings, progress=None, stop_requested=None) -> None:
        self.settings = settings
        self.progress = progress or (lambda message, percent=None: None)
        self.stop_requested = stop_requested or (lambda: False)
        token = get_token(settings.github_username)
        if not token:
            raise RuntimeError("GitHub tokeni bulunamadi. Once GitHub Bagla islemini yapin.")
        self.token = token
        self.api = GitHubAPI(token, settings.github_username)
        self._recovered_once = False

    def inventory(self):
        rows = scan_sources(self.settings)
        self.progress(f"{len(rows)} slayt kaydi hazir.", 100)
        return rows

    def recover(self) -> dict[str, int]:
        deleted_recovered = recover_pending_deletions(self.settings, self.api, self.progress)
        summary = recover_interrupted(self.settings, self.api, self.token, self.progress)
        summary["deleted_recovered"] = deleted_recovered
        self._recovered_once = True
        if deleted_recovered or any(row.get("status") == "published" for row in load_rows(self.settings)):
            self.progress("Yayin listesi ana galeri ile eslestiriliyor", None)
            publish_gallery(self.settings, self.token, self.api, self.progress)
        if self.settings.cleanup_published_repos:
            cleanup_all_published(self.settings, self.api, self.progress)
        return summary

    def _cleanup_verified_publication(self, gallery_id: str) -> None:
        if not self.settings.cleanup_published_repos:
            return
        try:
            cleanup_published_repo(
                self.settings,
                self.api,
                gallery_id,
                self.progress,
            )
        except Exception as cleanup_exc:
            update_row(
                self.settings,
                gallery_id,
                local_status="cleanup_error",
                recovery_note=f"Yerel temizlik yeniden denenecek: {cleanup_exc}",
            )
            self.progress(
                f"{gallery_id}: yayin dogrulandi ancak yerel klasor silinemedi: {cleanup_exc}",
                100,
            )

    def _service_one_pending_pages(self) -> dict | None:
        for row in pending_page_rows(self.settings):
            state, updated = check_or_retry_pages(
                self.settings,
                self.api,
                self.token,
                row,
                progress=self.progress,
                wait_seconds=0,
                allow_trigger=True,
            )
            if state == "verified":
                self.progress(f"{row['gallery_id']}: ana galeriye ekleniyor", None)
                publish_gallery(self.settings, self.token, self.api, self.progress)
                self._cleanup_verified_publication(row["gallery_id"])
                return updated
            if state in {"triggered", "error"}:
                return updated
            # Not due yet: leave it safely pending and process a new slide instead.
        return None

    def service_pending_pages_once(self) -> dict | None:
        """Check/repair one due Pages publication without starting a new slide."""
        return self._service_one_pending_pages()

    def _limit_bytes(self) -> int:
        return int(self.settings.max_repo_size_mb) * 1024 * 1024

    def _repo_size_mb(self, repo_dir: Path) -> float:
        return directory_size(repo_dir) / 1024 / 1024

    def _convert_with_automatic_size_control(
        self,
        source: Path,
        repo_dir: Path,
        gallery_id: str,
    ) -> tuple[float, int]:
        """Build a DZI repository and automatically reduce JPEG quality if needed."""
        quality = int(self.settings.jpeg_quality)
        min_quality = int(self.settings.min_jpeg_quality)
        step = int(self.settings.jpeg_quality_step)
        limit_mb = float(self.settings.max_repo_size_mb)

        while True:
            if repo_dir.exists():
                remove_partial_repo(self.settings, gallery_id, self.progress)

            self.progress(
                f"{gallery_id}: JPEG kalite {quality} ile DZI hazirlaniyor",
                0,
            )
            convert_slide(
                source,
                repo_dir,
                self.settings,
                self.progress,
                self.stop_requested,
                jpeg_quality=quality,
            )
            size_mb = self._repo_size_mb(repo_dir)
            self.progress(
                f"{gallery_id}: cikti {size_mb:.1f} MB (hedef en fazla {limit_mb:.0f} MB)",
                100,
            )
            if size_mb <= limit_mb:
                return size_mb, quality

            if not self.settings.auto_reduce_jpeg_quality or quality <= min_quality:
                raise RuntimeError(
                    f"Repo ciktisi {size_mb:.1f} MB; otomatik kucultme alt sinira "
                    f"(JPEG kalite {quality}) ulasti."
                )

            next_quality = max(min_quality, quality - step)
            if next_quality == quality:
                raise RuntimeError(
                    f"Repo ciktisi {size_mb:.1f} MB; JPEG kalitesi daha fazla dusurulemiyor."
                )
            self.progress(
                f"{gallery_id}: {size_mb:.1f} MB fazla buyuk. "
                f"Kalite {quality} -> {next_quality}; cikti silinip otomatik yeniden olusturulacak.",
                None,
            )
            quality = next_quality

    def _conversion_needs_rebuild(self, row: dict, repo_dir: Path) -> bool:
        if row.get("status") not in ("converted", "upload_error"):
            return True
        if not repo_dir.exists():
            return True
        size_mb = self._repo_size_mb(repo_dir)
        if size_mb > float(self.settings.max_repo_size_mb):
            self.progress(
                f"{row['gallery_id']}: mevcut cikti {size_mb:.1f} MB. "
                "Otomatik daha kucuk yeniden donusum yapilacak.",
                None,
            )
            return True
        return False

    def process_one(self) -> dict | None:
        scan_sources(self.settings)
        if not self._recovered_once:
            self.recover()
        pages_result = self._service_one_pending_pages()
        if pages_result is not None:
            return pages_result
        row = next_row(self.settings)
        if row is None:
            pages_waiting = pending_page_rows(self.settings)
            if pages_waiting:
                self.progress(
                    f"Donusum kuyrugu tamamlandi; {len(pages_waiting)} slayt Pages dogrulamasi bekliyor. "
                    "Repo korunuyor ve sonraki acilista yeniden kontrol edilecek.",
                    100,
                )
            else:
                self.progress("Bekleyen slayt kalmadi.", 100)
            return None
        gallery_id = row["gallery_id"]
        source = Path(row["source_path"])
        repo_dir = self.settings.repos_dir / gallery_id
        phase = "conversion"
        try:
            if self._conversion_needs_rebuild(row, repo_dir):
                attempt = increment_attempt(self.settings, gallery_id)
                update_row(
                    self.settings,
                    gallery_id,
                    status="converting",
                    phase="conversion",
                    error="",
                    recovery_note="",
                )
                if self.settings.compute_sha256 and not row.get("sha256"):
                    digest = sha256_file(source, self.progress)
                    update_row(self.settings, gallery_id, sha256=digest)
                self.progress(f"{gallery_id}: {source.suffix.upper().lstrip('.')} donusturuluyor (deneme {attempt})", 0)
                size_mb, used_quality = self._convert_with_automatic_size_control(
                    source,
                    repo_dir,
                    gallery_id,
                )
                update_row(
                    self.settings,
                    gallery_id,
                    status="converted",
                    phase="converted",
                    error="",
                    recovery_note=(
                        f"DZI {size_mb:.1f} MB, JPEG kalite {used_quality} ile hazirlandi."
                    ),
                )

            # Recheck immediately before Git to protect recovered/older outputs.
            size_mb = self._repo_size_mb(repo_dir)
            if size_mb > float(self.settings.max_repo_size_mb):
                self.progress(
                    f"{gallery_id}: yukleme oncesi boyut {size_mb:.1f} MB; "
                    "otomatik yeniden kucultuluyor.",
                    None,
                )
                update_row(
                    self.settings,
                    gallery_id,
                    status="converting",
                    phase="conversion",
                    error="",
                )
                size_mb, used_quality = self._convert_with_automatic_size_control(
                    source,
                    repo_dir,
                    gallery_id,
                )
                update_row(
                    self.settings,
                    gallery_id,
                    status="converted",
                    phase="converted",
                    recovery_note=(
                        f"DZI {size_mb:.1f} MB, JPEG kalite {used_quality} ile yeniden hazirlandi."
                    ),
                    error="",
                )

            if self.stop_requested():
                self.progress(
                    f"{gallery_id}: donusum tamamlandi; yukleme kullanici istegiyle bekletildi.",
                    100,
                )
                return row

            phase = "upload"
            update_row(
                self.settings,
                gallery_id,
                status="uploading",
                phase="git_upload",
                error="",
            )
            self.api.create_public_repo(
                gallery_id,
                f"Patoloji pratik sanal mikroskop - {gallery_id}",
            )
            # Pages dagitim workflow'u repo icerigiyle birlikte gonderilir.
            if self.settings.pages_workflow_deploy:
                write_workflow(repo_dir, self.settings)
            local_sha = prepare_and_push(
                repo_dir,
                gallery_id,
                self.settings,
                self.token,
                f"{gallery_id} sanal mikroskop yayini",
                self.progress,
            )
            remote_sha = self.api.get_branch_sha(gallery_id, "main")
            if not local_sha or local_sha.lower() != remote_sha.lower():
                raise RuntimeError(
                    "GitHub yuklemesi commit dogrulamasindan gecemedi. "
                    f"Yerel: {local_sha or '-'} | GitHub: {remote_sha or '-'}"
                )
            write_receipt(
                self.settings,
                gallery_id,
                stage="commit_verified",
                local_sha=local_sha,
                remote_sha=remote_sha,
            )
            update_row(
                self.settings,
                gallery_id,
                phase="remote_verified",
                last_verified_sha=remote_sha,
            )
            self.progress(f"{gallery_id}: GitHub commit dogrulandi", 100)

            if self.settings.pages_workflow_deploy:
                # Pages'e yalnizca hafif goruntuleyici kabugu dagitilir. DZI
                # karolari GitHub reposunda kalir ve ziyaret sirasinda okunur.
                page_url = ensure_workflow_pages(self.api, gallery_id, self.progress)
                try:
                    dispatch(self.api, gallery_id)
                except Exception as exc:
                    self.progress(
                        f"{gallery_id}: Pages workflow'u simdi tetiklenemedi, "
                        f"bekleyen kontrolde yeniden denenecek ({exc})",
                        None,
                    )
            else:
                page_url = self.api.enable_pages(gallery_id)
            self.api.set_repo_homepage(gallery_id, page_url)
            pending_row = mark_pages_pending(
                self.settings,
                gallery_id,
                page_url=page_url,
                local_sha=local_sha,
                remote_sha=remote_sha,
                note=(
                    "GitHub commit dogrulandi. Pages yayini kuyrukta; "
                    "dogrulanana kadar GitHub ve yerel repo korunacak."
                ),
                initial_delay=True,
            )
            self.progress(
                f"{gallery_id}: GitHub Pages yayini tarayicidan dogrulaniyor; repo korunuyor",
                None,
            )
            state, updated = check_or_retry_pages(
                self.settings,
                self.api,
                self.token,
                pending_row,
                progress=self.progress,
                wait_seconds=self.settings.verify_pages_seconds,
                allow_trigger=False,
            )
            if state == "verified":
                self.progress(f"{gallery_id}: ana galeri guncelleniyor", None)
                publish_gallery(self.settings, self.token, self.api, self.progress)
                self._cleanup_verified_publication(gallery_id)
                return updated

            self.progress(
                f"{gallery_id}: Pages henuz acilmadi. Repo SILINMEDI; "
                "15 dakika sonra veya program yeniden acildiginda kontrol edilip tetiklenecek.",
                100,
            )
            return updated
        except Exception as exc:
            status = "upload_error" if phase == "upload" else "conversion_error"
            update_row(
                self.settings,
                gallery_id,
                status=status,
                phase=phase,
                error=f"{exc}\n{traceback.format_exc(limit=4)}",
            )
            raise

    def publish_main_gallery(self) -> str:
        return publish_gallery(self.settings, self.token, self.api, self.progress)

    def service_main_gallery_once(self, *, force: bool = False):
        return service_main_gallery_once(
            self.settings,
            self.api,
            self.token,
            self.progress,
            force=force,
        )

    def cleanup_local_published(self):
        return cleanup_all_published(
            self.settings,
            self.api,
            self.progress,
        )
