from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Callable

from .config import Settings
from .inventory import load_rows, update_metadata_fields


class MetadataEditor(tk.Toplevel):
    """Local, quote-free editor for public slide names and descriptions."""

    def __init__(
        self,
        parent: tk.Misc,
        settings: Settings,
        *,
        selected_gallery_id: str = "",
        on_saved: Callable[[], None] | None = None,
        on_publish: Callable[[], None] | None = None,
    ) -> None:
        super().__init__(parent)
        self.parent = parent
        self.settings = settings
        self.on_saved = on_saved
        self.on_publish = on_publish
        self.rows: list[dict[str, str]] = []
        self.filtered: list[dict[str, str]] = []
        self.current_id = ""
        self._loading = False
        self._dirty = False
        self._restoring_selection = False

        self.title("Slayt Bilgilerini Düzenle")
        self.geometry("1180x720")
        self.minsize(980, 640)
        self.configure(bg="#eef2f7")
        self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self.close)

        self._configure_styles()
        self._build()
        self.reload_rows(selected_gallery_id)
        self.bind("<Control-s>", lambda _event: self.save_current())
        self.bind("<Control-Prior>", lambda _event: self.save_and_move(-1))
        self.bind("<Control-Next>", lambda _event: self.save_and_move(1))
        self.bind("<Escape>", lambda _event: self.close())
        self.grab_set()
        self.focus_force()

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        style.configure("Editor.TFrame", background="#eef2f7")
        style.configure("EditorCard.TFrame", background="white")
        style.configure(
            "EditorTitle.TLabel",
            background="#102847",
            foreground="white",
            font=("Segoe UI", 17, "bold"),
        )
        style.configure(
            "EditorSub.TLabel",
            background="#102847",
            foreground="#cfdaea",
            font=("Segoe UI", 9),
        )
        style.configure("Editor.Treeview", rowheight=29, font=("Segoe UI", 9))
        style.configure("Editor.Treeview.Heading", font=("Segoe UI", 9, "bold"))
        style.configure("EditorPrimary.TButton", font=("Segoe UI", 10, "bold"), padding=(13, 9))
        style.configure("EditorSecondary.TButton", font=("Segoe UI", 10), padding=(11, 8))

    def _build(self) -> None:
        header = tk.Frame(self, bg="#102847", padx=20, pady=14)
        header.pack(fill="x")
        tk.Label(
            header,
            text="Slayt Bilgilerini Düzenle",
            bg="#102847",
            fg="white",
            font=("Segoe UI", 17, "bold"),
        ).pack(anchor="w")
        tk.Label(
            header,
            text=(
                "Başlık, organ, tanı, açıklama ve etiketleri burada yazın. "
                "Virgül ve tırnak işaretleri otomatik olarak güvenli kaydedilir."
            ),
            bg="#102847",
            fg="#cfdaea",
            font=("Segoe UI", 9),
        ).pack(anchor="w", pady=(3, 0))

        body = ttk.Frame(self, style="Editor.TFrame", padding=14)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=2)
        body.columnconfigure(1, weight=3)
        body.rowconfigure(0, weight=1)

        left = tk.Frame(body, bg="white", bd=1, relief="solid")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        search_bar = tk.Frame(left, bg="white", padx=10, pady=9)
        search_bar.pack(fill="x")
        tk.Label(search_bar, text="Ara", bg="white", fg="#4b5d73").pack(side="left")
        self.search_var = tk.StringVar()
        search = ttk.Entry(search_bar, textvariable=self.search_var)
        search.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.search_var.trace_add("write", lambda *_: self._fill_list())

        columns = ("no", "gallery", "name")
        self.tree = ttk.Treeview(
            left,
            columns=columns,
            show="headings",
            selectmode="browse",
            style="Editor.Treeview",
        )
        self.tree.heading("no", text="Sıra")
        self.tree.heading("gallery", text="Repo")
        self.tree.heading("name", text="Tanı / başlık")
        self.tree.column("no", width=48, stretch=False)
        self.tree.column("gallery", width=105, stretch=False)
        self.tree.column("name", width=270, stretch=True)
        scroll = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=(0, 8))
        scroll.pack(side="right", fill="y", padx=(0, 8), pady=(0, 8))
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        right = tk.Frame(body, bg="white", bd=1, relief="solid", padx=18, pady=14)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(1, weight=1)
        right.rowconfigure(4, weight=1)

        self.identity_var = tk.StringVar(value="Bir slayt seçin")
        tk.Label(
            right,
            textvariable=self.identity_var,
            bg="white",
            fg="#17375e",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
        ).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 12))

        self.title_var = tk.StringVar()
        self.organ_var = tk.StringVar()
        self.tags_var = tk.StringVar()
        for var in (self.title_var, self.organ_var, self.tags_var):
            var.trace_add("write", lambda *_: self._mark_dirty())

        self._add_entry(right, 1, "Başlık", self.title_var)
        self._add_entry(right, 2, "Organ / sistem", self.organ_var)

        tk.Label(right, text="Tanı", bg="white", fg="#3e5067", anchor="nw").grid(
            row=3, column=0, sticky="nw", padx=(0, 12), pady=(5, 8)
        )
        self.diagnosis_text = tk.Text(
            right,
            height=4,
            wrap="word",
            font=("Segoe UI", 10),
            relief="solid",
            bd=1,
            padx=8,
            pady=7,
            undo=True,
        )
        self.diagnosis_text.grid(row=3, column=1, sticky="ew", pady=(5, 8))

        tk.Label(right, text="Açıklama", bg="white", fg="#3e5067", anchor="nw").grid(
            row=4, column=0, sticky="nw", padx=(0, 12), pady=(5, 8)
        )
        self.description_text = tk.Text(
            right,
            height=10,
            wrap="word",
            font=("Segoe UI", 10),
            relief="solid",
            bd=1,
            padx=8,
            pady=7,
            undo=True,
        )
        self.description_text.grid(row=4, column=1, sticky="nsew", pady=(5, 8))

        self._add_entry(right, 5, "Etiketler", self.tags_var, sticky="new")
        tk.Label(
            right,
            text="Etiketleri virgülle ayırın: mide, adenokarsinom, H&E. Tırnak yazmanız gerekmez.",
            bg="white",
            fg="#728096",
            font=("Segoe UI", 8),
            anchor="w",
        ).grid(row=6, column=1, sticky="ew", pady=(0, 8))

        for widget in (self.diagnosis_text, self.description_text):
            widget.bind("<<Modified>>", self._text_modified)

        self.status_var = tk.StringVar(value="Değişiklik yok")
        tk.Label(
            right,
            textvariable=self.status_var,
            bg="white",
            fg="#617087",
            font=("Segoe UI", 9),
            anchor="w",
        ).grid(row=7, column=0, columnspan=2, sticky="ew", pady=(8, 10))

        buttons = tk.Frame(right, bg="white")
        buttons.grid(row=8, column=0, columnspan=2, sticky="ew")

        navigation = tk.Frame(buttons, bg="white")
        navigation.pack(fill="x")
        ttk.Button(
            navigation,
            text="← Kaydet ve Öncekine Geç",
            command=lambda: self.save_and_move(-1),
            style="EditorSecondary.TButton",
        ).pack(side="left")
        ttk.Button(
            navigation,
            text="Kaydet",
            command=self.save_current,
            style="EditorPrimary.TButton",
        ).pack(side="left", padx=8)
        ttk.Button(
            navigation,
            text="Kaydet ve Sonrakine Geç →",
            command=lambda: self.save_and_move(1),
            style="EditorSecondary.TButton",
        ).pack(side="left")

        publishing = tk.Frame(buttons, bg="white")
        publishing.pack(fill="x", pady=(9, 0))
        ttk.Button(
            publishing,
            text="Kaydet ve İnternette Yayınla",
            command=self.save_and_publish,
            style="EditorPrimary.TButton",
        ).pack(side="left")
        ttk.Button(
            publishing,
            text="Kapat",
            command=self.close,
            style="EditorSecondary.TButton",
        ).pack(side="right")

    def _add_entry(
        self,
        parent: tk.Widget,
        row: int,
        label: str,
        variable: tk.StringVar,
        *,
        sticky: str = "ew",
    ) -> None:
        tk.Label(parent, text=label, bg="white", fg="#3e5067", anchor="w").grid(
            row=row, column=0, sticky="nw", padx=(0, 12), pady=(5, 8)
        )
        ttk.Entry(parent, textvariable=variable, font=("Segoe UI", 10)).grid(
            row=row, column=1, sticky=sticky, pady=(5, 8)
        )

    def reload_rows(self, selected_gallery_id: str = "") -> None:
        self.rows = load_rows(self.settings)
        self.rows.sort(
            key=lambda row: (
                int(row.get("display_order") or row.get("number") or 0),
                int(row.get("number") or 0),
            )
        )
        self._fill_list(selected_gallery_id or self.current_id)

    def _fill_list(self, selected_gallery_id: str = "") -> None:
        term = self.search_var.get().strip().casefold()
        self.filtered = []
        current = selected_gallery_id or self.current_id
        for item in self.tree.get_children():
            self.tree.delete(item)
        for row in self.rows:
            searchable = " ".join(
                row.get(field, "")
                for field in (
                    "gallery_id",
                    "source_name",
                    "title",
                    "organ",
                    "diagnosis",
                    "description",
                    "tags",
                )
            ).casefold()
            if term and term not in searchable:
                continue
            self.filtered.append(row)
            item = self.tree.insert(
                "",
                "end",
                iid=row.get("gallery_id", ""),
                values=(
                    row.get("display_order") or row.get("number", ""),
                    row.get("gallery_id", ""),
                    row.get("diagnosis") or row.get("title") or "—",
                ),
            )
            if row.get("gallery_id") == current:
                self.tree.selection_set(item)
                self.tree.see(item)
        if not self.tree.selection() and self.filtered:
            first = self.filtered[0].get("gallery_id", "")
            if first:
                self.tree.selection_set(first)
                self.tree.see(first)

    def _on_select(self, _event=None) -> None:
        if self._restoring_selection:
            return
        selection = self.tree.selection()
        if not selection:
            return
        new_id = str(selection[0])
        if new_id == self.current_id:
            return
        if self._dirty and self.current_id:
            answer = messagebox.askyesnocancel(
                "Kaydedilmemiş değişiklik",
                "Geçerli slayttaki değişiklikler kaydedilsin mi?",
                parent=self,
            )
            if answer is None:
                self._restoring_selection = True
                try:
                    self.tree.selection_set(self.current_id)
                    self.tree.see(self.current_id)
                finally:
                    self._restoring_selection = False
                return
            if answer:
                self.save_current()
        self._load_row(new_id)

    def _load_row(self, gallery_id: str) -> None:
        row = next((item for item in self.rows if item.get("gallery_id") == gallery_id), None)
        if row is None:
            return
        self._loading = True
        try:
            self.current_id = gallery_id
            self.identity_var.set(
                f"{gallery_id}  •  {row.get('source_name', '')}  •  {row.get('status', '')}"
            )
            self.title_var.set(row.get("title", ""))
            self.organ_var.set(row.get("organ", ""))
            self.tags_var.set(row.get("tags", ""))
            self._set_text(self.diagnosis_text, row.get("diagnosis", ""))
            self._set_text(self.description_text, row.get("description", ""))
            self.status_var.set("Değişiklik yok")
            self._dirty = False
        finally:
            self._loading = False
            self.diagnosis_text.edit_modified(False)
            self.description_text.edit_modified(False)

    @staticmethod
    def _set_text(widget: tk.Text, value: str) -> None:
        widget.delete("1.0", "end")
        widget.insert("1.0", value)

    def _text_modified(self, event) -> None:
        widget = event.widget
        if widget.edit_modified():
            self._mark_dirty()
            widget.edit_modified(False)

    def _mark_dirty(self) -> None:
        if self._loading or not self.current_id:
            return
        self._dirty = True
        self.status_var.set("Kaydedilmemiş değişiklik var")

    def _values(self) -> dict[str, str]:
        return {
            "title": self.title_var.get(),
            "organ": self.organ_var.get(),
            "diagnosis": self.diagnosis_text.get("1.0", "end-1c"),
            "description": self.description_text.get("1.0", "end-1c"),
            "tags": self.tags_var.get(),
        }

    def save_current(self) -> bool:
        if not self.current_id:
            messagebox.showinfo("Slayt seçin", "Önce soldan bir slayt seçin.", parent=self)
            return False
        if not self._dirty:
            self.status_var.set("Değişiklik yok; mevcut bilgiler korunuyor.")
            return True
        try:
            updated = update_metadata_fields(self.settings, self.current_id, self._values())
            for index, row in enumerate(self.rows):
                if row.get("gallery_id") == self.current_id:
                    self.rows[index] = updated
                    break
            self._dirty = False
            self.status_var.set(
                "Kaydedildi. Otomatik tarih damgalı yedek data\\yedek klasörüne alındı."
            )
            if self.tree.exists(self.current_id):
                self.tree.item(
                    self.current_id,
                    values=(
                        updated.get("display_order") or updated.get("number", ""),
                        updated.get("gallery_id", ""),
                        updated.get("diagnosis") or updated.get("title") or "—",
                    ),
                )
            if self.on_saved:
                self.on_saved()
            return True
        except Exception as exc:
            messagebox.showerror("Kaydetme hatası", str(exc), parent=self)
            return False

    def save_and_move(self, direction: int) -> None:
        """Save the current slide and move within the visible filtered list."""
        if not self.current_id or not self.save_current():
            return

        visible_ids = [
            row.get("gallery_id", "")
            for row in self.filtered
            if row.get("gallery_id", "")
        ]
        if self.current_id not in visible_ids:
            visible_ids = [
                row.get("gallery_id", "")
                for row in self.rows
                if row.get("gallery_id", "")
            ]
        if self.current_id not in visible_ids:
            return

        current_index = visible_ids.index(self.current_id)
        target_index = current_index + (1 if direction > 0 else -1)
        if target_index < 0:
            self.status_var.set("İlk slayttasınız; bilgiler kaydedildi.")
            return
        if target_index >= len(visible_ids):
            self.status_var.set("Son slayttasınız; bilgiler kaydedildi.")
            return

        target_id = visible_ids[target_index]
        self._restoring_selection = True
        try:
            self.tree.selection_set(target_id)
            self.tree.focus(target_id)
            self.tree.see(target_id)
        finally:
            self._restoring_selection = False
        self._load_row(target_id)

    def save_and_publish(self) -> None:
        if not self.save_current():
            return
        callback = self.on_publish
        self.grab_release()
        self.destroy()
        if callback:
            self.parent.after(100, callback)

    def close(self) -> None:
        if self._dirty:
            answer = messagebox.askyesnocancel(
                "Kaydedilmemiş değişiklik",
                "Değişiklikler kaydedilsin mi?",
                parent=self,
            )
            if answer is None:
                return
            if answer and not self.save_current():
                return
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()
