from __future__ import annotations

import json
import os
import shutil
import stat
import time
from pathlib import Path
from typing import Any

from .config import Settings
from .github_api import GitHubAPI
from .inventory import load_rows, remove_row, update_row
from .receipts import receipt_path
from .utils import atomic_write_json, now_iso


def _journal_dir(settings: Settings) -> Path:
    path = settings.data_dir / "silme_bekleyen"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _journal_path(settings: Settings, gallery_id: str) -> Path:
    return _journal_dir(settings) / f"{gallery_id}.json"


def _audit_dir(settings: Settings) -> Path:
    path = settings.data_dir / "silinen_slaytlar"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _validate_gallery_id(settings: Settings, gallery_id: str) -> None:
    expected_prefix = str(settings.repo_prefix or "gallery-")
    if not gallery_id.startswith(expected_prefix):
        raise RuntimeError(f"Silinmeye uygun olmayan repo adi: {gallery_id}")
    if gallery_id == settings.gallery_repo:
        raise RuntimeError("Ana galeri reposu bu islemle silinemez.")
    suffix = gallery_id[len(expected_prefix) :]
    if not suffix.isdigit():
        raise RuntimeError(f"Silinmeye uygun olmayan repo adi: {gallery_id}")


def _safe_child(root: Path, child: Path) -> Path:
    root_resolved = root.resolve()
    child_resolved = child.resolve(strict=False)
    if child_resolved.parent != root_resolved:
        raise RuntimeError(f"Guvenli olmayan klasor yolu: {child}")
    return child


def _remove_readonly(func, path, exc_info) -> None:
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except OSError:
        raise exc_info[1]


def _unique_destination(settings: Settings, source: Path, gallery_id: str) -> Path:
    settings.rejected_path.mkdir(parents=True, exist_ok=True)
    destination = settings.rejected_path / source.name
    if not destination.exists():
        return destination
    stamp = time.strftime("%Y%m%d_%H%M%S")
    return settings.rejected_path / f"{source.stem}__{gallery_id}_{stamp}{source.suffix}"


def _write_journal(settings: Settings, gallery_id: str, payload: dict[str, Any]) -> Path:
    payload = dict(payload)
    payload["gallery_id"] = gallery_id
    payload["updated_at"] = now_iso()
    path = _journal_path(settings, gallery_id)
    atomic_write_json(path, payload)
    return path


def _read_journal(settings: Settings, gallery_id: str) -> dict[str, Any]:
    path = _journal_path(settings, gallery_id)
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _cleanup_local_artifacts(settings: Settings, gallery_id: str) -> None:
    for root in (settings.repos_dir, settings.work_dir):
        target = _safe_child(root, root / gallery_id)
        if target.exists():
            shutil.rmtree(target, onerror=_remove_readonly)

    gallery_thumb = settings.repos_dir / settings.gallery_repo / "thumbs" / f"{gallery_id}.jpg"
    try:
        gallery_thumb.unlink(missing_ok=True)
    except OSError:
        pass
    try:
        receipt_path(settings, gallery_id).unlink(missing_ok=True)
    except OSError:
        pass


def _finish_delete(
    settings: Settings,
    api: GitHubAPI,
    gallery_id: str,
    row: dict[str, str],
    journal: dict[str, Any],
    progress=None,
) -> Path | None:
    _validate_gallery_id(settings, gallery_id)
    source_original = Path(str(journal.get("source_original") or row.get("source_path") or ""))
    destination_text = str(journal.get("destination") or "")
    destination = Path(destination_text) if destination_text else None

    if source_original and source_original.name:
        source_root = settings.source_path.resolve()
        if source_original.exists() and source_original.resolve().parent != source_root:
            # Recovery may already point at the quarantine copy.
            if source_original.resolve().parent != settings.rejected_path.resolve():
                raise RuntimeError(f"Kaynak dosya beklenmeyen klasorde: {source_original}")
        if destination is None:
            destination = _unique_destination(settings, source_original, gallery_id)

    if destination is not None:
        settings.rejected_path.mkdir(parents=True, exist_ok=True)
        if source_original.exists() and source_original.resolve() != destination.resolve(strict=False):
            if destination.exists():
                destination = _unique_destination(settings, source_original, gallery_id)
            if progress:
                progress(f"{gallery_id}: kaynak dosya yüklenmeyen klasorune tasiniyor", None)
            shutil.move(str(source_original), str(destination))
        _write_journal(
            settings,
            gallery_id,
            {
                **journal,
                "stage": "source_moved",
                "source_original": str(source_original),
                "destination": str(destination),
                "row": row,
            },
        )
        # The row remains hidden from the processing queue if a network error occurs.
        try:
            update_row(
                settings,
                gallery_id,
                status="deleting",
                phase="deleting",
                source_path=str(destination),
                local_status="quarantined",
                recovery_note="GitHub reposu silinip ana galeriden kaldirilacak.",
                error="",
            )
        except KeyError:
            pass

    if progress:
        progress(f"{gallery_id}: GitHub reposu tamamen siliniyor", None)
    api.delete_repo(gallery_id)
    _write_journal(
        settings,
        gallery_id,
        {
            **journal,
            "stage": "remote_deleted",
            "source_original": str(source_original),
            "destination": str(destination or ""),
            "row": row,
        },
    )

    if any(item.get("gallery_id") == gallery_id for item in load_rows(settings)):
        remove_row(settings, gallery_id)
    _cleanup_local_artifacts(settings, gallery_id)

    audit = {
        "gallery_id": gallery_id,
        "deleted_at": now_iso(),
        "source_original": str(source_original),
        "destination": str(destination or ""),
        "row": row,
    }
    atomic_write_json(_audit_dir(settings) / f"{gallery_id}.json", audit)
    try:
        _journal_path(settings, gallery_id).unlink(missing_ok=True)
    except OSError:
        pass
    if progress:
        progress(f"{gallery_id}: repo silindi ve slayt ana galeriden kaldirildi", 100)
    return destination


def delete_bad_slide(
    settings: Settings,
    api: GitHubAPI,
    gallery_id: str,
    progress=None,
) -> Path | None:
    """Quarantine the source, permanently delete its GitHub repo and remove its card."""
    _validate_gallery_id(settings, gallery_id)
    row = next((item for item in load_rows(settings) if item.get("gallery_id") == gallery_id), None)
    if row is None:
        raise KeyError(gallery_id)
    if row.get("status") == "deleting":
        journal = _read_journal(settings, gallery_id)
        if not journal:
            source = Path(row.get("source_path") or "")
            journal = {
                "stage": "retry_without_journal",
                "source_original": str(source),
                "destination": str(source if source.parent == settings.rejected_path else ""),
                "row": row,
            }
        return _finish_delete(settings, api, gallery_id, row, journal, progress)

    source = Path(row.get("source_path") or "")
    destination = _unique_destination(settings, source, gallery_id) if source.name else None
    journal = {
        "stage": "planned",
        "source_original": str(source),
        "destination": str(destination or ""),
        "row": row,
    }
    _write_journal(settings, gallery_id, journal)
    update_row(
        settings,
        gallery_id,
        status="deleting",
        phase="deleting",
        recovery_note="Kullanici istegiyle tamamen silme islemi baslatildi.",
        error="",
    )
    return _finish_delete(settings, api, gallery_id, row, journal, progress)


def recover_pending_deletions(settings: Settings, api: GitHubAPI, progress=None) -> int:
    """Finish user-confirmed deletions interrupted by power or network loss."""
    rows = load_rows(settings)
    candidates = [row for row in rows if row.get("status") == "deleting"]
    count = 0
    for row in candidates:
        gallery_id = row.get("gallery_id", "")
        if not gallery_id:
            continue
        journal = _read_journal(settings, gallery_id)
        if not journal:
            source = Path(row.get("source_path") or "")
            journal = {
                "stage": "recovered_without_journal",
                "source_original": str(source),
                "destination": str(source if source.parent == settings.rejected_path else ""),
                "row": row,
            }
        if progress:
            progress(f"{gallery_id}: yarim kalan silme islemi tamamlaniyor", None)
        _finish_delete(settings, api, gallery_id, row, journal, progress)
        count += 1
    return count
