from __future__ import annotations

import io
import json
import shutil
from pathlib import Path

import requests
from PIL import Image

from .config import APP_ROOT, APP_VERSION, Settings
from .github_api import GitHubAPI
from .git_ops import prepare_and_push, run_git, trigger_pages_retry_commit
from .inventory import load_rows
from .metadata_sync import refresh_remote_sha, sync_remote_metadata, write_editable_csv
from .main_gallery_retry import mark_main_gallery_pending
from .templates import main_gallery_html


SMALL_THUMB_DIR = "thumbs"
SMALL_THUMB_SIZE = (360, 240)
PUBLIC_RELEASE_DIR = APP_ROOT / "public_release"
PUBLIC_RELEASE_DATE = "2026-08-06"


def _version_number() -> str:
    return str(APP_VERSION).split()[0]


def _safe_release_notes() -> str:
    version = _version_number()
    return (
        f"# Patoloji Pratik Slayt Yayıncısı {version} Final\n\n"
        f"Yayın tarihi: {PUBLIC_RELEASE_DATE}\n\n"
        "## Bu sürümde\n\n"
        "- Ana galeri içeriği değişmemiş olsa bile `Ana galeriyi yayımla` düğmesi "
        "küçük bir yeniden yayın commit'i oluşturarak GitHub Pages işlemini gerçekten başlatır.\n"
        "- GitHub Actions geçici olarak `Service Unavailable` döndürürse dosyalar korunur; "
        "yayın denetimi daha sonra güvenli biçimde yeniden dener.\n"
        "- Galeri reposunda yalnızca güvenli dağıtım paketi, SHA-256 özeti ve bu sürüm notları yayımlanır.\n"
        "- Token, ayar dosyaları, `slides.csv`, kaynak slaytlar ve yerel çalışma klasörleri "
        "dağıtım paketine alınmaz.\n\n"
        "## Kurulum\n\n"
        "ZIP içeriğini `E:\\github` üzerine çıkarın. Sonraki güncellemelerde güncelleme ZIP'ini "
        "`E:\\github\\guncelleme` klasörüne koyup yalnızca `BASLAT.bat` çalıştırın.\n"
    )


def _publish_safe_release_files(repo_dir: Path) -> None:
    """Copy only prebuilt, audited public release files into the gallery repo.

    The public release directory is generated without config/data/repos/work/logs,
    so publishing the gallery cannot leak a token, slides.csv, patient metadata, or
    local source paths. Missing release assets never block gallery publication.
    """
    version = _version_number()
    release_name = f"PatolojiPratikSlaytYayincisi_v{version}.zip"
    sha_name = release_name + ".sha256.txt"
    source_zip = PUBLIC_RELEASE_DIR / release_name
    source_sha = PUBLIC_RELEASE_DIR / sha_name
    target_dir = repo_dir / "indir"
    target_dir.mkdir(parents=True, exist_ok=True)

    for stale in target_dir.glob("PatolojiPratikSlaytYayincisi_v*.zip"):
        if stale.name != release_name:
            stale.unlink(missing_ok=True)
    for stale in target_dir.glob("PatolojiPratikSlaytYayincisi_v*.zip.sha256.txt"):
        if stale.name != sha_name:
            stale.unlink(missing_ok=True)

    if source_zip.is_file() and source_sha.is_file():
        shutil.copy2(source_zip, target_dir / release_name)
        shutil.copy2(source_sha, target_dir / sha_name)
        sha_value = source_sha.read_text(encoding="utf-8").strip().split()[0]
    else:
        sha_value = ""

    (repo_dir / "SURUM_NOTLARI.md").write_text(_safe_release_notes(), encoding="utf-8")
    (repo_dir / "surum.json").write_text(
        json.dumps(
            {
                "version": APP_VERSION,
                "release_date": PUBLIC_RELEASE_DATE,
                "download": f"indir/{release_name}" if source_zip.is_file() else "",
                "sha256": sha_value,
                "release_notes": "SURUM_NOTLARI.md",
                "contains_user_data": False,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def _current_head(repo_dir: Path) -> str:
    if not (repo_dir / ".git").exists():
        return ""
    result = run_git(["rev-parse", "HEAD"], repo_dir, check=False)
    return result.stdout.strip() if result.returncode == 0 else ""


def _ensure_small_thumbnail(
    settings: Settings,
    gallery_repo_dir: Path,
    row: dict[str, str],
    progress=None,
) -> str:
    gallery_id = row.get("gallery_id", "").strip()
    if not gallery_id:
        return row.get("thumbnail_url", "")

    relative = f"{SMALL_THUMB_DIR}/{gallery_id}.jpg"
    target = gallery_repo_dir / relative
    if target.exists() and target.stat().st_size > 0:
        return relative

    target.parent.mkdir(parents=True, exist_ok=True)
    if progress:
        progress(f"{gallery_id}: ana galeri icin kucuk on izleme hazirlaniyor", None)
    local_source = settings.repos_dir / gallery_id / "thumbnail.jpg"
    image: Image.Image | None = None
    try:
        if local_source.exists():
            with Image.open(local_source) as opened:
                image = opened.convert("RGB")
        else:
            url = row.get("thumbnail_url", "").strip()
            if not url:
                return ""
            response = requests.get(
                url,
                timeout=(8, 20),
                headers={"User-Agent": "PatolojiPratik-Gallery/3.6.4"},
            )
            response.raise_for_status()
            with Image.open(io.BytesIO(response.content)) as opened:
                image = opened.convert("RGB")

        image.thumbnail(SMALL_THUMB_SIZE, Image.Resampling.LANCZOS)
        temp = target.with_suffix(".tmp.jpg")
        image.save(temp, format="JPEG", quality=68, optimize=True, progressive=True)
        temp.replace(target)
        return relative
    except Exception as exc:
        if progress:
            progress(f"{gallery_id}: kucuk on izleme hazirlanamadi; mevcut resim kullanilacak ({exc})", None)
        return row.get("thumbnail_url", "")
    finally:
        if image is not None:
            image.close()



def _align_local_gallery_repo(settings: Settings, api: GitHubAPI, progress=None) -> None:
    """Fast-forward the generated gallery worktree before applying web edits.

    GitHub's web editor creates a normal remote commit. Resetting the generated
    local gallery to remote main prevents a non-fast-forward push. Slide source
    state lives in data/slides.csv, so the gallery worktree is safe to regenerate.
    """
    if not api.repo_exists(settings.gallery_repo):
        return
    repo_dir = settings.repos_dir / settings.gallery_repo
    repo_dir.mkdir(parents=True, exist_ok=True)
    if not (repo_dir / ".git").exists():
        run_git(["init", "-b", "main"], repo_dir)
    remote = f"https://github.com/{settings.github_username}/{settings.gallery_repo}.git"
    current = run_git(["remote", "get-url", "origin"], repo_dir, check=False)
    if current.returncode == 0:
        run_git(["remote", "set-url", "origin", remote], repo_dir)
    else:
        run_git(["remote", "add", "origin", remote], repo_dir)
    fetched = run_git(["fetch", "--depth=1", "origin", "main"], repo_dir, check=False)
    if fetched.returncode == 0:
        run_git(["reset", "--hard", "FETCH_HEAD"], repo_dir)
        run_git(["clean", "-fd"], repo_dir, check=False)
        if progress:
            progress("Ana galeri GitHub'daki son duzenlemelerle esitlendi", 100)


def build_gallery(settings: Settings, progress=None) -> Path:
    repo_dir = settings.repos_dir / settings.gallery_repo
    repo_dir.mkdir(parents=True, exist_ok=True)
    rows = load_rows(settings)
    public_rows = []
    for row in rows:
        if row.get("status") != "published":
            continue
        public_item = {
            "gallery_id": row.get("gallery_id", ""),
            "number": int(row.get("number") or 0),
            "display_order": int(row.get("display_order") or row.get("number") or 0),
            "title": row.get("title", ""),
            "organ": row.get("organ", ""),
            "diagnosis": row.get("diagnosis", ""),
            "description": row.get("description", ""),
            "tags": row.get("tags", ""),
            "source_format": row.get("source_format", ""),
            "page_url": row.get("page_url", ""),
            "thumbnail_url": row.get("thumbnail_url", ""),
            "label_url": row.get("label_url", ""),
        }
        public_item["small_thumbnail_url"] = _ensure_small_thumbnail(
            settings, repo_dir, public_item, progress
        )
        public_rows.append(public_item)
    public_rows.sort(key=lambda x: (x["display_order"], x["number"]))

    # Silinen slaytlardan kalmis kucuk resimler ana galeri reposunda tutulmaz.
    valid_ids = {item["gallery_id"] for item in public_rows}
    thumbs_dir = repo_dir / SMALL_THUMB_DIR
    if thumbs_dir.exists():
        for stale in thumbs_dir.glob("gallery-*.jpg"):
            if stale.stem not in valid_ids:
                try:
                    stale.unlink()
                except OSError:
                    pass

    (repo_dir / "index.html").write_text(
        main_gallery_html(
            settings.github_username,
            settings.gallery_repo,
            settings.remote_metadata_filename,
        ),
        encoding="utf-8",
    )
    (repo_dir / "slides.json").write_text(
        json.dumps(public_rows, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    # Yalnizca kullanicinin duzenledigi alanlari iceren sade CSV. GitHub'in web
    # editorunde degistirildiginde galeri sayfasi bu dosyayi dogrudan okuyarak
    # ad ve aciklamalari uygulama acilmadan da gosterir.
    write_editable_csv(repo_dir / settings.remote_metadata_filename, public_rows)

    (repo_dir / ".nojekyll").write_text("", encoding="utf-8")
    _publish_safe_release_files(repo_dir)
    version = _version_number()
    release_name = f"PatolojiPratikSlaytYayincisi_v{version}.zip"
    (repo_dir / "README.md").write_text(
        "# Patoloji Pratik Slaytları\n\n"
        "Sanal mikroskop ana galerisi.\n\n"
        f"## Masaüstü uygulaması: {APP_VERSION}\n\n"
        f"- [Güvenli tam paket](indir/{release_name})\n"
        f"- [SHA-256 doğrulama dosyası](indir/{release_name}.sha256.txt)\n"
        "- [Son sürüm notları](SURUM_NOTLARI.md)\n\n"
        "Yayımlanan uygulama paketi kullanıcı verisi içermez. GitHub tokeni, `config`, "
        "`data/slides.csv`, `repos`, `work`, `logs` ve kaynak KFB/SVS dosyaları pakete alınmaz.\n\n"
        "## Slayt bilgilerini düzenleme\n\n"
        "Başlık, organ, tanı, açıklama ve etiketler Patoloji Pratik masaüstü "
        "uygulamasındaki `Slayt bilgilerini düzenle` penceresinden yönetilir.\n\n"
        "Ana sayfa küçük ön izlemeleri kullanır; büyük ön izlemeler yalnızca "
        "kullanıcı karttaki aşağı ok simgesine bastığında yüklenir.\n",
        encoding="utf-8",
    )
    return repo_dir


def publish_gallery(
    settings: Settings,
    token: str,
    api: GitHubAPI,
    progress=None,
) -> str:
    # GitHub web editoru uzakta bir commit olusturur. Once uretilen ana galeri
    # calisma kopyasi bu commit'e hizalanir, sonra ad/aciklama verileri alinir.
    try:
        _align_local_gallery_repo(settings, api, progress)
    except Exception as exc:
        if progress:
            progress(f"Ana galeri uzaktaki commit ile hizalanamadi: {exc}", None)

    # Otomatik uzak esitleme v3.2 ve sonrasinda varsayilan olarak kapalidir. Ileri kullanici
    # ayarlardan acarsa uc yonlu karsilastirma yerel tanilari koruyarak uygulanir.
    try:
        sync_remote_metadata(settings, api, progress)
    except Exception as exc:
        if progress:
            progress(f"Cevrimici slayt bilgileri alinamadi; yerel bilgiler kullaniliyor: {exc}", None)

    repo_dir = build_gallery(settings, progress)
    api.create_public_repo(settings.gallery_repo, "Patoloji pratik sanal mikroskop galerisi")
    head_before = _current_head(repo_dir)
    head_sha = prepare_and_push(
        repo_dir,
        settings.gallery_repo,
        settings,
        token,
        "Ana galeri guncellendi",
        progress,
    )
    if head_before and head_sha == head_before:
        if progress:
            progress(
                "Ana galeri içeriği değişmedi; GitHub Pages için küçük yeniden yayın commit'i gönderiliyor",
                None,
            )
        head_sha = trigger_pages_retry_commit(
            repo_dir,
            settings.gallery_repo,
            settings,
            token,
            "Ana galeri yeniden yayinlandi",
            progress,
        )
    fallback_url = f"https://{settings.github_username}.github.io/{settings.gallery_repo}/"
    try:
        url = api.enable_pages(settings.gallery_repo)
    except Exception as exc:
        url = fallback_url
        if progress:
            progress(
                f"Ana galeri GitHub'a gönderildi; Pages ayarı geçici olarak doğrulanamadı: {exc}",
                None,
            )
    mark_main_gallery_pending(settings, head_sha, url, repo_dir / "slides.json")
    try:
        api.set_repo_homepage(settings.gallery_repo, url)
    except Exception as exc:
        if progress:
            progress(f"Ana galeri adresi repo bilgisine yazılamadı; yayın takibi sürecek: {exc}", None)
    try:
        refresh_remote_sha(settings, api)
    except Exception:
        pass
    return url
