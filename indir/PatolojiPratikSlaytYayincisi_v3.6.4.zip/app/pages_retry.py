from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .config import Settings
from .git_ops import run_git, trigger_pages_retry_commit
from .github_api import GitHubAPI, page_is_reachable, page_probe_once
from .inventory import load_rows, update_row
from .receipts import load_receipt, write_receipt
from .utils import now_iso


def _parse_iso(value: str) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _next_retry_iso(settings: Settings, retry_count: int) -> str:
    base = max(300, int(getattr(settings, "pages_retry_delay_seconds", 900)))
    maximum = max(base, int(getattr(settings, "pages_retry_max_delay_seconds", 3600)))
    multiplier = 2 ** min(max(0, retry_count - 1), 2)
    delay = min(maximum, base * multiplier)
    return (_now_utc() + timedelta(seconds=delay)).astimezone().isoformat(timespec="seconds")


def retry_is_due(row: dict[str, str]) -> bool:
    due = _parse_iso(row.get("pages_next_retry_at", ""))
    return due is None or due <= _now_utc()


def was_published_recently(row: dict[str, str], hours: int) -> bool:
    published = _parse_iso(row.get("published_at", ""))
    if published is None:
        return False
    return published >= _now_utc() - timedelta(hours=max(1, int(hours)))


def _local_head(repo_dir: Path) -> str:
    if not (repo_dir / ".git").exists():
        return ""
    result = run_git(["rev-parse", "HEAD"], repo_dir, check=False)
    return result.stdout.strip() if result.returncode == 0 else ""


def mark_pages_pending(
    settings: Settings,
    gallery_id: str,
    *,
    page_url: str,
    local_sha: str,
    remote_sha: str,
    note: str,
    initial_delay: bool = True,
) -> dict[str, str]:
    next_retry = _next_retry_iso(settings, 1) if initial_delay else now_iso()
    write_receipt(
        settings,
        gallery_id,
        stage="pages_pending",
        local_sha=local_sha,
        remote_sha=remote_sha,
        page_url=page_url,
        pages_retry_count=0,
        pages_next_retry_at=next_retry,
    )
    return update_row(
        settings,
        gallery_id,
        status="pages_pending",
        phase="pages_wait",
        page_url=page_url,
        thumbnail_url=page_url.rstrip("/") + "/thumbnail.jpg",
        label_url=page_url.rstrip("/") + "/label.jpg",
        last_verified_sha=remote_sha,
        pages_retry_count="0",
        pages_next_retry_at=next_retry,
        pages_last_checked_at=now_iso(),
        recovery_note=note,
        error="",
    )


def finalize_page_verified(
    settings: Settings,
    row: dict[str, str],
    *,
    remote_sha: str,
    page_url: str,
    note: str,
) -> dict[str, str]:
    gallery_id = row["gallery_id"]
    receipt = load_receipt(settings, gallery_id)
    local_sha = str(receipt.get("local_sha") or _local_head(settings.repos_dir / gallery_id))
    write_receipt(
        settings,
        gallery_id,
        stage="page_verified",
        local_sha=local_sha,
        remote_sha=remote_sha,
        page_url=page_url,
        page_verified_at=now_iso(),
        pages_next_retry_at="",
    )
    return update_row(
        settings,
        gallery_id,
        status="published",
        phase="complete",
        page_url=page_url,
        thumbnail_url=page_url.rstrip("/") + "/thumbnail.jpg",
        label_url=page_url.rstrip("/") + "/label.jpg",
        last_verified_sha=remote_sha,
        published_at=row.get("published_at") or now_iso(),
        pages_next_retry_at="",
        pages_last_checked_at=now_iso(),
        recovery_note=note,
        error="",
    )


def _trigger_retry(
    settings: Settings,
    api: GitHubAPI,
    token: str,
    row: dict[str, str],
    progress=None,
) -> tuple[str, str, bool]:
    gallery_id = row["gallery_id"]
    remote_sha = api.get_branch_sha(gallery_id, "main")

    # Workflow modunda yeniden tetikleme, bos commit gerektirmeden dogrudan
    # workflow_dispatch ile yapilir. Pages artifact'i yalnizca kucuk
    # goruntuleyici kabugudur; on binlerce karo dagitim paketine girmez.
    if settings.pages_workflow_deploy:
        from .pages_deploy import (
            active_run,
            dispatch as _dispatch,
            ensure_lightweight_pages_remote,
        )

        # Eski/buyuk repo birkac KB'lik Pages kabuguna cevrilir. Karolar GitHub
        # reposunda kalir ve goruntuleyici bunlari gerektikce raw URL'den okur.
        ensure_lightweight_pages_remote(api, gallery_id, settings, progress)

        # Halen calisan bir kosu varsa yeni tetikleme yapma. `pages.yml`
        # concurrency ayari cancel-in-progress: false oldugu icin ikinci bir
        # dispatch kosulari birbiri arkasina yigar.
        running = active_run(api, gallery_id)
        if running is not None:
            return (
                api.get_branch_sha(gallery_id, "main"),
                "Pages workflow'u halen calisiyor; yeni tetikleme yapilmadi",
                False,
            )

        # Goruntuleyici/workflow commit'i uzak SHA'yi degistirebilir; envantere
        # eski SHA yazmamak icin tetiklemeden sonra yeniden oku.
        _dispatch(api, gallery_id)
        remote_sha = api.get_branch_sha(gallery_id, "main")
        return remote_sha, "Hafif Pages paketiyle dagitim yeniden tetiklendi", True

    run_state = api.latest_pages_workflow_state(gallery_id, remote_sha)
    if run_state.get("status") in {"queued", "in_progress", "waiting", "pending", "requested"}:
        return remote_sha, "GitHub Pages calismasi halen kuyrukta; yeni tetikleme yapilmadi", False

    run_id = int(run_state.get("id") or 0)
    if run_id and run_state.get("conclusion") in {"failure", "cancelled", "timed_out", "startup_failure"}:
        if api.rerun_failed_workflow(gallery_id, run_id):
            return remote_sha, f"basarisiz Pages calismasi yeniden baslatildi (run {run_id})", True

    repo_dir = settings.repos_dir / gallery_id
    local_sha = _local_head(repo_dir)
    if local_sha and local_sha.lower() == remote_sha.lower():
        new_sha = trigger_pages_retry_commit(
            repo_dir,
            gallery_id,
            settings,
            token,
            f"GitHub Pages yeniden deneme {now_iso()}",
            progress,
        )
        return new_sha, "kucuk bos Git commit ile Pages yeniden tetiklendi", True

    if repo_dir.exists() and local_sha and local_sha.lower() != remote_sha.lower():
        raise RuntimeError(
            f"{gallery_id}: yerel ve uzak commit eslesmiyor; guvenli Pages tetiklemesi ertelendi. "
            f"Yerel: {local_sha} | GitHub: {remote_sha}"
        )

    marker = (
        "Patoloji Pratik GitHub Pages otomatik yeniden deneme kaydi.\n"
        f"Tarih: {now_iso()}\n"
        f"Repo: {gallery_id}\n"
    )
    new_sha = api.upsert_text_file(
        gallery_id,
        ".pages-retry.txt",
        marker,
        f"GitHub Pages yeniden deneme {now_iso()}",
    )
    return new_sha, "kucuk .pages-retry.txt commit'i ile Pages yeniden tetiklendi", True


def check_or_retry_pages(
    settings: Settings,
    api: GitHubAPI,
    token: str,
    row: dict[str, str],
    *,
    progress=None,
    wait_seconds: int = 0,
    allow_trigger: bool = True,
    force_trigger: bool = False,
) -> tuple[str, dict[str, str]]:
    """Check one pending Pages publication and optionally trigger a safe retry.

    Returns (state, row), where state is verified, triggered, active, waiting, or error.
    GitHub and local repositories are never deleted here.
    """
    gallery_id = row["gallery_id"]
    page_url = row.get("page_url") or settings.page_url(gallery_id)
    if wait_seconds > 0:
        reachable = page_is_reachable(page_url, max(1, int(wait_seconds)), progress)
        probe = "reachable" if reachable else page_probe_once(page_url)
    else:
        probe = page_probe_once(page_url)
        reachable = probe == "reachable"
    if reachable:
        remote_sha = api.get_branch_sha(gallery_id, "main")
        updated = finalize_page_verified(
            settings,
            row,
            remote_sha=remote_sha,
            page_url=page_url,
            note="GitHub Pages tarayicidan dogrulandi; yayin tamamlandi.",
        )
        if progress:
            progress(f"{gallery_id}: GitHub Pages yayini dogrulandi", 100)
        return "verified", updated

    checked_row = update_row(settings, gallery_id, pages_last_checked_at=now_iso())
    if probe == "unavailable":
        if progress:
            progress(
                f"{gallery_id}: Pages kontrolunde internet/GitHub yaniti alinamadi; repo korunuyor",
                100,
            )
        return "waiting", checked_row
    if not allow_trigger or (not force_trigger and not retry_is_due(row)):
        return "waiting", checked_row

    try:
        new_sha, method, did_trigger = _trigger_retry(settings, api, token, row, progress)
    except Exception as exc:
        count = int(row.get("pages_retry_count") or 0) + 1
        next_retry = _next_retry_iso(settings, count)
        updated = update_row(
            settings,
            gallery_id,
            status="pages_pending",
            phase="pages_wait",
            pages_retry_count=str(count),
            pages_next_retry_at=next_retry,
            pages_last_checked_at=now_iso(),
            recovery_note=f"Pages yeniden denemesi gecici olarak basarisiz: {exc}",
            error="",
        )
        if progress:
            progress(
                f"{gallery_id}: Pages yeniden denemesi yapilamadi; repo korunuyor ve sonra tekrar denenecek",
                100,
            )
        return "error", updated

    if not did_trigger:
        count = int(row.get("pages_retry_count") or 0)
        next_retry = _next_retry_iso(settings, max(1, count))
        updated = update_row(
            settings,
            gallery_id,
            status="pages_pending",
            phase="pages_wait",
            pages_next_retry_at=next_retry,
            pages_last_checked_at=now_iso(),
            recovery_note=f"{method}; daha sonra yeniden kontrol edilecek.",
            error="",
        )
        if progress:
            progress(f"{gallery_id}: {method}; repo korunuyor", 100)
        return "active", updated

    count = int(row.get("pages_retry_count") or 0) + 1
    next_retry = _next_retry_iso(settings, count)
    updated = update_row(
        settings,
        gallery_id,
        status="pages_pending",
        phase="pages_retry",
        last_verified_sha=new_sha,
        pages_retry_count=str(count),
        pages_next_retry_at=next_retry,
        pages_last_triggered_at=now_iso(),
        pages_last_checked_at=now_iso(),
        recovery_note=f"{method}; yayin daha sonra tekrar kontrol edilecek.",
        error="",
    )
    receipt = load_receipt(settings, gallery_id)
    write_receipt(
        settings,
        gallery_id,
        stage="pages_retry_triggered",
        local_sha=str(receipt.get("local_sha") or _local_head(settings.repos_dir / gallery_id)),
        remote_sha=new_sha,
        page_url=page_url,
        pages_retry_count=count,
        pages_next_retry_at=next_retry,
        pages_retry_method=method,
    )
    if progress:
        progress(
            f"{gallery_id}: {method}; repo korunuyor, yayin daha sonra yeniden kontrol edilecek",
            100,
        )
    return "triggered", updated


def schedule_next_retry(
    settings: Settings,
    gallery_id: str,
    note: str,
    progress=None,
) -> dict[str, str]:
    """Satiri `pages_pending` olarak birak ve bir sonraki denemeyi planla.

    Onarim basarisiz olsa bile durum `pages_error` yapilmaz; boylece acilistaki
    otomatik kontrol satiri gormeye devam eder.
    """
    rows = load_rows(settings)
    row = next((r for r in rows if r.get("gallery_id") == gallery_id), {})
    count = int(row.get("pages_retry_count") or 0) + 1
    return update_row(
        settings,
        gallery_id,
        status="pages_pending",
        phase="pages_wait",
        pages_retry_count=str(count),
        pages_next_retry_at=_next_retry_iso(settings, count),
        pages_last_checked_at=now_iso(),
        recovery_note=note,
        error="",
    )


def pending_page_rows(settings: Settings) -> list[dict[str, str]]:
    rows = [
        row
        for row in load_rows(settings)
        if row.get("status") in ("pages_pending", "pages_error")
    ]
    return sorted(
        rows,
        key=lambda row: (
            row.get("pages_next_retry_at") or "",
            int(row.get("display_order") or row.get("number") or 0),
        ),
    )
