from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path

from .config import Settings
from .github_api import GitHubAPI
from .git_ops import run_git
from .inventory import load_rows, update_row
from .templates import LIGHTWEIGHT_VIEWER_MARKER
from .utils import directory_size


class CleanupError(RuntimeError):
    pass


def _format_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TB"


def _remove_readonly(func, path, exc_info) -> None:
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except OSError:
        raise exc_info[1]


def _safe_repo_path(settings: Settings, gallery_id: str) -> Path:
    repo_dir = (settings.repos_dir / gallery_id).resolve()
    repos_root = settings.repos_dir.resolve()
    if repo_dir.parent != repos_root:
        raise CleanupError(f"Guvenli olmayan repo yolu: {repo_dir}")
    if not gallery_id.startswith(settings.repo_prefix):
        raise CleanupError(f"Slayt repo adi beklenen bicimde degil: {gallery_id}")
    if gallery_id == settings.gallery_repo:
        raise CleanupError("Ana galeri reposu silinemez.")
    return repo_dir


def verify_local_matches_remote(
    settings: Settings,
    api: GitHubAPI,
    gallery_id: str,
    repo_dir: Path,
) -> tuple[str, str]:
    git_dir = repo_dir / ".git"
    if not git_dir.exists():
        raise CleanupError(f"Yerel Git deposu bulunamadi: {repo_dir}")
    local = run_git(["rev-parse", "HEAD"], repo_dir).stdout.strip()
    remote = api.get_branch_sha(gallery_id, "main")
    if not local or not remote:
        raise CleanupError(
            f"Yerel veya GitHub commit'i okunamadi ({gallery_id}). "
            f"Yerel: {local or '-'} | GitHub: {remote or '-'}"
        )
    if local.lower() != remote.lower():
        # Pages onarimi `.github/workflows/pages.yml` dosyasini Contents API ile
        # ekleyebilir. Bu durumda uzak HEAD yerelden ileridedir. Yalnizca izinli
        # Pages yonetim dosyalarini degistiren tek-ebeveynli commit zinciri
        # kriptografik SHA zinciri uzerinden dogrulanirsa temizlik guvenlidir.
        safe_admin_only = api.remote_has_only_safe_admin_commits(
            gallery_id,
            local,
            remote,
            allowed_paths={
                ".github/workflows/pages.yml",
                ".pages-retry.txt",
                "index.html",
            },
            required_content_markers={
                "index.html": LIGHTWEIGHT_VIEWER_MARKER,
            },
        )
        if not safe_admin_only:
            raise CleanupError(
                f"Yerel ve GitHub commitleri eslesmiyor ({gallery_id}); "
                "uzaktaki fark yalnizca guvenli Pages dosyalari olarak "
                "dogrulanamadi. Yerel klasor korunuyor. "
                f"Yerel: {local} | GitHub: {remote}"
            )
    return local, remote


def finish_interrupted_cleanup(
    settings: Settings,
    gallery_id: str,
    progress=None,
) -> int:
    """Finish a deletion that had already passed remote verification before power loss."""
    repo_dir = _safe_repo_path(settings, gallery_id)
    rows = load_rows(settings)
    row = next((r for r in rows if r.get("gallery_id") == gallery_id), {})
    expected = int(row.get("local_freed_bytes") or 0)
    if repo_dir.exists():
        if progress:
            progress(f"{gallery_id}: yarim kalan yerel temizlik tamamlaniyor", None)
        shutil.rmtree(repo_dir, onerror=_remove_readonly)
    update_row(settings, gallery_id, local_status="deleted")
    if progress:
        progress(f"{gallery_id}: yerel temizlik tamamlandi", 100)
    return expected


def cleanup_published_repo(
    settings: Settings,
    api: GitHubAPI,
    gallery_id: str,
    progress=None,
) -> int:
    repo_dir = _safe_repo_path(settings, gallery_id)
    if not repo_dir.exists():
        update_row(settings, gallery_id, local_status="deleted")
        return 0

    rows = load_rows(settings)
    row = next((r for r in rows if r.get("gallery_id") == gallery_id), {})
    if row.get("local_status") == "cleanup_in_progress":
        return finish_interrupted_cleanup(settings, gallery_id, progress)

    if progress:
        progress(f"{gallery_id}: GitHub kopyasi dogrulaniyor", None)
    verify_local_matches_remote(settings, api, gallery_id, repo_dir)
    size = directory_size(repo_dir)
    # This checkpoint is written only after the remote SHA has been verified.
    update_row(
        settings,
        gallery_id,
        local_status="cleanup_in_progress",
        local_freed_bytes=str(size),
    )
    if progress:
        progress(
            f"{gallery_id}: yerel yayin klasoru siliniyor ({_format_size(size)})",
            None,
        )
    shutil.rmtree(repo_dir, onerror=_remove_readonly)
    update_row(settings, gallery_id, local_status="deleted")
    if progress:
        progress(
            f"{gallery_id}: yerel alan temizlendi, {_format_size(size)} bosaltildi",
            100,
        )
    return size


def cleanup_all_published(
    settings: Settings,
    api: GitHubAPI,
    progress=None,
) -> tuple[int, int, list[str]]:
    rows = load_rows(settings)
    candidates = [
        row
        for row in rows
        if row.get("status") == "published"
        and (
            (settings.repos_dir / row.get("gallery_id", "")).exists()
            or row.get("local_status") == "cleanup_in_progress"
        )
        and row.get("gallery_id") != settings.gallery_repo
    ]
    deleted = 0
    freed = 0
    errors: list[str] = []
    for index, row in enumerate(candidates, start=1):
        gallery_id = row.get("gallery_id", "")
        if progress:
            progress(
                f"Yerel temizlik: {gallery_id} ({index}/{len(candidates)})",
                (index - 1) / max(1, len(candidates)) * 100,
            )
        try:
            freed += cleanup_published_repo(settings, api, gallery_id, progress)
            deleted += 1
        except Exception as exc:
            errors.append(f"{gallery_id}: {exc}")
    if progress:
        progress(
            f"Yerel temizlik tamamlandi: {deleted} repo, {_format_size(freed)} bosaltildi",
            100,
        )
    return deleted, freed, errors
