"""GitHub Pages dagitimini hafif bir artifact ile yurutur.

GitHub Pages siteleri 1 GB ile sinirlidir ve 10 dakikadan uzun deployment'lar
zaman asimina ugrar. Buyuk SVS slaytlarinda sorun toplam JPEG boyutundan cok,
on binlerce karonun Pages artifact'i olarak acilip yayinlanmasidir.

Bu modul karolari GitHub reposunda birakir. Pages'e yalnizca index.html,
thumbnail, etiket ve DZI tanimi gider. OpenSeadragon karolari ziyaret sirasinda
public raw GitHub URL'lerinden okur. Boylece repo ve kaynak slayt korunurken
Pages paketi birkac MB'da kalir.
"""

from __future__ import annotations

import time
import xml.etree.ElementTree as ET
from pathlib import Path

from .config import Settings
from .github_api import GitHubAPI, GitHubError
from .templates import LIGHTWEIGHT_VIEWER_MARKER, viewer_html


WORKFLOW_FILENAME = "pages.yml"
WORKFLOW_RELPATH = f".github/workflows/{WORKFLOW_FILENAME}"

# Node 24 calisma zamanini hedefleyen surumler. Node 20 uyarisi bu sayede olusmaz.
ACTION_CHECKOUT = "actions/checkout@v6"
ACTION_CONFIGURE = "actions/configure-pages@v6"
ACTION_UPLOAD = "actions/upload-pages-artifact@v5"
ACTION_DEPLOY = "actions/deploy-pages@v5"


class PagesDeployError(RuntimeError):
    pass


def workflow_yaml(settings: Settings) -> str:
    """Pages'e yalnizca kucuk goruntuleyici kabugunu dagit.

    DZI karolari GitHub reposunda kalir ve goruntuleyici bunlari
    ``raw.githubusercontent.com`` uzerinden gerektikce okur. Boylece on binlerce
    JPEG dosyasi Pages artifact'ina girmez; deployment 10 dakikalik GitHub
    Pages sinirinin altinda kalir. Pages deployment'lari atomiktir ve parca
    parca birlestirilemez, bu nedenle depolama ile Pages paketini ayirmak daha
    guvenlidir.
    """
    return f"""name: Pages dagitimi

"on":
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

jobs:
  deploy:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    environment:
      name: github-pages
      url: ${{{{ steps.deployment.outputs.page_url }}}}
    steps:
      - name: Yalnizca Pages kabugunu al
        uses: {ACTION_CHECKOUT}
        with:
          fetch-depth: 1
          sparse-checkout: |
            index.html
            slide.dzi
            thumbnail.jpg
            label.jpg
            metadata.json
            .nojekyll
          sparse-checkout-cone-mode: false

      - name: Pages ayarlarini oku
        uses: {ACTION_CONFIGURE}

      - name: Hafif Pages paketini hazirla
        shell: bash
        run: |
          set -euo pipefail
          rm -rf _pages_site
          mkdir -p _pages_site
          cp index.html slide.dzi thumbnail.jpg _pages_site/
          test -f label.jpg && cp label.jpg _pages_site/ || true
          test -f metadata.json && cp metadata.json _pages_site/ || true
          test -f .nojekyll && cp .nojekyll _pages_site/ || true
          echo "Pages paketindeki dosyalar:"
          find _pages_site -maxdepth 1 -type f -printf '%f\\n' | sort

      - name: Hafif Pages artifact'ini yukle
        id: upload
        uses: {ACTION_UPLOAD}
        with:
          path: _pages_site
          include-hidden-files: true

      - name: Pages'e dagit
        id: deployment
        uses: {ACTION_DEPLOY}
"""


def write_workflow(repo_dir: Path, settings: Settings) -> Path:
    """Workflow dosyasini repo klasorune yaz. Push'tan once cagrilmalidir."""
    path = repo_dir / ".github" / "workflows" / WORKFLOW_FILENAME
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(workflow_yaml(settings), encoding="utf-8")
    return path


WORKFLOW_SCOPE_HINT = (
    "GitHub token'inin yetkisi yetersiz.\n"
    "Klasik token: 'repo' ve 'workflow' kutulari isaretli olmali.\n"
    "Ince ayarli (fine-grained) token, bu depolar icin sunlarin hepsini ister:\n"
    "  Contents: Read and write        (dosya yazma)\n"
    "  Workflows: Read and write       (.github/workflows yazma)\n"
    "  Actions: Read and write         (workflow_dispatch ile tetikleme)\n"
    "  Pages: Read and write           (Pages kaynagini workflow moduna alma)\n"
    "  Administration: Read and write  (Pages ayarini degistirme)\n"
    "Yetkiyi ekledikten sonra GITHUB_BAGLA.bat ile token'i yeniden kaydedin."
)


def ensure_workflow_file_remote(
    api: GitHubAPI,
    repo_name: str,
    settings: Settings,
    progress=None,
) -> bool:
    """Workflow dosyasini dogrudan GitHub uzerinde olustur/guncelle.

    Yerel repo klasoru silinmis olsa bile calisir; buyuk DZI dosyalari yeniden
    gonderilmez, yalnizca birkac yuz baytlik tek bir commit olusur.
    """
    wanted = workflow_yaml(settings).encode("utf-8")
    existing = api.get_repo_file(repo_name, WORKFLOW_RELPATH)
    if existing is not None and existing[0] == wanted:
        return True
    try:
        api.put_repo_file(
            repo_name,
            WORKFLOW_RELPATH,
            wanted,
            "Pages dagitim workflow'u guncellendi",
        )
    except GitHubError as exc:
        text = str(exc).lower()
        if "workflow" in text and ("scope" in text or "permission" in text or "403" in text):
            raise GitHubError(WORKFLOW_SCOPE_HINT) from exc
        raise
    if progress:
        progress(f"{repo_name}: Pages dagitim workflow'u repoya eklendi", None)
    return True


def parse_dzi_descriptor(raw: bytes) -> dict[str, int | str]:
    """DZI XML'inden goruntuleyici icin gerekli geometriyi oku."""
    try:
        root = ET.fromstring(raw.decode("utf-8-sig"))
    except Exception as exc:
        raise PagesDeployError(f"slide.dzi okunamadi: {exc}") from exc
    size_node = next((node for node in root if str(node.tag).endswith("Size")), None)
    if size_node is None:
        raise PagesDeployError("slide.dzi icinde Size bilgisi bulunamadi.")
    try:
        width = int(size_node.attrib["Width"])
        height = int(size_node.attrib["Height"])
        tile_size = int(root.attrib["TileSize"])
        overlap = int(root.attrib.get("Overlap", "0"))
    except (KeyError, TypeError, ValueError) as exc:
        raise PagesDeployError("slide.dzi geometri bilgileri gecersiz.") from exc
    tile_format = str(root.attrib.get("Format") or "jpeg").strip().lower()
    if width <= 0 or height <= 0 or tile_size <= 0:
        raise PagesDeployError("slide.dzi boyutlari gecersiz.")
    return {
        "width": width,
        "height": height,
        "tile_size": tile_size,
        "overlap": max(0, overlap),
        "format": tile_format or "jpeg",
    }


def ensure_lightweight_pages_remote(
    api: GitHubAPI,
    repo_name: str,
    settings: Settings,
    progress=None,
) -> bool:
    """Eski/buyuk bir repo icin hafif Pages kabugunu uzaktan hazirla.

    Karolara dokunulmaz ve DZI yeniden donusturulmez. Yalnizca ``index.html``
    ve ``pages.yml`` birkac KB'lik commitlerle guncellenir.
    """
    ensure_workflow_pages(api, repo_name, progress)
    dzi_file = api.get_repo_file(repo_name, "slide.dzi")
    if dzi_file is None:
        raise PagesDeployError(f"{repo_name}: GitHub'da slide.dzi bulunamadi; repo korunuyor.")
    geometry = parse_dzi_descriptor(dzi_file[0])
    has_label = api.get_repo_file(repo_name, "label.jpg") is not None
    wanted_html = viewer_html(
        repo_name,
        settings.github_username,
        has_label,
        settings.remote_metadata_filename,
        width=int(geometry["width"]),
        height=int(geometry["height"]),
        tile_size=int(geometry["tile_size"]),
        tile_overlap=int(geometry["overlap"]),
        tile_format=str(geometry["format"]),
    ).encode("utf-8")
    existing_html = api.get_repo_file(repo_name, "index.html")
    viewer_changed = existing_html is None or existing_html[0] != wanted_html
    if viewer_changed:
        api.put_repo_file(
            repo_name,
            "index.html",
            wanted_html,
            "Hafif Pages goruntuleyicisi etkinlestirildi",
        )
        if progress:
            progress(
                f"{repo_name}: buyuk karolar Pages paketinden ayrildi; hafif goruntuleyici yazildi",
                None,
            )
    ensure_workflow_file_remote(api, repo_name, settings, progress)
    return viewer_changed


def is_lightweight_viewer(raw: bytes | str) -> bool:
    if isinstance(raw, bytes):
        text = raw.decode("utf-8", errors="replace")
    else:
        text = str(raw)
    return LIGHTWEIGHT_VIEWER_MARKER in text


def _is_permission_error(exc: Exception) -> bool:
    text = str(exc).casefold()
    return any(
        marker in text
        for marker in (
            "403",
            "resource not accessible",
            "permission",
            "scope",
            "must have admin rights",
        )
    )


def ensure_workflow_pages(api: GitHubAPI, repo_name: str, progress=None) -> str:
    """Pages kaynagini branch yerine GitHub Actions workflow'una cevir.

    Zaten workflow modundaysa dokunmaz. Pages hic acilmamissa acar. GitHub yeni
    bir repo/Pages kaydini kisa bir sure gecikmeli gosterebildigi icin 409/422
    sonrasinda GET islemi artan bekleme ile yeniden denenir.
    """
    assert api.username
    endpoint = f"/repos/{api.username}/{repo_name}/pages"
    current = None

    for attempt in range(8):
        try:
            current = api.request("GET", endpoint, expected=(200, 404))
            if current.status_code == 200:
                break

            created = api.request(
                "POST",
                endpoint,
                expected=(201, 409, 422),
                json={"build_type": "workflow"},
            )
            if created.status_code == 201:
                data = created.json()
                if progress:
                    progress(f"{repo_name}: Pages workflow moduyla acildi", None)
                return data.get("html_url") or _default_url(api, repo_name)
        except GitHubError as exc:
            if _is_permission_error(exc):
                raise GitHubError(WORKFLOW_SCOPE_HINT) from exc
            raise

        # 409/422 veya yeni repo tutarlilik gecikmesi: kayit gorunene kadar bekle.
        time.sleep(min(30, 2 ** attempt))
    else:
        raise PagesDeployError(
            f"{repo_name}: GitHub Pages kaydi olusturuldu ancak API'de gorunur olmadi. "
            "Repo korunuyor; daha sonra yeniden denenecek."
        )

    assert current is not None and current.status_code == 200
    data = current.json()
    if str(data.get("build_type") or "").lower() != "workflow":
        try:
            api.request(
                "PUT",
                endpoint,
                expected=(200, 204),
                json={"build_type": "workflow"},
            )
        except GitHubError as exc:
            if _is_permission_error(exc):
                raise GitHubError(WORKFLOW_SCOPE_HINT) from exc
            raise
        if progress:
            progress(f"{repo_name}: Pages kaynagi workflow moduna alindi", None)
    return data.get("html_url") or _default_url(api, repo_name)


def _default_url(api: GitHubAPI, repo_name: str) -> str:
    return f"https://{api.username}.github.io/{repo_name}/"


def latest_run_id(api: GitHubAPI, repo_name: str) -> int:
    """Workflow'un en son kosu numarasi. Yeni kosuyu ayirt etmek icin kullanilir."""
    runs = _list_runs(api, repo_name, per_page=1)
    return int(runs[0].get("id") or 0) if runs else 0


def _list_runs(api: GitHubAPI, repo_name: str, per_page: int = 10) -> list[dict]:
    assert api.username
    response = api.request(
        "GET",
        f"/repos/{api.username}/{repo_name}/actions/workflows/{WORKFLOW_FILENAME}/runs",
        expected=(200, 404),
        params={"per_page": per_page},
    )
    if response.status_code == 404:
        return []
    return list(response.json().get("workflow_runs") or [])


ACTIVE_STATES = {"queued", "in_progress", "waiting", "pending", "requested"}


def active_run(api: GitHubAPI, repo_name: str) -> dict | None:
    """Halen calisan/kuyrukta bekleyen pages.yml kosusu varsa dondur.

    Ayni anda ikinci bir dagitim tetiklemek, `cancel-in-progress: false`
    nedeniyle kosularin birbiri arkasina yigilmasina yol acar.
    """
    for run in _list_runs(api, repo_name, per_page=5):
        if str(run.get("status") or "") in ACTIVE_STATES:
            return run
    return None


def dispatch(api: GitHubAPI, repo_name: str, ref: str = "main", attempts: int = 10) -> int:
    """Workflow'u tetikle ve API veriyorsa yeni run kimligini dondur.

    Push'tan hemen sonra GitHub workflow dosyasini henuz kaydetmemis olabilir;
    bu durumda 404/422 doner. Artan bekleme ile yeniden denenir. Eski API
    surumleri 204, yeni surumler run bilgisiyle 200 dondurebilir.
    """
    assert api.username
    endpoint = (
        f"/repos/{api.username}/{repo_name}/actions/workflows/"
        f"{WORKFLOW_FILENAME}/dispatches"
    )
    for attempt in range(attempts):
        response = api.request(
            "POST",
            endpoint,
            expected=(200, 204, 404, 422),
            json={"ref": ref},
        )
        if response.status_code == 200:
            try:
                return int(response.json().get("workflow_run_id") or 0)
            except (TypeError, ValueError):
                return 0
        if response.status_code == 204:
            return 0
        time.sleep(min(30, 3 * (attempt + 1)))
    raise PagesDeployError(
        f"{repo_name}: Pages workflow'u tetiklenemedi. "
        f"{WORKFLOW_RELPATH} dosyasi GitHub tarafinda gorunmuyor olabilir."
    )


def wait_for_run(
    api: GitHubAPI,
    repo_name: str,
    after_run_id: int,
    timeout_seconds: int,
    progress=None,
    stop_requested=None,
    target_run_id: int = 0,
) -> dict:
    """Yeni veya onceden aktif kosunun tamamlanmasini bekle."""
    deadline = time.time() + max(120, timeout_seconds)
    run: dict = {}
    last_note = ""
    while time.time() < deadline:
        if stop_requested is not None and stop_requested():
            raise PagesDeployError(f"{repo_name}: Pages dagitimi kullanici istegiyle birakildi.")
        try:
            runs = _list_runs(api, repo_name, per_page=10)
        except GitHubError:
            runs = []

        if target_run_id:
            matches = [r for r in runs if int(r.get("id") or 0) == target_run_id]
            run = matches[0] if matches else {}
        else:
            fresh = [r for r in runs if int(r.get("id") or 0) > after_run_id]
            run = max(fresh, key=lambda r: int(r.get("id") or 0)) if fresh else {}

        if run:
            status = str(run.get("status") or "")
            if status == "completed":
                return run
            note = f"{repo_name}: Pages dagitimi suruyor ({status or 'bekliyor'})"
        else:
            note = f"{repo_name}: Pages dagitimi kuyruga aliniyor"
        if progress and note != last_note:
            progress(note, None)
            last_note = note
        time.sleep(15)
    if run:
        run["conclusion"] = run.get("conclusion") or "timed_out"
        return run
    raise PagesDeployError(f"{repo_name}: Pages dagitim kosusu baslatilamadi.")


def deploy_with_retry(
    api: GitHubAPI,
    repo_name: str,
    settings: Settings,
    progress=None,
    stop_requested=None,
) -> tuple[bool, str]:
    """Pages dagitimini yurut; basarisiz olursa yeniden tetikle.

    Donus: (basarili_mi, son_kosu_url)
    """
    ensure_workflow_pages(api, repo_name, progress)
    attempts = max(1, int(settings.pages_deploy_retries) + 1)
    last_url = ""
    for attempt in range(1, attempts + 1):
        # Zaten calisan bir kosu varsa yenisini baslatma; onu izle.
        running = active_run(api, repo_name)
        if running is not None:
            if progress:
                progress(
                    f"{repo_name}: calisan Pages kosusu bulundu, yenisi baslatilmadi",
                    None,
                )
            target_run_id = int(running.get("id") or 0)
            before = target_run_id - 1
        else:
            before = latest_run_id(api, repo_name)
            target_run_id = dispatch(api, repo_name)
        if progress and running is None:
            progress(
                f"{repo_name}: Pages dagitimi baslatildi (deneme {attempt}/{attempts})",
                None,
            )
        run = wait_for_run(
            api,
            repo_name,
            before,
            int(settings.pages_deploy_watch_seconds),
            progress,
            stop_requested,
            target_run_id=target_run_id,
        )
        conclusion = str(run.get("conclusion") or "")
        last_url = str(run.get("html_url") or "")
        if conclusion == "success":
            if progress:
                progress(f"{repo_name}: Pages dagitimi tamamlandi", 100)
            return True, last_url
        if progress:
            progress(
                f"{repo_name}: Pages dagitimi basarisiz ({conclusion or 'bilinmiyor'})",
                None,
            )
        if attempt < attempts:
            wait = min(120, 20 * attempt)
            if progress:
                progress(f"{repo_name}: {wait} saniye sonra yeniden denenecek", None)
            time.sleep(wait)
    return False, last_url
