from __future__ import annotations

import base64
import time
from typing import Any

import requests


class GitHubError(RuntimeError):
    pass


class GitHubAPI:
    def __init__(self, token: str, username: str | None = None) -> None:
        self.username = username
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {token}",
                "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "patoloji-pratik-gallery-uploader/1.0",
            }
        )

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        expected: tuple[int, ...] = (200,),
        retries: int = 6,
        **kwargs: Any,
    ) -> requests.Response:
        url = endpoint if endpoint.startswith("http") else f"https://api.github.com{endpoint}"
        last: requests.Response | None = None
        last_connection_error: requests.RequestException | None = None
        for attempt in range(retries):
            try:
                response = self.session.request(method, url, timeout=60, **kwargs)
            except requests.RequestException as exc:
                # GitHub ya da ara ag katmani baglantiyi yanitsiz kapatabilir.
                # Bu tur gecici hatalar yuklemenin basarisiz oldugu anlamina gelmez;
                # ayni API kontrolunu artan bekleme ile yeniden dene.
                last_connection_error = exc
                if attempt < retries - 1:
                    time.sleep(min(60, 2 ** attempt))
                    continue
                raise GitHubError(
                    f"GitHub baglantisi {retries} denemeden sonra kurulamadi: {exc}"
                ) from exc
            last = response
            if response.status_code in expected:
                return response
            if response.status_code in (403, 429) or response.status_code >= 500:
                retry_after = response.headers.get("Retry-After")
                wait = int(retry_after) if retry_after and retry_after.isdigit() else min(60, 2 ** attempt)
                time.sleep(wait)
                continue
            break
        if last is None and last_connection_error is not None:
            raise GitHubError(f"GitHub baglantisi kurulamadi: {last_connection_error}")
        assert last is not None
        try:
            detail = last.json().get("message", last.text)
        except ValueError:
            detail = last.text
        if last.status_code == 401:
            raise GitHubError(
                f"GitHub API {method} {endpoint}: 401 - Bad credentials. "
                "Token gecersiz, eksik, suresi dolmus veya iptal edilmis olabilir."
            )
        raise GitHubError(f"GitHub API {method} {endpoint}: {last.status_code} - {detail}")

    def verify_user(self) -> dict[str, Any]:
        return self.request("GET", "/user").json()

    def repo_exists(self, repo_name: str) -> bool:
        assert self.username
        response = self.request(
            "GET",
            f"/repos/{self.username}/{repo_name}",
            expected=(200, 404),
        )
        return response.status_code == 200

    def delete_repo(self, repo_name: str) -> bool:
        """Delete one slide repository. Missing repositories count as success."""
        assert self.username
        response = self.request(
            "DELETE",
            f"/repos/{self.username}/{repo_name}",
            expected=(204, 404),
        )
        return response.status_code == 204

    def create_public_repo(self, repo_name: str, description: str) -> None:
        if self.repo_exists(repo_name):
            return
        self.request(
            "POST",
            "/user/repos",
            expected=(201,),
            json={
                "name": repo_name,
                "description": description,
                "private": False,
                "has_issues": False,
                "has_projects": False,
                "has_wiki": False,
                "auto_init": False,
            },
        )
        time.sleep(2)

    def enable_pages(self, repo_name: str) -> str:
        assert self.username
        endpoint = f"/repos/{self.username}/{repo_name}/pages"
        payload = {"source": {"branch": "main", "path": "/"}}
        for attempt in range(8):
            try:
                current = self.session.get(
                    f"https://api.github.com{endpoint}", timeout=60
                )
                if current.status_code == 200:
                    update = self.session.put(
                        f"https://api.github.com{endpoint}", json=payload, timeout=60
                    )
                    if update.status_code in (200, 204):
                        data = update.json() if update.content else current.json()
                        return data.get("html_url") or f"https://{self.username}.github.io/{repo_name}/"
                elif current.status_code == 404:
                    create = self.session.post(
                        f"https://api.github.com{endpoint}", json=payload, timeout=60
                    )
                    if create.status_code == 201:
                        return create.json().get("html_url") or f"https://{self.username}.github.io/{repo_name}/"
                    if create.status_code not in (403, 409, 422, 429):
                        raise GitHubError(
                            f"Pages acilamadi ({repo_name}): {create.status_code} {create.text}"
                        )
                elif current.status_code not in (403, 429):
                    raise GitHubError(
                        f"Pages durumu alinamadi ({repo_name}): {current.status_code} {current.text}"
                    )
            except requests.RequestException:
                # Gecici baglanti kopmalarinda ayni Pages islemini yeniden dene.
                pass
            time.sleep(min(30, 2 ** attempt))
        raise GitHubError(
            f"Pages acilamadi ({repo_name}). main branch GitHub tarafinda hazir olmayabilir."
        )

    def get_pages(self, repo_name: str) -> dict[str, Any] | None:
        assert self.username
        response = self.request(
            "GET",
            f"/repos/{self.username}/{repo_name}/pages",
            expected=(200, 404),
        )
        return response.json() if response.status_code == 200 else None

    def token_scopes(self) -> str:
        """Klasik token'larda yetki listesi. Fine-grained token'larda bos doner."""
        assert self.username is not None or True
        response = self.session.get("https://api.github.com/user", timeout=30)
        return response.headers.get("X-OAuth-Scopes", "")

    def put_repo_file(
        self,
        repo_name: str,
        path: str,
        content: bytes,
        message: str,
        branch: str = "main",
    ) -> str:
        """Tek dosyayi dogrudan GitHub uzerinde olustur veya guncelle.

        Yerel repo klasoru silinmis olsa bile calisir. Workflow dosyalari icin
        token'in `workflow` yetkisi gerekir.
        """
        assert self.username
        existing = self.get_repo_file(repo_name, path, ref=branch)
        payload: dict[str, Any] = {
            "message": message,
            "content": base64.b64encode(content).decode("ascii"),
            "branch": branch,
        }
        if existing is not None:
            payload["sha"] = self.get_repo_file_sha(repo_name, path, branch)
        response = self.request(
            "PUT",
            f"/repos/{self.username}/{repo_name}/contents/{path}",
            expected=(200, 201),
            json=payload,
        )
        return str(response.json().get("commit", {}).get("sha", ""))

    def get_repo_file_sha(self, repo_name: str, path: str, ref: str = "main") -> str:
        assert self.username
        response = self.request(
            "GET",
            f"/repos/{self.username}/{repo_name}/contents/{path}",
            expected=(200, 404),
            params={"ref": ref},
        )
        if response.status_code == 404:
            return ""
        return str(response.json().get("sha", ""))

    def get_branch_sha(self, repo_name: str, branch: str = "main") -> str:
        assert self.username
        data = self.request(
            "GET",
            f"/repos/{self.username}/{repo_name}/branches/{branch}",
        ).json()
        return str(data.get("commit", {}).get("sha", ""))


    def get_repo_file(
        self,
        repo_name: str,
        path: str,
        ref: str = "main",
    ) -> tuple[bytes, str] | None:
        """Return repository file bytes and blob SHA, or None when absent."""
        assert self.username
        endpoint = f"/repos/{self.username}/{repo_name}/contents/{path}"
        response = self.request(
            "GET",
            endpoint,
            expected=(200, 404),
            params={"ref": ref},
        )
        if response.status_code == 404:
            return None
        data = response.json()
        if data.get("type") != "file":
            raise GitHubError(f"Repo yolu dosya degil: {repo_name}/{path}")
        content = str(data.get("content") or "").replace("\n", "")
        try:
            raw = base64.b64decode(content)
        except Exception as exc:
            raise GitHubError(f"Repo dosyasi cozulmedi: {repo_name}/{path}") from exc
        return raw, str(data.get("sha") or "")


    def list_workflow_runs(self, repo_name: str, *, branch: str = "main", per_page: int = 20) -> list[dict[str, Any]]:
        assert self.username
        response = self.request(
            "GET",
            f"/repos/{self.username}/{repo_name}/actions/runs",
            params={"branch": branch, "per_page": max(1, min(100, int(per_page)))},
        )
        data = response.json()
        runs = data.get("workflow_runs", []) if isinstance(data, dict) else []
        return [item for item in runs if isinstance(item, dict)]

    def latest_pages_workflow_state(self, repo_name: str, head_sha: str = "") -> dict[str, Any]:
        """Return the newest GitHub Pages workflow run visible to the token."""
        try:
            runs = self.list_workflow_runs(repo_name, branch="main", per_page=20)
        except GitHubError:
            return {}
        pages_runs: list[dict[str, Any]] = []
        for run in runs:
            name = str(run.get("name") or run.get("display_title") or "").lower()
            path = str(run.get("path") or "").lower()
            if "page" not in name and "page" not in path:
                continue
            pages_runs.append(run)
        if head_sha:
            matching = [
                run for run in pages_runs
                if str(run.get("head_sha") or "").lower() == head_sha.lower()
            ]
            if matching:
                return matching[0]
        return pages_runs[0] if pages_runs else {}

    def rerun_failed_workflow(self, repo_name: str, run_id: int) -> bool:
        """Try to re-run failed jobs. False means the token lacks Actions write or run is not rerunnable."""
        assert self.username
        response = self.request(
            "POST",
            f"/repos/{self.username}/{repo_name}/actions/runs/{int(run_id)}/rerun-failed-jobs",
            expected=(201, 403, 404, 409, 422),
            retries=1,
        )
        return response.status_code == 201

    def upsert_text_file(
        self,
        repo_name: str,
        path: str,
        content: str,
        message: str,
        branch: str = "main",
    ) -> str:
        """Create/update a tiny UTF-8 file and return the resulting commit SHA."""
        assert self.username
        current = self.get_repo_file(repo_name, path, branch)
        payload: dict[str, Any] = {
            "message": message,
            "content": base64.b64encode(content.encode("utf-8")).decode("ascii"),
            "branch": branch,
        }
        if current is not None:
            payload["sha"] = current[1]
        response = self.request(
            "PUT",
            f"/repos/{self.username}/{repo_name}/contents/{path}",
            expected=(200, 201),
            json=payload,
        )
        data = response.json()
        return str((data.get("commit") or {}).get("sha") or "")


    def remote_has_only_safe_admin_commits(
        self,
        repo_name: str,
        ancestor_sha: str,
        head_sha: str,
        *,
        allowed_paths: set[str] | None = None,
        required_content_markers: dict[str, str] | None = None,
        max_commits: int = 12,
    ) -> bool:
        """Uzak HEAD'in yerel commit uzerine yalnizca guvenli idari dosyalar ekledigini dogrula.

        Pages onarimi workflow dosyasini GitHub Contents API ile eklediginde uzak
        SHA, yerel HEAD'den bir veya birkac commit ileride olur. Yerel klasoru
        silmeden once aradaki her commit tek ebeveynli olmalı ve sadece izinli
        kucuk Pages yonetim dosyalarini degistirmelidir. Slayt/DZI dosyalarina
        dokunan, dosya silen veya merge iceren bir zincir guvenli sayilmaz.
        """
        assert self.username
        allowed = allowed_paths or {
            ".github/workflows/pages.yml",
            ".pages-retry.txt",
        }
        markers = required_content_markers or {}
        ancestor = str(ancestor_sha or "").lower()
        current = str(head_sha or "").lower()
        verified_head = current
        if not ancestor or not current:
            return False
        if ancestor == current:
            return True

        chain_reached = False
        for _ in range(max(1, int(max_commits))):
            if current == ancestor:
                chain_reached = True
                break
            try:
                data = self.request(
                    "GET",
                    f"/repos/{self.username}/{repo_name}/commits/{current}",
                ).json()
            except GitHubError:
                return False

            files = data.get("files")
            if not isinstance(files, list):
                return False
            for item in files:
                path = str((item or {}).get("filename") or "")
                status = str((item or {}).get("status") or "")
                if path not in allowed or status == "removed":
                    return False

            parents = data.get("parents")
            if not isinstance(parents, list) or len(parents) != 1:
                return False
            parent_sha = str((parents[0] or {}).get("sha") or "").lower()
            if not parent_sha or parent_sha == current:
                return False
            current = parent_sha

        if current == ancestor:
            chain_reached = True
        if not chain_reached:
            return False

        # Some safe administrative repairs also rewrite a tiny viewer shell.
        # A path allow-list alone is insufficient: verify the final remote file
        # contains the exact application marker before local data is deleted.
        for path, marker in markers.items():
            try:
                remote_file = self.get_repo_file(repo_name, path, ref=verified_head)
            except GitHubError:
                return False
            if remote_file is None:
                return False
            text = remote_file[0].decode("utf-8", errors="replace")
            if str(marker) not in text:
                return False
        return True

    def set_repo_homepage(self, repo_name: str, homepage: str) -> None:
        assert self.username
        self.request(
            "PATCH",
            f"/repos/{self.username}/{repo_name}",
            json={"homepage": homepage},
        )


def page_is_reachable(url: str, timeout_seconds: int, progress=None) -> bool:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            response = requests.get(url, timeout=20, allow_redirects=True)
            if response.status_code == 200 and "openseadragon" in response.text.lower():
                return True
        except requests.RequestException:
            pass
        if progress:
            progress("GitHub Pages yayini bekleniyor", None)
        time.sleep(10)
    return False

def page_probe_once(url: str, timeout_seconds: int = 12) -> str:
    """Return reachable, not_ready, or unavailable for one public Pages request."""
    try:
        response = requests.get(url, timeout=max(3, int(timeout_seconds)), allow_redirects=True)
    except requests.RequestException:
        return "unavailable"
    if response.status_code == 200 and "openseadragon" in response.text.lower():
        return "reachable"
    if response.status_code in (408, 425, 429) or response.status_code >= 500:
        return "unavailable"
    return "not_ready"


def page_is_reachable_once(url: str, timeout_seconds: int = 12) -> bool:
    return page_probe_once(url, timeout_seconds) == "reachable"

