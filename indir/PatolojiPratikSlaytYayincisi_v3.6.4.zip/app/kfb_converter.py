from __future__ import annotations

import json
import math
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from PIL import Image

from .config import Settings
from .templates import viewer_html
from .utils import Progress, atomic_write_json, safe_name


class ConversionError(RuntimeError):
    pass


def _format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def _to_rgb(image: Image.Image) -> Image.Image:
    """Convert to RGB while preserving white outside-slide background.

    KFBSlide usually returns opaque RGBA. For the common opaque case, a direct
    C-level conversion is much faster than creating a new image and masking.
    Only edge regions with real transparency need white compositing.
    """
    if image.mode == "RGB":
        return image
    if image.mode == "RGBA":
        alpha = image.getchannel("A")
        if alpha.getextrema() == (255, 255):
            return image.convert("RGB")
        background = Image.new("RGB", image.size, "white")
        background.paste(image, mask=alpha)
        return background
    return image.convert("RGB")


def _save_jpeg(
    image: Image.Image,
    path: Path,
    quality: int = 88,
    *,
    subsampling: int = 0,
    optimize: bool = False,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    _to_rgb(image).save(
        path,
        "JPEG",
        quality=quality,
        optimize=optimize,
        progressive=False,
        subsampling=subsampling,
    )


def _extract_associated(slide, repo_dir: Path, settings: Settings) -> bool:
    associated_dir = repo_dir / "associated"
    associated_dir.mkdir(exist_ok=True)
    names = list(slide.associated_images)
    saved: dict[str, Path] = {}
    for name in names:
        try:
            image = slide.associated_images[name]
            output = associated_dir / f"{safe_name(str(name).lower())}.jpg"
            # Keep text on labels crisp; these files are tiny compared with tiles.
            _save_jpeg(image, output, 90, subsampling=0, optimize=True)
            saved[str(name).lower()] = output
        except Exception:
            continue
    priorities = ("label", "slide_label", "slide-label", "barcode")
    selected = None
    for priority in priorities:
        for name, path in saved.items():
            if name == priority or priority in name:
                selected = path
                break
        if selected:
            break
    if selected:
        shutil.copy2(selected, repo_dir / "label.jpg")
        return True
    return False


def _write_dzi(
    path: Path,
    width: int,
    height: int,
    settings: Settings,
    tile_size: int | None = None,
) -> None:
    tile = int(settings.tile_size if tile_size is None else tile_size)
    path.write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<Image xmlns="http://schemas.microsoft.com/deepzoom/2008" '
        f'Format="jpeg" Overlap="{settings.overlap}" TileSize="{tile}">\n'
        f'  <Size Width="{width}" Height="{height}"/>\n'
        '</Image>\n',
        encoding="utf-8",
    )



def estimate_tile_count(width: int, height: int, tile_size: int) -> int:
    """Bir DZI piramidinin toplam karo sayisi."""
    max_level = int(math.ceil(math.log2(max(width, height, 2))))
    total = 0
    for level in range(max_level + 1):
        downsample = 2 ** (max_level - level)
        level_w = int(math.ceil(width / downsample))
        level_h = int(math.ceil(height / downsample))
        total += int(math.ceil(level_w / tile_size)) * int(math.ceil(level_h / tile_size))
    return total


def choose_tile_size(width: int, height: int, settings: Settings) -> tuple[int, int]:
    """Karo boyutunu sec ve tahmini karo sayisini dondur.

    Git indeksleme/yukleme maliyeti dosya sayisiyla birlikte artar. Cok buyuk
    kaynaklarda karo boyutu iki katina cikarilarak toplam dosya sayisi
    `max_tiles_per_repo` hedefinin altinda tutulur. Yayinlanmis eski slaytlar
    etkilenmez; her repo kendi slide.dzi dosyasindaki karo boyutunu kullanir.
    """
    tile = int(settings.tile_size)
    limit = int(getattr(settings, "max_tiles_per_repo", 0) or 0)
    ceiling = int(getattr(settings, "max_auto_tile_size", tile) or tile)
    count = estimate_tile_count(width, height, tile)
    if limit <= 0:
        return tile, count
    while count > limit and tile * 2 <= ceiling:
        tile *= 2
        count = estimate_tile_count(width, height, tile)
    return tile, count


def _tile_bounds(
    col: int,
    row: int,
    cols: int,
    rows: int,
    level_w: int,
    level_h: int,
    tile_size: int,
    overlap: int,
) -> tuple[int, int, int, int]:
    left = col * tile_size - (overlap if col > 0 else 0)
    top = row * tile_size - (overlap if row > 0 else 0)
    right = min(
        (col + 1) * tile_size + (overlap if col < cols - 1 else 0),
        level_w,
    )
    bottom = min(
        (row + 1) * tile_size + (overlap if row < rows - 1 else 0),
        level_h,
    )
    return left, top, right, bottom


def _save_tile(
    image: Image.Image,
    output: Path,
    quality: int,
    subsampling: int,
) -> None:
    _save_jpeg(
        image,
        output,
        quality,
        subsampling=subsampling,
        optimize=False,
    )


def _open_slide(source: Path):
    """Open KFB with kfbslide and standard WSI formats with OpenSlide."""
    suffix = source.suffix.lower()
    if suffix == ".kfb":
        try:
            import kfbslide
        except ImportError as exc:
            raise ConversionError(
                "KFB destegi (kfbslide) kurulu degil. KURULUM.bat yeniden calistirin."
            ) from exc
        try:
            return kfbslide.OpenSlide(str(source)), "KFB"
        except Exception as exc:
            raise ConversionError(f"KFB acilamadi: {exc}") from exc

    try:
        import openslide
    except ImportError as exc:
        raise ConversionError(
            "SVS/OpenSlide destegi kurulu degil. KURULUM.bat yeniden calistirin."
        ) from exc
    try:
        return openslide.OpenSlide(str(source)), suffix.lstrip(".").upper()
    except Exception as exc:
        raise ConversionError(f"{suffix or 'Slayt'} dosyasi acilamadi: {exc}") from exc


def convert_slide(
    source: Path,
    repo_dir: Path,
    settings: Settings,
    progress: Progress | None = None,
    stop_requested=None,
    jpeg_quality: int | None = None,
) -> dict:
    quality = int(settings.jpeg_quality if jpeg_quality is None else jpeg_quality)
    quality = max(35, min(92, quality))
    tile_size = int(settings.tile_size)
    overlap = int(settings.overlap)
    encode_workers = max(1, int(settings.encode_workers))
    subsampling = int(settings.jpeg_subsampling)

    repo_dir.mkdir(parents=True, exist_ok=True)
    state_file = repo_dir / "conversion_state.json"
    complete_file = repo_dir / ".conversion_complete.json"
    if complete_file.exists():
        complete_file.unlink()
    slide, source_format = _open_slide(source)

    try:
        width, height = slide.dimensions
        level_downsamples = list(slide.level_downsamples)
        max_dzi_level = int(math.ceil(math.log2(max(width, height))))

        # Kaynak boyutu belli olduktan sonra karo boyutu secilir. Cok buyuk
        # slaytlarda Git dosya sayisini makul tutmak icin karo buyutulur.
        tile_size, estimated_tiles = choose_tile_size(width, height, settings)
        if tile_size != int(settings.tile_size) and progress:
            progress(
                f"Kaynak cok buyuk: karo boyutu {settings.tile_size} yerine "
                f"{tile_size} px secildi (tahmini {estimated_tiles} karo)",
                0,
            )
        super_tile_size = max(tile_size, int(settings.super_tile_size))
        super_tile_size = max(tile_size, (super_tile_size // tile_size) * tile_size)
        block_cols = max(1, super_tile_size // tile_size)
        block_rows = block_cols
        (repo_dir / ".nojekyll").write_text("", encoding="utf-8")
        (repo_dir / ".gitignore").write_text(
            "conversion_state.json\n.conversion_complete.json\n",
            encoding="utf-8",
        )
        # JPEGs are already compressed; tell Git not to spend time searching for deltas.
        (repo_dir / ".gitattributes").write_text(
            "*.jpeg -delta\n*.jpg -delta\n*.png -delta\n",
            encoding="utf-8",
        )
        _write_dzi(repo_dir / "slide.dzi", width, height, settings, tile_size)

        if progress:
            progress("Doku on izlemesi hazirlaniyor", 0)
        thumbnail = slide.get_thumbnail((settings.thumbnail_width, settings.thumbnail_height))
        _save_jpeg(thumbnail, repo_dir / "thumbnail.jpg", 88, subsampling=0, optimize=True)
        has_label = _extract_associated(slide, repo_dir, settings)

        files_root = repo_dir / "slide_files"
        files_root.mkdir(exist_ok=True)
        total_tiles = 0
        dimensions_by_level: list[tuple[int, int, int, int]] = []
        for dzi_level in range(max_dzi_level + 1):
            downsample = 2 ** (max_dzi_level - dzi_level)
            level_w = int(math.ceil(width / downsample))
            level_h = int(math.ceil(height / downsample))
            cols = int(math.ceil(level_w / tile_size))
            rows = int(math.ceil(level_h / tile_size))
            dimensions_by_level.append((level_w, level_h, cols, rows))
            total_tiles += cols * rows

        completed = 0
        conversion_started = time.monotonic()
        report_every = max(100, total_tiles // 100)
        next_report = report_every

        with ThreadPoolExecutor(max_workers=encode_workers, thread_name_prefix="jpeg") as pool:
            for dzi_level, (level_w, level_h, cols, rows) in enumerate(dimensions_by_level):
                if stop_requested and stop_requested():
                    raise ConversionError("Islem kullanici tarafindan durduruldu.")

                target_ds = 2 ** (max_dzi_level - dzi_level)
                source_level = slide.get_best_level_for_downsample(target_ds)
                source_ds = float(level_downsamples[source_level])
                level_dir = files_root / str(dzi_level)
                level_dir.mkdir(exist_ok=True)

                for row0 in range(0, rows, block_rows):
                    for col0 in range(0, cols, block_cols):
                        if stop_requested and stop_requested():
                            raise ConversionError("Islem kullanici tarafindan durduruldu.")

                        row1 = min(rows, row0 + block_rows)
                        col1 = min(cols, col0 + block_cols)
                        pending: list[tuple[int, int, Path, tuple[int, int, int, int]]] = []

                        for row in range(row0, row1):
                            for col in range(col0, col1):
                                output = level_dir / f"{col}_{row}.jpeg"
                                bounds = _tile_bounds(
                                    col,
                                    row,
                                    cols,
                                    rows,
                                    level_w,
                                    level_h,
                                    tile_size,
                                    overlap,
                                )
                                pending.append((col, row, output, bounds))

                        if not pending:
                            continue

                        group_left = col0 * tile_size - (overlap if col0 > 0 else 0)
                        group_top = row0 * tile_size - (overlap if row0 > 0 else 0)
                        group_right = min(
                            col1 * tile_size + (overlap if col1 < cols else 0),
                            level_w,
                        )
                        group_bottom = min(
                            row1 * tile_size + (overlap if row1 < rows else 0),
                            level_h,
                        )
                        group_w = max(1, group_right - group_left)
                        group_h = max(1, group_bottom - group_top)

                        x0 = int(round(group_left * target_ds))
                        y0 = int(round(group_top * target_ds))
                        read_w = max(1, int(math.ceil(group_w * target_ds / source_ds)))
                        read_h = max(1, int(math.ceil(group_h * target_ds / source_ds)))
                        block = slide.read_region((x0, y0), source_level, (read_w, read_h))
                        block = _to_rgb(block)
                        if block.size != (group_w, group_h):
                            block = block.resize((group_w, group_h), Image.Resampling.LANCZOS)

                        futures = []
                        for _col, _row, output, (left, top, right, bottom) in pending:
                            crop = block.crop(
                                (
                                    left - group_left,
                                    top - group_top,
                                    right - group_left,
                                    bottom - group_top,
                                )
                            ).copy()
                            futures.append(
                                pool.submit(
                                    _save_tile,
                                    crop,
                                    output,
                                    quality,
                                    subsampling,
                                )
                            )

                        for future in as_completed(futures):
                            future.result()
                            completed += 1
                            if progress and (completed >= next_report or completed == total_tiles):
                                elapsed = max(0.1, time.monotonic() - conversion_started)
                                rate = completed / elapsed
                                remaining_seconds = (total_tiles - completed) / rate if rate > 0 else 0
                                progress(
                                    f"DZI: %{completed / total_tiles * 100:.0f} | "
                                    f"{completed:,}/{total_tiles:,} karo | "
                                    f"gecen {_format_duration(elapsed)} | "
                                    f"kalan ~{_format_duration(remaining_seconds)}",
                                    completed / total_tiles * 100,
                                )
                                while next_report <= completed:
                                    next_report += report_every

                        del block

                atomic_write_json(
                    state_file,
                    {
                        "width": width,
                        "height": height,
                        "max_dzi_level": max_dzi_level,
                        "last_completed_level": dzi_level,
                        "completed_tiles": completed,
                        "total_tiles": total_tiles,
                        "jpeg_quality": quality,
                        "tile_size": tile_size,
                        "super_tile_size": super_tile_size,
                        "encode_workers": encode_workers,
                        "jpeg_subsampling": subsampling,
                    },
                )

        repo_name = repo_dir.name
        (repo_dir / "index.html").write_text(
            viewer_html(
                repo_name,
                settings.github_username,
                has_label,
                settings.remote_metadata_filename,
                width=width,
                height=height,
                tile_size=tile_size,
                tile_overlap=overlap,
                tile_format="jpeg",
            ), encoding="utf-8"
        )
        metadata = {
            "gallery_id": repo_name,
            "source_format": source_format,
            "source_dimensions": [width, height],
            "source_levels": [list(x) for x in slide.level_dimensions],
            "objective_power": slide.properties.get("openslide.objective-power", ""),
            "mpp_x": slide.properties.get("openslide.mpp-x", ""),
            "has_label": has_label,
            "jpeg_quality": quality,
            "jpeg_subsampling": subsampling,
            "tile_size": tile_size,
            "super_tile_size": super_tile_size,
            "encode_workers": encode_workers,
        }
        (repo_dir / "metadata.json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (repo_dir / "README.md").write_text(
            f"# {repo_name}\n\nPatoloji pratik sanal mikroskop slayti.\n\n"
            f"[Sanal mikroskopu ac]({settings.page_url(repo_name)})\n",
            encoding="utf-8",
        )
        atomic_write_json(
            complete_file,
            {
                "gallery_id": repo_name,
                "source_name": source.name,
                "source_format": source_format,
                "width": width,
                "height": height,
                "total_tiles": total_tiles,
                "completed_tiles": completed,
                "has_label": has_label,
                "jpeg_quality": quality,
                "jpeg_subsampling": subsampling,
                "tile_size": tile_size,
                "super_tile_size": super_tile_size,
                "encode_workers": encode_workers,
            },
        )
        if progress:
            progress(
                f"{repo_name}: DZI tamamlandi | {total_tiles:,} karo | "
                f"tile {tile_size} | JPEG kalite {quality}",
                100,
            )
        return metadata
    finally:
        slide.close()


# Geriye donuk uyumluluk: eski moduller bu adi kullanabilir.
def convert_kfb(*args, **kwargs):
    return convert_slide(*args, **kwargs)
