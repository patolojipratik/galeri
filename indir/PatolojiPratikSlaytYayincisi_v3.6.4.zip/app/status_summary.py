from __future__ import annotations

from collections.abc import Iterable

PUBLISHED_STATUSES = {"published"}
WORK_QUEUE_STATUSES = {"pending", "converting", "converted", "uploading"}
PAGES_WAITING_STATUSES = {"pages_pending", "pages_error"}
REAL_ERROR_STATUSES = {"conversion_error", "upload_error"}
HIDDEN_STATUSES = {"removed", "deleted", "quarantined", "partial_removed"}


def visible_rows(rows: Iterable[dict[str, str]]) -> list[dict[str, str]]:
    return [row for row in rows if str(row.get("status") or "") not in HIDDEN_STATUSES]


def summarize_rows(rows: Iterable[dict[str, str]]) -> dict[str, object]:
    items = visible_rows(rows)
    published = sum(1 for row in items if row.get("status") in PUBLISHED_STATUSES)
    to_process = sum(1 for row in items if row.get("status") in WORK_QUEUE_STATUSES)
    pages_waiting = sum(1 for row in items if row.get("status") in PAGES_WAITING_STATUSES)
    real_errors = sum(1 for row in items if row.get("status") in REAL_ERROR_STATUSES)

    next_row = next(
        (
            row
            for row in items
            if row.get("status") in (
                WORK_QUEUE_STATUSES | REAL_ERROR_STATUSES | PAGES_WAITING_STATUSES
            )
        ),
        None,
    )
    next_item = str(next_row.get("gallery_id") or "") if next_row else "Tamamlandı"
    return {
        "total": len(items),
        "published": published,
        "to_process": to_process,
        "pages_waiting": pages_waiting,
        "real_errors": real_errors,
        "next_item": next_item,
    }
