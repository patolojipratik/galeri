# Patoloji Pratik Slayt Yayıncısı — v3.6.4 Final

Bu uygulama `E:\Pratik_slaytları` içindeki sanal slaytları sırayla işler, DZI/OpenSeadragon biçimine dönüştürür, `gallery-001`, `gallery-002` biçiminde GitHub repolarına yükler, GitHub Pages yayınını açar ve ana galeriyi günceller.

Ana galeri:

`https://patolojipratik.github.io/galeri/`

## v3.6.4 ana galeri düzeltmesi

- `Ana galeriyi yayımla`, içerik değişmemiş olsa bile küçük bir yeniden yayın commit'i gönderir ve GitHub Actions çalışmasını gerçekten başlatır.
- Galeri reposuna güvenli tam paket, SHA-256 dosyası ve son sürüm notları otomatik eklenir.
- Bu halka açık pakete token, `config`, `data`, `repos`, `work`, `logs`, kaynak slaytlar veya kullanıcıya ait yerel dosyalar alınmaz.

## v3.6.4 neden güvenli ve kolay sürüm?

- Slayt adı, organ, tanı, açıklama ve etiketler artık Python arayüzünden düzenlenir.
- CSV içine elle virgül veya tırnak işareti yazma zorunluluğu yoktur.
- Yerel bilgiler ana kaynaktır; otomatik GitHub → yerel metadata eşitlemesi varsayılan olarak kapalıdır.
- Eski veya boş çevrimiçi CSV, yerel tanıları silemez.
- Her kullanıcı düzenlemesinden önce tarih damgalı yedek oluşturulur.
- İleri kullanıcı uzaktan eşitlemeyi açarsa üç yönlü karşılaştırma yapılır; çakışmada yerel değer korunur.
- KFB ve SVS yanında OpenSlide'ın açabildiği ek formatlar taranabilir.
- Ana galeri küçük ön izlemelerle hızlı açılır; büyük ön izlemeler yalnızca istendiğinde yüklenir.
- Metadata editöründe kaydedip önceki veya sonraki slayta tek tıkla geçilebilir.
- Ana galeri sırası repo adlarını değiştirmeden yukarı/aşağı veya doğrudan sıra numarasıyla düzenlenebilir.
- Kötü yüklemeler kaynak dosyası karantinaya taşınarak GitHub reposu ve ana galeri kartıyla birlikte tamamen kaldırılabilir.
- GitHub Pages kuyruğu zaman aşımına uğrarsa slayt bozuk sayılmaz; GitHub ve yerel repo korunur, yayın daha sonra otomatik kontrol edilip yeniden tetiklenir.

## Mevcut kurulumun üzerine v3.6.2'yi kurma

Bu sürüm, gelecek güncellemeleri **BASLAT.bat** içine alan ilk sürümdür. Bu nedenle yalnızca v3.6.2'ye geçerken son kez ZIP'i elle çıkartmak gerekir:

1. Programda **GÜVENLE KAPATABİLİRSİNİZ** yazısını bekleyin.
2. Programı kapatın.
3. Ek güvenlik için `E:\github\data\slides.csv` dosyasını başka bir klasöre bir kez kopyalayabilirsiniz.
4. Güncelleme veya tam paket ZIP içeriğini doğrudan `E:\github` üzerine çıkartın.
5. Sorulduğunda dosyaları değiştirin; `E:\github` klasörünü önceden silmeyin.
6. Bundan sonra yalnızca `BASLAT.bat` çalıştırın.

Korunan veriler:

- `data\slides.csv`
- `data\slides.pending.csv`
- `data\yedek\`
- `data\yedek_kurulum\`
- `config\settings.json`
- `logs\`
- `repos\galeri`
- GitHub tokeni
- yayımlanmış slayt kayıtları

`GUNCELLE_VE_BASLAT.bat` yalnızca eski alışkanlıklar için bırakılmıştır; doğrudan `BASLAT.bat` dosyasını çağırır.


## Bundan sonraki güncellemeler: yalnızca BASLAT.bat

Gelecekte size verilen `patoloji_galeri_GUNCELLEME_vX.Y.Z.zip` dosyasını:

`E:\github\guncelleme`

klasörüne kopyalayın ve her zamanki gibi `BASLAT.bat` dosyasını açın. BASLAT:

1. Paketin bu uygulamaya ait manifestini ve her dosyanın SHA-256 karmasını doğrular.
2. `slides.csv` için güncelleme öncesi yedek oluşturur.
3. Değişecek kod dosyalarını `E:\github\yedekler` altında yedekler.
4. `config`, `data`, `repos`, `work`, `logs` ve `.venv` içindeki kullanıcı verilerini güncelleme paketine kapatır.
5. Yeni bağımlılık gerekiyorsa kodu değiştirmeden önce kurar.
6. Güncellemeyi uygular ve Python dosyalarını derleyerek kontrol eder.
7. Hata olursa önceki kodu geri yükler ve uygulamayı açmaz.
8. Başarılıysa aynı BASLAT işlemi içinde yeni sürümü açar.

Güncelleme internetten sessizce indirilmez; yalnızca sizin `guncelleme` klasörüne koyduğunuz doğrulanabilir paket uygulanır. Başarılı paketler `guncelleme\uygulandi` klasörüne taşınır.

`GUNCELLE_VE_BASLAT.bat` geriye dönük uyumluluk için kalır ancak yalnızca `BASLAT.bat` dosyasını çağırır.

## Daha anlaşılır ana ekran

Özet kutuları artık birbirinden ayrıdır:

- **İşlenecek:** henüz dönüşüm/yükleme sırası gelmemiş slaytlar.
- **Yayın bekliyor:** GitHub'a yüklenmiş ancak web sayfası henüz doğrulanmamış slaytlar.
- **İşlem hatası:** yalnızca dönüşüm veya GitHub yükleme hataları. `0` görünmesi gerçek işlem hatası olmadığını belirtir.

Eski **Pages Dağıtımını Onar** düğmesi üst araç çubuğundan kaldırılmıştır. Yerine açıklamalı bir **Yayın denetimi** alanı vardır:

- Bekleyen yayın yoksa düğme pasiftir ve “Bekleyen yayın yok” yazar.
- Bekleyen yayın varsa sayı görünür ve **Şimdi kontrol et** düğmesi etkinleşir.
- Program zaten açılışta ve boşta kaldığında otomatik kontrol yaptığı için normalde elle kullanmak gerekmez.

## Büyük SVS dosyaları ve hafif GitHub Pages yayını

GitHub Pages dağıtımı tek bir artifact üzerinden atomik olarak yapılır; parça parça gönderilen dağıtımlar birleştirilmez. Ayrıca `actions/deploy-pages` bir dağıtımı en fazla 10 dakika izler. Bu nedenle büyük SVS slaytlarında binlerce JPEG karosunu Pages artifact'ına koymak güvenilir değildir.

v3.6 depolama ile web sayfasını ayırır:

1. DZI karoları normal biçimde slaytın herkese açık `gallery-XXX` GitHub reposuna yüklenir.
2. GitHub Pages'e yalnızca küçük `index.html`, `slide.dzi`, `thumbnail.jpg`, varsa `label.jpg`, metadata ve `.nojekyll` gönderilir.
3. OpenSeadragon, kullanıcı yakınlaştırıp kaydırdıkça gerekli karoları aynı GitHub reposunun `raw.githubusercontent.com` adresinden alır.
4. Böylece Pages artifact'ı birkaç küçük dosyadan oluşur; büyük SVS yeniden dönüştürülmez ve yüzlerce MB veri tekrar yüklenmez.

Mevcut, sorunsuz çalışan eski KFB yayınları değiştirilmez. Yalnızca yeni slaytlar ve `pages_pending/pages_error` durumundaki yayınlar hafif Pages düzenine geçirilir.

### Otomatik onarım BASLAT içine gömülüdür

`BASLAT.bat` ile program açıldığında bekleyen Pages yayınları otomatik kontrol edilir. Program açık kaldığında da yaklaşık her 15 dakikada bir, aktif başka işlem yoksa bekleyen yayınlardan biri yeniden kontrol edilir.

Güvenlik kuralları:

- Pages hatası slayt bozukluğu sayılmaz.
- GitHub reposu ve yerel `repos\gallery-XXX` klasörü silinmez.
- Çalışan veya kuyrukta bir workflow varken ikinci workflow başlatılmaz.
- Sayfa tarayıcıdan doğrulanmadan ana galeriye eklenmez.
- Uzak onarım `index.html` ve `pages.yml` dosyalarını değiştirmişse, yerel temizlikten önce commit zinciri ve hafif görüntüleyici işareti doğrulanır.
- İnternet/GitHub yanıtı alınamazsa kayıt beklemede kalır.

`PAGES_ONAR.bat` yalnızca acil durum aracı olarak pakette kalır; günlük kullanımda hatırlanması gerekmez.

Ayarlar `config\settings.json` içindedir:

```json
"pages_workflow_deploy": true,
"pages_deploy_timeout_ms": 600000,
"pages_deploy_watch_seconds": 1800,
"pages_deploy_retries": 0,
"pages_retry_delay_seconds": 900,
"pages_retry_max_delay_seconds": 3600,
"pages_recent_audit_hours": 48
```

`pages_deploy_timeout_ms` eski ayar dosyalarıyla uyumluluk için tutulur; GitHub action üst sınırı 600000 ms'dir ve v3.6 bunu yükseltmeye çalışmaz.

Fine-grained token için gereken repo izinleri:

```text
Contents: Read and write
Workflows: Read and write
Actions: Read and write
Pages: Read and write
Administration: Read and write
```

Klasik token için `repo` ve `workflow` kapsamları gerekir. Yetki değiştirildikten sonra `GITHUB_BAGLA.bat` ile tokeni yeniden kaydedin.

## Slayt bilgilerini düzenleme

Ana pencerede bir slayt seçin ve **Slayt bilgilerini düzenle** düğmesine basın.

Düzenlenebilir alanlar:

- Başlık
- Organ / sistem
- Tanı
- Açıklama
- Etiketler

Etiketleri virgülle ayırabilirsiniz:

`mide, adenokarsinom, H&E, eğitim`

Tırnak işareti veya CSV kaçış karakteri yazmanız gerekmez. Uygulama bunları güvenli şekilde kaydeder.

### Kaydet

Bilgileri yerel envantere kaydeder. Önceki sürüm otomatik olarak şu klasöre yedeklenir:

`E:\github\data\yedek\`

### Kaydet ve Öncekine / Sonrakine Geç

Geçerli slayttaki bilgileri kaydeder ve soldaki görünür listede önceki veya sonraki slayta geçer. Arama filtresi açıksa geçiş filtrelenmiş sonuçlar içinde yapılır.

Klavye kısayolları:

- `Ctrl+Page Up`: kaydet ve öncekine geç
- `Ctrl+Page Down`: kaydet ve sonrakine geç

### Kaydet ve İnternette Yayınla

Bilgileri kaydeder, ana galeri reposunu yeniden oluşturur ve GitHub Pages'a gönderir. Slaytın büyük DZI dosyaları yeniden üretilmez; yalnızca küçük ana galeri dosyaları güncellenir.

## Ana galeri çalışma biçimi

Ana sayfa hızlı açılacak şekilde iki ayrı ön izleme kullanır:

- **Küçük ön izleme:** yaklaşık 360×240 piksel; ana sayfada yüklenir.
- **Büyük ön izleme:** slayt reposundaki `thumbnail.jpg`; yalnızca kartın altındaki `🔽` simgesine basıldığında indirilir.

Kart üzerinde yalnızca tanı ve organ doğrudan gösterilir. Teknik `gallery-XXX` adı, kaynak biçimi (`KFB`, `SVS` vb.) ve ayrıca bir “Sanal mikroskop” yazısı gösterilmez. Küçük ön izlemenin kendisi sanal mikroskop bağlantısıdır.

Kullanım:

1. Küçük ön izlemeye basarak sanal mikroskobu açın.
2. Kartın altındaki `🔽` simgesine basarak ayrıntıları ve ekranı kaplayan büyük ön izlemeyi açın.
3. `−`, `100%` ve `+` düğmelerini veya fare tekerleğini kullanarak yakınlaştırın.
4. Görüntüyü fareyle tutup sürükleyin. Telefonda tek parmakla kaydırın, iki parmakla yakınlaştırın.
5. `ℹ` düğmesiyle tanı, organ, açıklama ve etiket panelini gizleyip görüntü alanını genişletin.
6. `⛶` düğmesi desteklenen tarayıcılarda gerçek tam ekran görünümünü açar. `Esc` veya `×` ile kapatabilirsiniz.

Güncellemeden sonraki ilk **Ana Galeriyi Yayınla** işleminde mevcut slaytların küçük ön izlemeleri bir kez hazırlanır. Yerel slayt klasörü daha önce temizlendiyse program mevcut büyük ön izlemeyi GitHub Pages'tan indirip küçültür. Bu ilk işlem birkaç dakika sürebilir; sonraki yayınlarda küçük dosyalar yeniden kullanılır.


## Galeri sırasını değiştirme

Ana pencerede slaytı seçip şu düğmeleri kullanın:

- **↑ Yukarı**
- **↓ Aşağı**
- **Sıraya Taşı…**

Sıralama yalnızca ana galerideki gösterim sırasını değiştirir. `gallery-025` gibi repo adları ve mevcut bağlantılar değişmez. Birden fazla düzenleme yaptıktan sonra **Ana galeriyi yayımla** düğmesine basarak yeni sırayı internete aktarın.

Silinen bir repo numarası daha sonra başka bir slayt için tekrar kullanılmaz. Yeni eklenen slaytlar kalıcı sayaçtan sonraki numarayı alır.

## Kötü yüklemeyi tamamen kaldırma

Ana pencerede kaldırılacak slaytı seçip **Kötü Yüklemeyi Tamamen Kaldır…** düğmesine basın. Yanlış slaytın silinmesini önlemek için iki aşamalı onay kullanılır ve ikinci ekranda repo adının aynen yazılması gerekir.

Başarılı işlem sırası:

1. Kaynak KFB/SVS dosyası `E:\Pratik_slaytları\yüklenmeyen` klasörüne taşınır.
2. İlgili `gallery-XXX` GitHub reposu kalıcı olarak silinir.
3. Ana galerideki kart, küçük ön izleme ve metadata kaydı kaldırılır.
4. Yerel repo, geçici çalışma klasörü ve doğrulama fişi temizlenir.
5. Ana galeri otomatik yeniden yayınlanır.

Ana `galeri` reposu bu işlemle silinemez. Silme sırasında elektrik veya ağ kesilirse niyet `data\silme_bekleyen` altında kaydedilir; sonraki açılışta işlem otomatik tamamlanır. Silinen kaynak dosya doğrudan yok edilmez, `yüklenmeyen` klasöründe tutulur. Kayıt özeti `data\silinen_slaytlar` altında kalır.

GitHub tokeninin repo silme için **Administration: Read and write** izni bulunmalıdır. Yetki veya bağlantı hatasında program sesli uyarı verir ve silme işlemini sonraki açılışta yeniden dener.

## Çevrimiçi metadata eşitlemesi

v3.4'te varsayılan ayar:

```json
"sync_remote_metadata_on_start": false
```

Bu bilinçli bir güvenlik tercihidir. GitHub'daki `slayt_bilgileri.csv` artık uygulamanın ürettiği yayın çıktısıdır. Normal kullanımda GitHub web editöründen değiştirmeyin.

İleri kullanıcı bu ayarı `true` yaparsa sistem üç yönlü karşılaştırma uygular:

- yalnızca çevrimiçi taraf değişmişse çevrimiçi değer alınır,
- yalnızca yerel taraf değişmişse yerel değer korunur,
- iki taraf da değişmişse yerel değer korunur ve `data\remote_metadata_conflicts.txt` oluşturulur.

## Yeni slayt ekleme

Yeni slaytları yalnızca kaynak klasöre kopyalayın:

`E:\Pratik_slaytları`

`E:\Pratik_slaytları\yüklenmeyen` alt klasörü taranmaz; kötü yükleme olarak kaldırılan dosyalar yeniden kuyruğa eklenmez.

Program sonraki açılışta yeni dosyaları otomatik bulur ve mevcut galeri numaralarını değiştirmeden kuyruğun sonuna ekler.

Varsayılan uzantılar:

- `.kfb`
- `.svs`
- `.tif`, `.tiff`
- `.ndpi`
- `.mrxs`
- `.scn`
- `.bif`
- `.svslide`
- `.vms`, `.vmu`
- `.dcm`
- `.czi`
- `.avs`

Bir uzantının listede bulunması, ilgili dosyanın OpenSlide tarafından kesin açılacağı anlamına gelmez. Desteklenmeyen dosya hata kaydına alınır; diğer yayımlanmış slaytlar korunur.

## Çalışma düğmeleri

### Sıradaki 1 Slaytı İşle

Kuyruktaki yalnızca bir slaydı tamamlar ve durur.

### Tümünü İşle

Yayımlanmış slaytları atlar ve kalanların tamamını sırayla işler.

### Mevcut Slaytı Bitir ve Dur

Aktif slaydı yarıda kesmez. Dönüşüm ve GitHub commit doğrulaması tamamlanır. Pages kısa sürede açılırsa ana galeri güncellemesi ve yerel temizlik de tamamlanır; GitHub kuyruğu uzarsa repo silinmeden **Pages bekliyor** durumuna alınır ve program güvenli noktada durur.

Üst bölüm yeniden **GÜVENLE KAPATABİLİRSİNİZ** olduğunda bilgisayar kapatılabilir.

## Elektrik kesintisi

Tamamlanmış yayınlar tekrar işlenmez. Kesinti sırasında aktif olan yarım yerel çıktı sonraki açılışta temizlenir ve yalnızca o slayt baştan hazırlanır. Bu, farklı karo veya kalite ayarlarına ait parçaların karışmasını önleyen güvenli yaklaşımdır.

## Disk kullanımı

Bir slayt başarıyla GitHub'a yüklenip commit ve tarayıcıdan Pages doğrulaması tamamlandıktan sonra yerel `repos\gallery-XXX` klasörü silinir. Pages kuyruğu zaman aşımına uğrarsa klasör korunur. Kaynak KFB/SVS dosyası silinmez.

## Dönüşüm ayarları

Varsayılanlar:

- DZI karo: 512 px
- süper karo okuma: 2048 px
- paralel JPEG yazıcı: 4
- JPEG kalite: 72
- JPEG alt örnekleme: 4:2:0
- hedef repo üst sınırı: 800 MB
- Git fast-import: açık
- JPEG delta araması: kapalı
- çok büyük slaytlarda hedef karo sayısı: 14.000; gerekirse 1024 px karo

Otomatik 1024 px karo seçimini kapatmak için `settings.json` içinde:

```json
"max_tiles_per_repo": 0
```

Ayarlar:

`E:\github\config\settings.json`

## Dosya yapısı

```text
E:\github
├─ app\                    program modülleri
├─ config\settings.json    ayarlar
├─ data\slides.csv         temel envanter
├─ data\yedek\             metadata yedekleri
├─ data\silme_bekleyen\    yarım kalan kalıcı silme kayıtları
├─ data\silinen_slaytlar\  silme işlem özetleri
├─ logs\                   işlem günlükleri
├─ repos\galeri            ana galeri çalışma kopyası
└─ work\                   geçici çalışma alanı
```

Kaynak slaytlar ayrı kalır:

`E:\Pratik_slaytları`
