# Patoloji Pratik Slayt Yayıncısı — v3.6.4 Final

## Ana galeri yayın düzeltmesi

- `Ana galeriyi yayımla` düğmesi artık galeri içeriğinde değişiklik olmasa bile küçük bir boş commit gönderir. Böylece GitHub Pages için gerçekten yeni bir Actions çalışması başlar.
- İçerik değişmişse normal galeri commit'i kullanılır; gereksiz ikinci commit oluşturulmaz.
- GitHub Actions `Service Unavailable` gibi geçici bir altyapı hatası verirse mevcut yayın kayıtları, slayt repoları ve yerel dosyalar korunur. Yayın denetimi daha sonra yeniden kontrol eder.

## Galeri reposunda güvenli son sürüm

Ana galeri yeniden yayımlandığında `patolojipratik/galeri` reposuna şunlar eklenir:

- güvenli tam uygulama ZIP'i,
- ZIP için SHA-256 doğrulama dosyası,
- `SURUM_NOTLARI.md`,
- makine tarafından okunabilir `surum.json`,
- son sürüm bağlantılarını içeren güncel `README.md`.

Yayımlanan ZIP'e GitHub tokeni, `config`, `data/slides.csv`, `repos`, `work`, `logs`, yedekler veya kaynak KFB/SVS dosyaları alınmaz.

## Güncelleme

Güncelleme ZIP'ini açmadan `E:\github\guncelleme` klasörüne kopyalayın ve yalnızca `BASLAT.bat` çalıştırın.
