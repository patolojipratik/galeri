from __future__ import annotations

"""BASLAT.bat icin guvenli yerel guncelleme yukleyicisi.

Gelecekte verilen manifestli ve dosya karmalari belirtilmis guncelleme ZIP'i E:\\github\\guncelleme
klasorune (veya E:\\github kokune) kopyalanir. BASLAT.bat uygulama acilmadan
once paketi dogrular, kod dosyalarini yedekler, gunceller ve sonra normal
uygulamayi baslatir.

Bu modul internetten kendi kendine dosya indirmez. Bilinmeyen bir adresten
sessiz kod indirmek yerine kullanicinin bilerek koydugu, dosya karmalari
manifestte bulunan paketi uygular.
"""

import compileall
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any

APP_ID = "patoloji-pratik-galeri"
MANIFEST_NAME = "UPDATE_MANIFEST.json"
APP_ROOT = Path(__file__).resolve().parent
INBOX = APP_ROOT / "guncelleme"
APPLIED_DIR = INBOX / "uygulandi"
BACKUP_ROOT = APP_ROOT / "yedekler"
LOG_FILE = APP_ROOT / "logs" / "guncelleme.log"
LOCK_FILE = APP_ROOT / ".guncelleme_kilidi"

PACKAGE_PATTERNS = (
    "patoloji_galeri_GUNCELLEME_*.zip",
    "patoloji_galeri_guncelleme_*.zip",
    "GUNCELLEME.zip",
)

# Kullanici verisi, token, sanal slayt, repo ve calisma ciktilari bir guncelleme
# paketi tarafindan asla degistirilemez.
PROTECTED_TOP_LEVEL = {
    ".venv",
    "config",
    "data",
    "repos",
    "work",
    "logs",
    "yedekler",
    "guncelleme",
}


def _console(text: str) -> None:
    print(text, flush=True)


def _log(text: str) -> None:
    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with LOG_FILE.open("a", encoding="utf-8") as handle:
            handle.write(f"{datetime.now().isoformat(timespec='seconds')} {text}\n")
    except OSError:
        pass


def _version_tuple(value: str) -> tuple[int, ...]:
    numbers = re.findall(r"\d+", str(value))
    return tuple(int(number) for number in numbers[:4]) or (0,)


def _current_version() -> str:
    config_path = APP_ROOT / "app" / "config.py"
    try:
        text = config_path.read_text(encoding="utf-8")
    except OSError:
        return "0"
    match = re.search(r'^APP_VERSION\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
    return match.group(1) if match else "0"


def _safe_relative(raw: str) -> Path:
    posix = PurePosixPath(str(raw).replace("\\", "/"))
    if posix.is_absolute() or not posix.parts:
        raise ValueError(f"Gecersiz guncelleme yolu: {raw}")
    if any(part in {"", ".", ".."} for part in posix.parts):
        raise ValueError(f"Guvenli olmayan guncelleme yolu: {raw}")
    if ":" in posix.parts[0]:
        raise ValueError(f"Guvenli olmayan guncelleme yolu: {raw}")
    if posix.parts[0].casefold() in {item.casefold() for item in PROTECTED_TOP_LEVEL}:
        raise ValueError(f"Kullanici verisi guncelleme paketinde degistirilemez: {raw}")
    return Path(*posix.parts)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_zip_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0o170000
    return mode == 0o120000


def _read_manifest(package: Path) -> dict[str, Any]:
    with zipfile.ZipFile(package) as archive:
        try:
            raw = archive.read(MANIFEST_NAME)
        except KeyError as exc:
            raise ValueError(f"{package.name}: {MANIFEST_NAME} bulunamadi") from exc
    manifest = json.loads(raw.decode("utf-8"))
    if manifest.get("app_id") != APP_ID:
        raise ValueError(f"{package.name}: bu uygulamaya ait bir guncelleme degil")
    if not str(manifest.get("version") or "").strip():
        raise ValueError(f"{package.name}: surum bilgisi eksik")
    if not isinstance(manifest.get("files"), list) or not manifest["files"]:
        raise ValueError(f"{package.name}: dosya listesi eksik")
    return manifest


def _discover_packages() -> list[tuple[Path, dict[str, Any]]]:
    INBOX.mkdir(parents=True, exist_ok=True)
    found: dict[Path, dict[str, Any]] = {}
    invalid: list[str] = []
    locations = (APP_ROOT, INBOX)
    for location in locations:
        for pattern in PACKAGE_PATTERNS:
            for package in location.glob(pattern):
                if not package.is_file():
                    continue
                try:
                    found[package.resolve()] = _read_manifest(package)
                except Exception as exc:
                    detail = f"{package.name}: {exc}"
                    invalid.append(detail)
                    _log(f"Gecersiz guncelleme paketi: {package} - {exc}")
    if invalid:
        raise RuntimeError(
            "Guncelleme klasorunde dogrulanamayan paket var: " + " | ".join(invalid)
        )
    return sorted(
        found.items(),
        key=lambda item: (_version_tuple(item[1].get("version", "0")), item[0].stat().st_mtime),
    )


def _validate_and_stage(package: Path, manifest: dict[str, Any], stage: Path) -> tuple[list[Path], list[Path]]:
    declared: dict[str, str] = {}
    files: list[Path] = []
    for entry in manifest["files"]:
        if not isinstance(entry, dict):
            raise ValueError("Manifest dosya girdisi gecersiz")
        rel = _safe_relative(str(entry.get("path") or ""))
        expected = str(entry.get("sha256") or "").lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise ValueError(f"SHA-256 eksik veya gecersiz: {rel.as_posix()}")
        key = rel.as_posix()
        if key in declared:
            raise ValueError(f"Manifestte yinelenen dosya: {key}")
        declared[key] = expected
        files.append(rel)

    delete_paths = [_safe_relative(str(item)) for item in manifest.get("delete", [])]
    if {item.as_posix() for item in files} & {item.as_posix() for item in delete_paths}:
        raise ValueError("Bir dosya ayni pakette hem yazilip hem silinemez")

    with zipfile.ZipFile(package) as archive:
        archive_files: set[str] = set()
        for info in archive.infolist():
            if info.is_dir():
                continue
            if _is_zip_symlink(info):
                raise ValueError(f"Sembolik baglantili ZIP girdisi kabul edilmez: {info.filename}")
            normalized = PurePosixPath(info.filename).as_posix()
            if normalized == MANIFEST_NAME:
                continue
            archive_files.add(normalized)
        if archive_files != set(declared):
            extra = sorted(archive_files - set(declared))
            missing = sorted(set(declared) - archive_files)
            raise ValueError(f"ZIP/manifest dosya listesi uyusmuyor. Fazla={extra}, eksik={missing}")

        for rel in files:
            target = stage / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(rel.as_posix()) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            actual = _sha256(target)
            if actual != declared[rel.as_posix()]:
                raise ValueError(f"Dosya dogrulama hatasi: {rel.as_posix()}")

    # Paket kendi bildirdigi surumu gercekten tasiyor mu?
    staged_config = stage / "app" / "config.py"
    if staged_config.exists():
        match = re.search(
            r'^APP_VERSION\s*=\s*["\']([^"\']+)["\']',
            staged_config.read_text(encoding="utf-8"),
            re.MULTILINE,
        )
        if match and _version_tuple(match.group(1)) != _version_tuple(str(manifest["version"])):
            raise ValueError("Manifest surumu ile app/config.py surumu uyusmuyor")

    for path in stage.rglob("*.py"):
        import py_compile
        py_compile.compile(str(path), doraise=True)
    return files, delete_paths



def _prepare_runtime(stage: Path, files: list[Path]) -> None:
    """Veri yedegini al ve yeni requirements varsa kodu degistirmeden kur."""
    backup_script = APP_ROOT / "guncelle_oncesi_yedek.py"
    if backup_script.is_file():
        result = subprocess.run(
            [sys.executable, str(backup_script)],
            cwd=APP_ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "bilinmeyen hata").strip()
            raise RuntimeError(f"Guncelleme oncesi veri yedegi olusturulamadi: {detail}")

    requirements = Path("requirements.txt")
    if requirements in files:
        staged_requirements = stage / requirements
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(staged_requirements)],
            cwd=APP_ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=1800,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "bilinmeyen hata").strip()
            raise RuntimeError(f"Yeni bagimliliklar kurulamadi: {detail[-1600:]}")

def _make_backup(files: list[Path], delete_paths: list[Path], version: str) -> tuple[Path, dict[str, bool]]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = BACKUP_ROOT / f"guncelleme_oncesi_{stamp}_v{version}"
    backup.mkdir(parents=True, exist_ok=False)
    existed: dict[str, bool] = {}
    for rel in files + delete_paths:
        key = rel.as_posix()
        source = APP_ROOT / rel
        existed[key] = source.is_file()
        if source.is_file():
            destination = backup / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
    (backup / "backup_manifest.json").write_text(
        json.dumps(existed, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return backup, existed


def _atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=destination.name + ".", suffix=".new", dir=destination.parent)
    os.close(fd)
    temp = Path(temp_name)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def _rollback(backup: Path, existed: dict[str, bool], touched: list[Path]) -> None:
    for rel in reversed(touched):
        target = APP_ROOT / rel
        if existed.get(rel.as_posix(), False):
            saved = backup / rel
            if saved.is_file():
                _atomic_copy(saved, target)
        else:
            target.unlink(missing_ok=True)


def _compile_installed_code() -> bool:
    excluded = re.compile(r"[\\/](?:\.venv|data|repos|work|logs|yedekler|guncelleme)[\\/]")
    return bool(compileall.compile_dir(APP_ROOT, quiet=1, rx=excluded))


def _trim_backups(keep: int = 5) -> None:
    try:
        backups = sorted(
            (item for item in BACKUP_ROOT.glob("guncelleme_oncesi_*") if item.is_dir()),
            key=lambda item: item.stat().st_mtime,
            reverse=True,
        )
        for old in backups[keep:]:
            shutil.rmtree(old, ignore_errors=True)
    except OSError:
        pass


def _archive_package(package: Path, version: str) -> None:
    APPLIED_DIR.mkdir(parents=True, exist_ok=True)
    destination = APPLIED_DIR / f"{package.stem}_uygulandi_v{version}{package.suffix}"
    counter = 2
    while destination.exists():
        destination = APPLIED_DIR / f"{package.stem}_uygulandi_v{version}_{counter}{package.suffix}"
        counter += 1
    shutil.move(str(package), str(destination))


def _apply(package: Path, manifest: dict[str, Any]) -> bool:
    current = _current_version()
    target_version = str(manifest["version"])
    if _version_tuple(target_version) <= _version_tuple(current):
        _log(f"Eski/ayni surum paketi atlandi: {package.name} ({target_version} <= {current})")
        _archive_package(package, target_version)
        return False

    minimum = str(manifest.get("minimum_version") or "0")
    if _version_tuple(current) < _version_tuple(minimum):
        raise RuntimeError(
            f"{package.name} en az {minimum} ister; kurulu surum {current}. Ara surum eksik."
        )

    stage_root = APP_ROOT / "work" / "_guncelleme_hazirlik"
    shutil.rmtree(stage_root, ignore_errors=True)
    stage_root.mkdir(parents=True, exist_ok=True)
    files, delete_paths = _validate_and_stage(package, manifest, stage_root)
    _prepare_runtime(stage_root, files)
    backup, existed = _make_backup(files, delete_paths, target_version)
    touched: list[Path] = []
    try:
        for rel in files:
            _atomic_copy(stage_root / rel, APP_ROOT / rel)
            touched.append(rel)
        for rel in delete_paths:
            (APP_ROOT / rel).unlink(missing_ok=True)
            touched.append(rel)
        if not _compile_installed_code():
            raise RuntimeError("Guncellenen Python dosyalari derlenemedi")
        installed = _current_version()
        if _version_tuple(installed) != _version_tuple(target_version):
            raise RuntimeError(
                f"Kurulum sonrasi surum dogrulanamadi: beklenen {target_version}, bulunan {installed}"
            )
    except Exception:
        _rollback(backup, existed, touched)
        _compile_installed_code()
        raise
    finally:
        shutil.rmtree(stage_root, ignore_errors=True)

    _archive_package(package, target_version)
    _trim_backups()
    _log(f"Guncelleme uygulandi: {current} -> {target_version}; paket={package.name}")
    _console(f"Patoloji Galeri {target_version} guncellemesi uygulandi. Uygulama baslatiliyor...")
    return True


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    INBOX.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
    except FileExistsError:
        # Cok eski kalmis kilit dosyasi kendiliginden temizlenir.
        try:
            if time.time() - LOCK_FILE.stat().st_mtime > 1800:
                LOCK_FILE.unlink(missing_ok=True)
                return main()
        except OSError:
            pass
        _console("Guncelleme kontrolu zaten calisiyor. Biraz sonra yeniden BASLAT.bat kullanin.")
        return 2

    try:
        packages = _discover_packages()
        changed = False
        for package, manifest in packages:
            changed = _apply(package, manifest) or changed
        if changed:
            time.sleep(1.2)
        return 0
    except Exception as exc:
        message = f"Guncelleme uygulanamadi; mevcut surum korundu: {exc}"
        _log(message)
        _console("\n" + message)
        _console("Ayrinti: E:\\github\\logs\\guncelleme.log")
        return 2
    finally:
        LOCK_FILE.unlink(missing_ok=True)


if __name__ == "__main__":
    raise SystemExit(main())
