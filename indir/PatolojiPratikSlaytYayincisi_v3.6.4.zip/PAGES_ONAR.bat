@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================
echo  Pages dagitim onarimi
echo ================================================
echo.
echo Bu islem sanal slaytlari YENIDEN DONUSTURMEZ.
echo Karolar GitHub'da hazir; yalnizca yayin adimi tekrarlanir.
echo.
if not exist ".venv\Scripts\python.exe" (
  echo Sanal ortam bulunamadi. Once GUNCELLE_VE_BASLAT.bat calistirin.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" pages_onar.py %*
echo.
pause
