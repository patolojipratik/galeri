@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Once KURULUM.bat calistirin.
  pause
  exit /b 1
)

rem Gelecekte E:\github\guncelleme klasorune konan dogrulanmis guncelleme
rem paketi once guvenli bicimde uygulanir. Paket yoksa bu adim sessizce gecer.
".venv\Scripts\python.exe" baslat_guncelleyici.py
if errorlevel 1 (
  echo.
  echo Uygulama baslatilmadi. Guncelleme hatasi giderildikten sonra tekrar deneyin.
  pause
  exit /b 1
)

start "" ".venv\Scripts\pythonw.exe" baslat.py
