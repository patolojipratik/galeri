from __future__ import annotations

import ctypes
import os
import queue
import shutil
import threading
import tkinter as tk
import webbrowser
from datetime import datetime
from tkinter import messagebox, simpledialog, ttk

from app.config import APP_VERSION, load_settings, save_settings
from app.github_api import GitHubAPI
from app.inventory import load_rows, reorder_row, scan_sources, sync_pending_csv
from app.metadata_editor import MetadataEditor
from app.main_gallery_retry import (
    adopt_existing_main_gallery_failure,
    main_gallery_is_pending,
    main_gallery_status_text,
    service_main_gallery_once,
)
from app.pipeline import Pipeline
from app.slide_manager import delete_bad_slide
from app.status_summary import summarize_rows
from app.token_store import get_token, save_token


ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"Patoloji Pratik Slayt Yayıncısı - {APP_VERSION}")
        self.geometry("1200x780")
        self.minsize(980, 650)
        self.configure(bg="#eef2f7")

        self.settings = load_settings()
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        # stop_event yalnizca zorunlu/anlik kapatma icindir.
        # finish_after_current_event mevcut slaytin tum yayin zincirini bitirip
        # yeni slayta gecmeden guvenli noktada durur.
        self.stop_event = threading.Event()
        self.finish_after_current_event = threading.Event()
        self.worker: threading.Thread | None = None
        self._rows_cache: list[dict[str, str]] = []
        self._selection_to_restore = ""

        self._configure_styles()
        self._build()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(150, self._poll)
        self.refresh_status()
        # Tarama, kesinti kontrolu, cevrimici bilgi esitleme ve yerel temizlik
        # her acilista otomatik yapilir. Pages bekleyenleri uygulama acik
        # kaldigi surece de belirli araliklarla guvenli bicimde kontrol edilir.
        self.after(700, self.startup_prepare)
        self.after(15 * 60 * 1000, self._pages_maintenance_tick)

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("App.TFrame", background="#eef2f7")
        style.configure("Header.TFrame", background="#102847")
        style.configure(
            "HeaderTitle.TLabel",
            background="#102847",
            foreground="white",
            font=("Segoe UI", 20, "bold"),
        )
        style.configure(
            "HeaderSub.TLabel",
            background="#102847",
            foreground="#cbd8e8",
            font=("Segoe UI", 10),
        )
        style.configure(
            "Primary.TButton",
            font=("Segoe UI", 11, "bold"),
            padding=(18, 11),
            background="#225fa3",
            foreground="white",
        )
        style.map("Primary.TButton", background=[("active", "#194d88")])
        style.configure(
            "Secondary.TButton",
            font=("Segoe UI", 10),
            padding=(12, 8),
        )
        style.configure(
            "Danger.TButton",
            font=("Segoe UI", 10, "bold"),
            padding=(12, 8),
            background="#b23b3b",
            foreground="white",
        )
        style.map("Danger.TButton", background=[("active", "#922f2f")])
        style.configure(
            "Finish.TButton",
            font=("Segoe UI", 10, "bold"),
            padding=(14, 10),
            background="#d9821b",
            foreground="white",
        )
        style.map("Finish.TButton", background=[("active", "#b96d10")])
        style.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        style.configure("TNotebook.Tab", padding=(14, 8), font=("Segoe UI", 10))

    def _build(self) -> None:
        header = ttk.Frame(self, style="Header.TFrame", padding=(22, 17))
        header.pack(fill="x")
        title_box = ttk.Frame(header, style="Header.TFrame")
        title_box.pack(side="left", fill="x", expand=True)
        ttk.Label(
            title_box,
            text="Patoloji Pratik Slayt Yayıncısı",
            style="HeaderTitle.TLabel",
        ).pack(anchor="w")
        ttk.Label(
            title_box,
            text=(
                f"KFB ve SVS → sanal mikroskop → GitHub Pages  •  {APP_VERSION}"
            ),
            style="HeaderSub.TLabel",
        ).pack(anchor="w", pady=(4, 0))
        self.connection_var = tk.StringVar(value="GitHub kontrol ediliyor")
        self.connection_badge = tk.Label(
            header,
            textvariable=self.connection_var,
            bg="#1b426d",
            fg="white",
            font=("Segoe UI", 9, "bold"),
            padx=12,
            pady=7,
        )
        self.connection_badge.pack(side="right")

        main = ttk.Frame(self, style="App.TFrame", padding=(16, 14))
        main.pack(fill="both", expand=True)

        path_frame = ttk.Frame(main, style="App.TFrame")
        path_frame.pack(fill="x", pady=(0, 10))
        self.path_var = tk.StringVar(
            value=f"Kaynak: {self.settings.source_dir}    •    Çalışma: {self.settings.work_root}"
        )
        ttk.Label(path_frame, textvariable=self.path_var, background="#eef2f7").pack(
            side="left", fill="x", expand=True
        )
        self.disk_var = tk.StringVar(value="Disk bilgisi hesaplanıyor")
        ttk.Label(path_frame, textvariable=self.disk_var, background="#eef2f7").pack(
            side="right"
        )

        actions = ttk.Frame(main, style="App.TFrame")
        actions.pack(fill="x", pady=(0, 11))
        ttk.Button(
            actions,
            text="Sıradaki 1 Slaytı İşle",
            command=self.process_one,
            style="Primary.TButton",
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            actions,
            text="Tümünü İşle",
            command=self.process_all,
            style="Primary.TButton",
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            actions,
            text="Mevcut Slaytı Bitir ve Dur",
            command=self.finish_current_and_stop,
            style="Finish.TButton",
        ).pack(side="left", padx=(0, 18))

        utility = ttk.Frame(main, style="App.TFrame")
        utility.pack(fill="x", pady=(0, 11))
        ttk.Label(
            utility,
            text="Galeri araçları:",
            background="#eef2f7",
            font=("Segoe UI", 9, "bold"),
        ).pack(side="left", padx=(0, 5))
        utility_buttons = [
            ("Slayt bilgilerini düzenle", self.edit_metadata),
            ("Galeriyi aç", self.open_gallery),
            ("Ana galeriyi yayımla", self.publish_gallery),
            ("GitHub bağlantısı", self.connect_github),
        ]
        for text, command in utility_buttons:
            ttk.Button(
                utility,
                text=text,
                command=command,
                style="Secondary.TButton",
            ).pack(side="left", padx=3)

        self.safety_frame = tk.Frame(main, bg="#e6f4ea", bd=1, relief="solid")
        self.safety_frame.pack(fill="x", pady=(0, 11))
        self.safety_title = tk.Label(
            self.safety_frame,
            text="GÜVENLE KAPATABİLİRSİNİZ",
            bg="#e6f4ea",
            fg="#176b31",
            font=("Segoe UI", 14, "bold"),
            anchor="w",
            padx=14,
            pady=6,
        )
        self.safety_title.pack(fill="x")
        self.safety_detail = tk.Label(
            self.safety_frame,
            text="Aktif işlem yok.",
            bg="#e6f4ea",
            fg="#244b2e",
            font=("Segoe UI", 10),
            anchor="w",
            justify="left",
            wraplength=1120,
            padx=14,
            pady=8,
        )
        self.safety_detail.pack(fill="x")

        cards = ttk.Frame(main, style="App.TFrame")
        cards.pack(fill="x", pady=(0, 10))
        self.card_vars: dict[str, tk.StringVar] = {}
        self.card_frames: dict[str, tk.Frame] = {}
        self.card_value_labels: dict[str, tk.Label] = {}
        card_specs = [
            ("total", "Toplam slayt", "0"),
            ("published", "Yayında", "0"),
            ("to_process", "İşlenecek", "0"),
            ("pages_waiting", "Yayın bekliyor", "0"),
            ("errors", "İşlem hatası", "0"),
            ("next", "Sıradaki işlem", "—"),
        ]
        for index, (key, label, default) in enumerate(card_specs):
            frame = tk.Frame(cards, bg="white", bd=1, relief="solid", padx=13, pady=8)
            frame.grid(row=0, column=index, padx=(0, 8 if index < len(card_specs) - 1 else 0), sticky="ew")
            self.card_frames[key] = frame
            cards.columnconfigure(index, weight=1)
            tk.Label(
                frame,
                text=label,
                bg="white",
                fg="#657287",
                font=("Segoe UI", 9),
            ).pack(anchor="w")
            var = tk.StringVar(value=default)
            self.card_vars[key] = var
            value_label = tk.Label(
                frame,
                textvariable=var,
                bg="white",
                fg="#17375e",
                font=("Segoe UI", 16, "bold"),
            )
            value_label.pack(anchor="w")
            self.card_value_labels[key] = value_label

        publication_bar = tk.Frame(main, bg="white", bd=1, relief="solid", padx=12, pady=9)
        publication_bar.pack(fill="x", pady=(0, 10))
        publication_text = tk.Frame(publication_bar, bg="white")
        publication_text.pack(side="left", fill="x", expand=True)
        tk.Label(
            publication_text,
            text="Yayın denetimi",
            bg="white",
            fg="#17375e",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")
        self.pages_help_var = tk.StringVar(
            value="Bekleyen yayın yok. Web sayfaları tamamlanmış görünüyor."
        )
        tk.Label(
            publication_text,
            textvariable=self.pages_help_var,
            bg="white",
            fg="#657287",
            font=("Segoe UI", 9),
            anchor="w",
        ).pack(anchor="w", pady=(2, 0))
        self.pages_repair_button = ttk.Button(
            publication_bar,
            text="Bekleyen yayınları şimdi kontrol et",
            command=self.repair_pages,
            style="Secondary.TButton",
            state="disabled",
        )
        self.pages_repair_button.pack(side="right", padx=(12, 0))

        status_line = ttk.Frame(main, style="App.TFrame")
        status_line.pack(fill="x")
        self.status_var = tk.StringVar(value="Hazır")
        ttk.Label(
            status_line,
            textvariable=self.status_var,
            background="#eef2f7",
            font=("Segoe UI", 10),
        ).pack(side="left", fill="x", expand=True)
        self.progress = ttk.Progressbar(status_line, mode="determinate", maximum=100, length=360)
        self.progress.pack(side="right", padx=(12, 0))

        self.notebook = ttk.Notebook(main)
        self.notebook.pack(fill="both", expand=True, pady=(10, 0))
        self.slides_frame = ttk.Frame(self.notebook)
        self.log_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.slides_frame, text="Slaytlar")
        self.notebook.add(self.log_frame, text="İşlem Günlüğü")

        toolbar = ttk.Frame(self.slides_frame, padding=(0, 0, 0, 7))
        toolbar.pack(fill="x")
        ttk.Label(toolbar, text="Ara:").pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self._fill_tree())
        ttk.Entry(toolbar, textvariable=self.search_var, width=38).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Seçili Slaytı Aç", command=self.open_selected_slide).pack(
            side="left", padx=4
        )
        ttk.Button(toolbar, text="Slayt bilgilerini düzenle", command=self.edit_metadata).pack(
            side="left", padx=4
        )
        ttk.Button(toolbar, text="Listeyi Yenile", command=self.refresh_status).pack(
            side="left", padx=4
        )
        ttk.Label(
            toolbar,
            text="Yeni KFB/SVS dosyaları bir sonraki açılışta otomatik eklenir.",
        ).pack(side="right")

        managebar = ttk.Frame(self.slides_frame, padding=(0, 0, 0, 7))
        managebar.pack(fill="x")
        ttk.Label(managebar, text="Galeri sırası:").pack(side="left")
        ttk.Button(
            managebar, text="↑ Yukarı", command=lambda: self.move_selected_order(-1)
        ).pack(side="left", padx=(6, 3))
        ttk.Button(
            managebar, text="↓ Aşağı", command=lambda: self.move_selected_order(1)
        ).pack(side="left", padx=3)
        ttk.Button(
            managebar, text="Sıraya Taşı…", command=self.move_selected_to_position
        ).pack(side="left", padx=3)
        ttk.Label(
            managebar,
            text="Repo adları değişmez; yalnızca ana sayfadaki gösterim sırası değişir.",
        ).pack(side="left", padx=10)
        ttk.Button(
            managebar,
            text="Kötü Yüklemeyi Tamamen Kaldır…",
            command=self.remove_selected_bad_slide,
            style="Danger.TButton",
        ).pack(side="right")

        columns = ("order", "number", "gallery", "source", "format", "diagnosis", "status", "local")
        self.slides_tree = ttk.Treeview(
            self.slides_frame,
            columns=columns,
            show="headings",
            selectmode="browse",
        )
        headings = {
            "order": "Sıra",
            "number": "No",
            "gallery": "Repo",
            "source": "Kaynak dosya",
            "format": "Tür",
            "diagnosis": "Tanı / Başlık",
            "status": "Durum",
            "local": "Yerel",
        }
        widths = {
            "order": 52,
            "number": 52,
            "gallery": 105,
            "source": 245,
            "format": 60,
            "diagnosis": 310,
            "status": 115,
            "local": 90,
        }
        for name in columns:
            self.slides_tree.heading(name, text=headings[name])
            self.slides_tree.column(name, width=widths[name], anchor="w")
        tree_scroll = ttk.Scrollbar(
            self.slides_frame,
            orient="vertical",
            command=self.slides_tree.yview,
        )
        self.slides_tree.configure(yscrollcommand=tree_scroll.set)
        self.slides_tree.pack(side="left", fill="both", expand=True)
        tree_scroll.pack(side="right", fill="y")
        self.slides_tree.bind("<Double-1>", lambda _event: self.open_selected_slide())

        self.log = tk.Text(
            self.log_frame,
            wrap="word",
            bg="#101722",
            fg="#d9e4f2",
            insertbackground="white",
            font=("Consolas", 9),
            padx=10,
            pady=10,
        )
        log_scroll = ttk.Scrollbar(self.log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=log_scroll.set)
        self.log.pack(side="left", fill="both", expand=True)
        log_scroll.pack(side="right", fill="y")

    def _set_summary_card(self, key: str, state: str) -> None:
        palette = {
            "normal": ("white", "#17375e"),
            "ok": ("#edf8f0", "#176b31"),
            "info": ("#edf4fb", "#225fa3"),
            "warning": ("#fff4d6", "#855600"),
            "error": ("#fde8e8", "#a61b1b"),
        }
        bg, fg = palette.get(state, palette["normal"])
        frame = self.card_frames.get(key)
        value = self.card_value_labels.get(key)
        if frame is not None:
            frame.configure(bg=bg)
            for child in frame.winfo_children():
                if isinstance(child, tk.Label):
                    child.configure(bg=bg)
        if value is not None:
            value.configure(fg=fg)

    def _set_safety_state(self, state: str, title: str, detail: str) -> None:
        palette = {
            "safe": ("#e6f4ea", "#176b31", "#244b2e"),
            "working": ("#fff3cd", "#855600", "#664d03"),
            "attention": ("#fde8e8", "#a61b1b", "#6f1d1d"),
        }
        bg, title_fg, detail_fg = palette.get(state, palette["safe"])
        self.safety_frame.configure(bg=bg)
        self.safety_title.configure(text=title, bg=bg, fg=title_fg)
        self.safety_detail.configure(text=detail, bg=bg, fg=detail_fg)

    def _refresh_safety_state(self, rows=None) -> None:
        if self.worker and self.worker.is_alive():
            return
        try:
            rows = rows if rows is not None else load_rows(self.settings)
            summary = summarize_rows(rows)
            published = int(summary["published"])
            errors = int(summary["real_errors"])
            pending = int(summary["to_process"])
            pages_waiting = int(summary["pages_waiting"])
            main_gallery_waiting = main_gallery_is_pending(self.settings)
            if errors:
                detail = (
                    f"{published} slayt yayında; {errors} dönüşüm/yükleme hatası var. Aktif işlem yok. "
                    "Programı kapatabilir veya Tümünü İşle ile yeniden deneyebilirsiniz."
                )
            elif pages_waiting or main_gallery_waiting:
                waiting_parts = []
                if main_gallery_waiting:
                    waiting_parts.append("ana galeri")
                if pages_waiting:
                    waiting_parts.append(f"{pages_waiting} slayt sayfası")
                detail = (
                    f"{published} slayt yayında; " + " ve ".join(waiting_parts) +
                    " web yayını doğrulama bekliyor. Dosyalar korunuyor. "
                    "Programı kapatabilirsiniz; sonraki açılışta otomatik kontrol edilir."
                )
            elif pending:
                detail = (
                    f"{published} slayt yayında, {pending} slayt bekliyor. "
                    "Programı kapatabilir; daha sonra Tümünü İşle ile devam edebilirsiniz."
                )
            else:
                detail = f"{published} slaydın tamamı yayında. Programı güvenle kapatabilirsiniz."
            self._set_safety_state("safe", "GÜVENLE KAPATABİLİRSİNİZ", detail)
        except Exception:
            self._set_safety_state("safe", "GÜVENLE KAPATABİLİRSİNİZ", "Aktif işlem yok.")

    def _set_awake(self, enabled: bool) -> None:
        if os.name != "nt" or not self.settings.prevent_sleep_during_work:
            return
        try:
            flags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED if enabled else ES_CONTINUOUS
            ctypes.windll.kernel32.SetThreadExecutionState(flags)
        except Exception:
            pass

    def write_log(self, text: str) -> None:
        line = text.rstrip()
        self.log.insert("end", line + "\n")
        self.log.see("end")
        try:
            self.settings.logs_dir.mkdir(parents=True, exist_ok=True)
            with (self.settings.logs_dir / "app.log").open("a", encoding="utf-8") as handle:
                handle.write(f"{datetime.now().isoformat(timespec='seconds')} {line}\n")
                handle.flush()
        except OSError:
            pass

    def progress_callback(self, message: str, percent: float | None = None) -> None:
        self.events.put(("progress", (message, percent)))

    def _error_beep(self) -> None:
        def sound() -> None:
            try:
                if os.name == "nt":
                    import winsound
                    for frequency in (1050, 720, 1050):
                        winsound.Beep(frequency, 270)
                    winsound.MessageBeep(winsound.MB_ICONHAND)
                else:
                    self.bell()
            except Exception:
                try:
                    self.bell()
                except Exception:
                    pass

        threading.Thread(target=sound, daemon=True).start()

    def _poll(self) -> None:
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "progress":
                    message, percent = payload
                    self.status_var.set(str(message))
                    self.write_log(str(message))
                    self._set_safety_state(
                        "working",
                        "KAPATMAYIN — İŞLEM DEVAM EDİYOR",
                        str(message) + "  •  Ekran kapanabilir; bilgisayar uykuya geçmez.",
                    )
                    if percent is None:
                        self.progress.configure(mode="indeterminate")
                        self.progress.start(12)
                    else:
                        self.progress.stop()
                        self.progress.configure(mode="determinate")
                        self.progress["value"] = float(percent)
                elif kind == "refresh":
                    self.refresh_status()
                elif kind == "error":
                    self.progress.stop()
                    self._error_beep()
                    self.write_log("HATA: " + str(payload))
                    self.status_var.set("İşlem hatayla durdu")
                    self._set_safety_state(
                        "attention",
                        "İŞLEM HATAYLA DURDU — ŞİMDİ KAPATABİLİRSİNİZ",
                        "Hata kaydedildi. Sonraki açılışta otomatik kontrol yapılır; "
                        "Tümünü İşle ile yeniden deneyebilirsiniz.",
                    )
                    self.refresh_status(keep_safety=True)
                    messagebox.showerror("Hata", str(payload))
                    self.notebook.select(self.log_frame)
                elif kind == "done":
                    self.progress.stop()
                    self.progress.configure(mode="determinate")
                    self.progress["value"] = 100
                    self.write_log(str(payload))
                    self.status_var.set(str(payload))
                    self.refresh_status()
        except queue.Empty:
            pass
        self.after(150, self._poll)

    def _run(self, target, done_message: str = "İşlem tamamlandı.") -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("İşlem sürüyor", "Önce mevcut işlemi tamamlayın veya durdurun.")
            return
        self.stop_event.clear()
        self.finish_after_current_event.clear()
        self._set_safety_state(
            "working",
            "KAPATMAYIN — İŞLEM BAŞLADI",
            "Pencereyi kapatmayın ve harici diski çıkarmayın. "
            "Mevcut Slaytı Bitir ve Dur, aktif slaytı tamamen yayımlayıp güvenli noktada durur.",
        )

        def wrapped() -> None:
            self._set_awake(True)
            try:
                target()
            except Exception as exc:
                self.events.put(("error", exc))
            else:
                self.events.put(("done", done_message))
            finally:
                self._set_awake(False)

        self.worker = threading.Thread(target=wrapped, daemon=True)
        self.worker.start()

    def startup_prepare(self) -> None:
        if self.worker and self.worker.is_alive():
            return

        def task() -> None:
            rows = scan_sources(self.settings)
            formats = ", ".join(self.settings.supported_extensions[:4])
            self.progress_callback(
                f"Açılış kontrolü: {len(rows)} slayt bulundu ({formats} …)",
                15,
            )
            token = get_token(self.settings.github_username)
            if token:
                pipeline = Pipeline(self.settings, self.progress_callback)
                pipeline.recover()
                adopt_existing_main_gallery_failure(
                    self.settings, pipeline.api, self.progress_callback
                )
                if main_gallery_is_pending(self.settings):
                    pipeline.service_main_gallery_once(force=False)
            else:
                self.progress_callback(
                    "Slayt listesi hazır. Yayın için önce GitHub Bağla düğmesini kullanın.",
                    100,
                )
            self.events.put(("refresh", None))

        self._run(task, "Açılış kontrolü tamamlandı. Sistem hazır.")

    def _pages_maintenance_tick(self) -> None:
        """Idle durumunda bekleyen Pages yayinlarindan birini otomatik kontrol et."""
        try:
            if self.worker and self.worker.is_alive():
                return
            rows = load_rows(self.settings)
            waiting = [
                row for row in rows
                if row.get("status") in {"pages_pending", "pages_error"}
            ]
            main_waiting = main_gallery_is_pending(self.settings)
            if (not waiting and not main_waiting) or not get_token(self.settings.github_username):
                return

            def task() -> None:
                pipeline = Pipeline(
                    self.settings,
                    self.progress_callback,
                    self.stop_event.is_set,
                )
                if main_waiting:
                    pipeline.service_main_gallery_once(force=False)
                if waiting:
                    pipeline.service_pending_pages_once()
                self.events.put(("refresh", None))

            self._run(task, "Otomatik Pages kontrolü tamamlandı.")
        finally:
            # Uygulama acik kaldigi surece her 15 dakikada bir yeniden bak.
            self.after(15 * 60 * 1000, self._pages_maintenance_tick)

    def connect_github(self) -> None:
        token = simpledialog.askstring(
            "GitHub Bağlantısı",
            f"{self.settings.github_username} hesabının fine-grained tokenini yapıştırın:",
            show="*",
            parent=self,
        )
        if not token:
            return
        try:
            profile = GitHubAPI(token).verify_user()
            login = profile["login"]
            if login.lower() != self.settings.github_username.lower():
                if not messagebox.askyesno(
                    "Farklı hesap",
                    f"Token {login} hesabına ait. Bu hesap kullanılsın mı?",
                ):
                    return
            self.settings.github_username = login
            self.settings.commit_email = f"{profile['id']}+{login}@users.noreply.github.com"
            save_settings(self.settings)
            save_token(login, token)
            self.connection_var.set(f"GitHub: {login}")
            messagebox.showinfo("Başarılı", f"GitHub bağlandı: {login}")
            self.write_log(f"GitHub bağlandı: {login}")
        except Exception as exc:
            self._error_beep()
            messagebox.showerror("Bağlantı hatası", str(exc))

    def process_one(self) -> None:
        def task() -> None:
            Pipeline(
                self.settings,
                self.progress_callback,
                self.stop_event.is_set,
            ).process_one()
            self.events.put(("refresh", None))

        self._run(task, "Sıradaki slayt işlemi tamamlandı.")

    def process_all(self) -> None:
        def task() -> None:
            pipeline = Pipeline(
                self.settings,
                self.progress_callback,
                self.stop_event.is_set,
            )
            pipeline.recover()
            while not self.stop_event.is_set():
                result = pipeline.process_one()
                self.events.put(("refresh", None))
                if result is None:
                    break
                if self.finish_after_current_event.is_set():
                    self.progress_callback(
                        "Mevcut slayt tümüyle tamamlandı. Yeni slayt başlatılmayacak.",
                        100,
                    )
                    break

        self._run(task, "Kuyruk tamamlandı veya mevcut slayt bitirilerek güvenli biçimde durduruldu.")

    def repair_pages(self) -> None:
        """Bekleyen slayt ve ana galeri web yayınlarını güvenli biçimde denetler."""
        from app.github_api import GitHubAPI
        from app.pages_repair import candidates, repair_all
        from app.token_store import get_token

        preview_rows = candidates(self.settings)
        main_pending = main_gallery_is_pending(self.settings)
        if not preview_rows and not main_pending:
            messagebox.showinfo(
                "Yayınlar tamam",
                "Bekleyen web yayını bulunmuyor. Slayt sayfaları ve ana galeri güncel görünüyor.",
            )
            return

        parts = []
        if main_pending:
            parts.append("Ana galeri web yayını")
        if preview_rows:
            names = ", ".join(str(r.get("gallery_id") or "") for r in preview_rows[:10])
            if len(preview_rows) > 10:
                names += f" (+{len(preview_rows) - 10})"
            parts.append(f"{len(preview_rows)} slayt sayfası: {names}")
        detail = "\n".join(parts)
        if not messagebox.askyesno(
            "Bekleyen yayınları kontrol et",
            f"Henüz doğrulanmamış yayınlar:\n\n{detail}\n\n"
            "Sanal slaytlar yeniden dönüştürülmez ve GitHub repoları silinmez. "
            "Yalnızca web yayın durumu kontrol edilir.\n\nŞimdi kontrol edilsin mi?",
        ):
            return

        def task() -> None:
            token = get_token(self.settings.github_username)
            if not token:
                raise RuntimeError("GitHub tokeni bulunamadı. Önce GitHub bağlantısını yapın.")
            api = GitHubAPI(token, self.settings.github_username)
            main_result = "idle"
            if main_pending:
                main_result, _ = service_main_gallery_once(
                    self.settings, api, token, self.progress_callback, force=True
                )
            summary = {"basarili": 0, "basarisiz": 0}
            if preview_rows:
                summary = repair_all(
                    self.settings,
                    api,
                    None,
                    self.progress_callback,
                    self.stop_event.is_set,
                )
            self.progress_callback(
                f"Yayın denetimi tamamlandı. Ana galeri: {main_result}; "
                f"slayt başarılı: {summary['basarili']}, başarısız: {summary['basarisiz']}",
                100,
            )
            self.events.put(("refresh", None))

        self._run(task, "Bekleyen yayın kontrolü tamamlandı.")

    def publish_gallery(self) -> None:
        def task() -> None:
            url = Pipeline(self.settings, self.progress_callback).publish_main_gallery()
            self.progress_callback(
                f"Ana galeri GitHub'a gönderildi; web yayını arka planda doğrulanacak: {url}",
                100,
            )
            self.events.put(("refresh", None))

        self._run(task, "Ana galeri GitHub'a gönderildi. Web yayını otomatik izlenecek.")

    def finish_current_and_stop(self) -> None:
        if not (self.worker and self.worker.is_alive()):
            self._refresh_safety_state()
            return
        if self.finish_after_current_event.is_set():
            return
        self.finish_after_current_event.set()
        self.write_log(
            "Güvenli durma istendi. Aktif slayt dönüştürme, GitHub yükleme, "
            "Pages doğrulama aşamasına kadar ilerleyecek; Pages kuyruğu uzarsa repo "
            "korunup güvenli beklemeye alınacak ve yeni slayt başlatılmayacak."
        )
        self._set_safety_state(
            "working",
            "MEVCUT SLAYT BİTİRİLECEK — HENÜZ KAPATMAYIN",
            "Aktif slayt yayımlanacak; Pages kuyruğu uzarsa repo silinmeden güvenli beklemeye "
            "alınacak. Üstte GÜVENLE KAPATABİLİRSİNİZ yazısını bekleyin.",
        )

    def open_csv(self) -> None:
        scan_sources(self.settings)
        if not sync_pending_csv(self.settings, retries=3):
            messagebox.showwarning(
                "CSV açık",
                "slides.csv başka bir program tarafından kilitli. Excel/Not Defteri penceresini "
                "kapatıp yeniden deneyin. Güncel durum slides.pending.csv içinde güvende.",
            )
            return
        if os.name == "nt":
            os.startfile(self.settings.slides_csv)
        else:
            webbrowser.open(self.settings.slides_csv.as_uri())

    def _selected_gallery_id(self) -> str:
        selection = self.slides_tree.selection()
        if not selection:
            return ""
        tags = self.slides_tree.item(selection[0], "tags")
        return str(tags[0]) if tags else ""

    def edit_metadata(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(
                "İşlem sürüyor",
                "Slayt bilgilerini düzenlemek için aktif slaydın tamamlanmasını bekleyin.",
            )
            return
        scan_sources(self.settings)
        MetadataEditor(
            self,
            self.settings,
            selected_gallery_id=self._selected_gallery_id(),
            on_saved=self.refresh_status,
            on_publish=self.publish_gallery,
        )

    def move_selected_order(self, direction: int) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("İşlem sürüyor", "Sıralamayı değiştirmek için aktif işlemin bitmesini bekleyin.")
            return
        gallery_id = self._selected_gallery_id()
        if not gallery_id:
            messagebox.showinfo("Slayt seçin", "Önce listeden bir slayt seçin.")
            return
        try:
            reorder_row(self.settings, gallery_id, direction=direction)
            self._selection_to_restore = gallery_id
            self.refresh_status()
            self.status_var.set("Galeri sırası değiştirildi. İnternete aktarmak için Ana galeriyi yayımla düğmesine basın.")
        except Exception as exc:
            messagebox.showerror("Sıralama hatası", str(exc))

    def move_selected_to_position(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("İşlem sürüyor", "Sıralamayı değiştirmek için aktif işlemin bitmesini bekleyin.")
            return
        gallery_id = self._selected_gallery_id()
        if not gallery_id:
            messagebox.showinfo("Slayt seçin", "Önce listeden bir slayt seçin.")
            return
        row = next((item for item in self._rows_cache if item.get("gallery_id") == gallery_id), None)
        current = int((row or {}).get("display_order") or (row or {}).get("number") or 1)
        target = simpledialog.askinteger(
            "Galeri sırası",
            f"{gallery_id} için yeni sıra numarası (1-{max(1, len(self._rows_cache))}):",
            initialvalue=current,
            minvalue=1,
            maxvalue=max(1, len(self._rows_cache)),
            parent=self,
        )
        if target is None:
            return
        try:
            reorder_row(self.settings, gallery_id, target_position=target)
            self._selection_to_restore = gallery_id
            self.refresh_status()
            self.status_var.set("Galeri sırası değiştirildi. İnternete aktarmak için Ana galeriyi yayımla düğmesine basın.")
        except Exception as exc:
            messagebox.showerror("Sıralama hatası", str(exc))

    def remove_selected_bad_slide(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(
                "İşlem sürüyor",
                "Kötü yüklemeyi kaldırmak için aktif işlemin tamamlanmasını bekleyin.",
            )
            return
        gallery_id = self._selected_gallery_id()
        row = next((item for item in self._rows_cache if item.get("gallery_id") == gallery_id), None)
        if not row:
            messagebox.showinfo("Slayt seçin", "Önce kaldırılacak slaytı seçin.")
            return
        source_name = row.get("source_name", "")
        accepted = messagebox.askyesno(
            "Kötü yüklemeyi tamamen kaldır",
            f"{gallery_id} / {source_name} kaldırılacak.\n\n"
            f"• Kaynak dosya {self.settings.rejected_path} klasörüne taşınacak.\n"
            "• GitHub reposu kalıcı olarak silinecek.\n"
            "• Ana galerideki kart ve küçük ön izleme kaldırılacak.\n"
            "• Repo numarası daha sonra yeniden kullanılmayacak.\n\n"
            "Bu işlem devam etsin mi?",
            icon="warning",
        )
        if not accepted:
            return
        typed = simpledialog.askstring(
            "Silme onayı",
            f"Kalıcı GitHub silmesini onaylamak için {gallery_id} yazın:",
            parent=self,
        )
        if (typed or "").strip() != gallery_id:
            messagebox.showinfo("İptal edildi", "Repo adı eşleşmedi; hiçbir şey silinmedi.")
            return

        def task() -> None:
            token = get_token(self.settings.github_username)
            if not token:
                raise RuntimeError("GitHub tokeni bulunamadı. Önce GitHub Bağla işlemini yapın.")
            api = GitHubAPI(token, self.settings.github_username)
            destination = delete_bad_slide(
                self.settings, api, gallery_id, self.progress_callback
            )
            url = Pipeline(self.settings, self.progress_callback).publish_main_gallery()
            destination_text = str(destination) if destination else "Kaynak dosya diskte bulunamadı"
            self.progress_callback(
                f"{gallery_id} tamamen kaldırıldı. Kaynak: {destination_text}. Galeri: {url}",
                100,
            )
            self.events.put(("refresh", None))

        self._run(task, f"{gallery_id} tamamen kaldırıldı ve ana galeri güncellendi.")

    def open_gallery(self) -> None:
        webbrowser.open(
            f"https://{self.settings.github_username}.github.io/{self.settings.gallery_repo}/"
        )

    def open_selected_slide(self) -> None:
        selection = self.slides_tree.selection()
        if not selection:
            return
        gallery_id = str(self.slides_tree.item(selection[0], "tags")[0])
        row = next((r for r in self._rows_cache if r.get("gallery_id") == gallery_id), None)
        if row and row.get("status") == "published" and row.get("page_url"):
            webbrowser.open(row["page_url"])
        elif row:
            messagebox.showinfo("Henüz yayında değil", "Seçili slayt henüz GitHub Pages'ta yayınlanmadı.")

    def _status_text(self, row: dict[str, str]) -> str:
        mapping = {
            "pending": "İşlenmeyi bekliyor",
            "converting": "Dönüştürülüyor",
            "converted": "Yükleme bekliyor",
            "uploading": "Yükleniyor",
            "published": "Yayında",
            "pages_pending": "Yayın doğrulaması bekliyor",
            "pages_error": "Yayın yeniden denenecek",
            "conversion_error": "Dönüşüm hatası",
            "upload_error": "Yükleme hatası",
            "deleting": "Siliniyor",
        }
        return mapping.get(row.get("status", ""), row.get("status", "") or "—")

    def _fill_tree(self) -> None:
        term = self.search_var.get().strip().casefold() if hasattr(self, "search_var") else ""
        for item in self.slides_tree.get_children():
            self.slides_tree.delete(item)
        for row in self._rows_cache:
            searchable = " ".join(
                str(row.get(k, ""))
                for k in ("gallery_id", "source_name", "source_format", "title", "organ", "diagnosis", "description", "tags", "status")
            ).casefold()
            if term and term not in searchable:
                continue
            local = "Silindi" if row.get("local_status") == "deleted" else (
                "Temizlenecek" if row.get("local_status") else "Mevcut"
            )
            title = row.get("diagnosis") or row.get("title") or ""
            item_id = self.slides_tree.insert(
                "",
                "end",
                values=(
                    row.get("display_order") or row.get("number", ""),
                    row.get("number", ""),
                    row.get("gallery_id", ""),
                    row.get("source_name", ""),
                    row.get("source_format", "") or os.path.splitext(row.get("source_name", ""))[1].lstrip(".").upper(),
                    title,
                    self._status_text(row),
                    local,
                ),
                tags=(row.get("gallery_id", ""),),
            )
            if row.get("gallery_id") == self._selection_to_restore:
                self.slides_tree.selection_set(item_id)
                self.slides_tree.focus(item_id)
                self.slides_tree.see(item_id)
        self._selection_to_restore = ""

    def refresh_status(self, keep_safety: bool = False) -> None:
        try:
            rows = load_rows(self.settings)
            rows.sort(
                key=lambda r: (
                    int(r.get("display_order") or r.get("number") or 0),
                    int(r.get("number") or 0),
                )
            )
            self._rows_cache = rows
            summary = summarize_rows(rows)
            published = int(summary["published"])
            to_process = int(summary["to_process"])
            pages_waiting = int(summary["pages_waiting"])
            errors = int(summary["real_errors"])
            next_item = str(summary["next_item"])
            self.card_vars["total"].set(str(summary["total"]))
            self.card_vars["published"].set(str(published))
            self.card_vars["to_process"].set(str(to_process))
            self.card_vars["pages_waiting"].set(str(pages_waiting))
            self.card_vars["errors"].set(str(errors))
            self.card_vars["next"].set(next_item)

            self._set_summary_card("published", "ok" if published else "normal")
            self._set_summary_card("to_process", "info" if to_process else "normal")
            self._set_summary_card("pages_waiting", "warning" if pages_waiting else "ok")
            self._set_summary_card("errors", "error" if errors else "ok")
            main_waiting = main_gallery_is_pending(self.settings)
            main_text = main_gallery_status_text(self.settings)
            if pages_waiting or main_waiting:
                slide_text = (
                    f" {pages_waiting} slayt sayfası da doğrulama bekliyor."
                    if pages_waiting else ""
                )
                self.pages_help_var.set(
                    main_text + slide_text +
                    " Program açılışta ve boşta kaldığında otomatik kontrol eder."
                )
                total_waiting = pages_waiting + (1 if main_waiting else 0)
                self.pages_repair_button.configure(
                    state="normal",
                    text=f"Yayınları şimdi kontrol et ({total_waiting})",
                )
            else:
                self.pages_help_var.set(
                    "Ana galeri ve slayt web sayfaları güncel; bekleyen yayın yok."
                )
                self.pages_repair_button.configure(
                    state="disabled",
                    text="Bekleyen yayın yok",
                )

            usage = shutil.disk_usage(self.settings.root_path)
            drive = self.settings.root_path.drive or str(self.settings.root_path)
            self.disk_var.set(f"{drive} boş: {usage.free / 1024**3:.1f} GB")
            token = get_token(self.settings.github_username)
            self.connection_var.set(
                f"GitHub: {self.settings.github_username}" if token else "GitHub bağlı değil"
            )
            self._fill_tree()
            if not keep_safety:
                self._refresh_safety_state(rows)
        except Exception as exc:
            self.status_var.set(str(exc))

    def on_close(self) -> None:
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno(
                "İşlem sürüyor",
                "İşlem devam ediyor. Güvenli durmak için Hayır seçip "
                "'Mevcut Slaytı Bitir ve Dur' düğmesine basın. Şimdi zorla kapatırsanız "
                "yalnızca aktif slaytın yarım çıktısı silinir ve sonraki açılışta baştan işlenir. "
                "Yine de şimdi kapatılsın mı?",
            ):
                return
            self.stop_event.set()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
