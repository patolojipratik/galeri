@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Once KURULUM.bat calistirin.
  pause
  exit /b 1
)
if exist ".venv\Scripts\pythonw.exe" (
  start "" ".venv\Scripts\pythonw.exe" github_bagla_gui.py
) else (
  ".venv\Scripts\python.exe" github_bagla_gui.py
)
