from __future__ import annotations

import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"


def run(args: list[str]) -> None:
    print(">", " ".join(args))
    subprocess.check_call(args)


def main() -> None:
    if sys.version_info < (3, 10):
        raise SystemExit("Python 3.10 veya daha yeni bir surum gereklidir.")
    if not VENV.exists():
        print("Sanal Python ortami olusturuluyor...")
        venv.EnvBuilder(with_pip=True).create(VENV)
    python = VENV / "Scripts" / "python.exe"
    run([str(python), "-m", "pip", "install", "--upgrade", "pip"])
    run([str(python), "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")])
    print("\nKurulum tamamlandi.")
    print("Siradaki adim: GITHUB_BAGLA.bat")


if __name__ == "__main__":
    main()
