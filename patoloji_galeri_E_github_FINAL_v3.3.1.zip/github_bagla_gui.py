from __future__ import annotations

import re
import threading
import tkinter as tk
from tkinter import messagebox, ttk

from app.config import load_settings, save_settings
from app.github_api import GitHubAPI, GitHubError
from app.token_store import save_token


def normalize_token(value: str) -> str:
    """Kopyalama sırasında eklenen boşluk ve tırnakları temizler."""
    token = value.strip().strip('"').strip("'")
    token = re.sub(r"\s+", "", token)
    return token


def token_looks_valid(token: str) -> bool:
    return token.startswith(("github_pat_", "ghp_")) and len(token) >= 30


class GitHubConnectWindow:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.settings = load_settings()
        self.busy = False

        root.title("Patoloji Pratik - GitHub Bağlantısı")
        root.geometry("700x470")
        root.minsize(620, 420)

        self.token_var = tk.StringVar()
        self.show_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="Token bekleniyor")
        self.detail_var = tk.StringVar(value="")

        outer = ttk.Frame(root, padding=22)
        outer.pack(fill="both", expand=True)

        ttk.Label(
            outer,
            text="GitHub hesabını bağla",
            font=("Segoe UI", 18, "bold"),
        ).pack(anchor="w")

        ttk.Label(
            outer,
            text=f"Hedef hesap: {self.settings.github_username}",
            font=("Segoe UI", 10),
        ).pack(anchor="w", pady=(4, 16))

        info = (
            "GitHub'da token oluşturulduktan sonra yalnızca bir kez gösterilen "
            "github_pat_... değerinin tamamını kopyalayın. Aşağıdaki "
            "'Panodan yapıştır' düğmesine basın."
        )
        ttk.Label(
            outer,
            text=info,
            wraplength=640,
            justify="left",
        ).pack(anchor="w", pady=(0, 14))

        token_frame = ttk.LabelFrame(outer, text="Fine-grained GitHub tokeni", padding=14)
        token_frame.pack(fill="x")

        self.token_entry = ttk.Entry(
            token_frame,
            textvariable=self.token_var,
            show="•",
            font=("Consolas", 11),
        )
        self.token_entry.pack(fill="x", pady=(0, 10), ipady=5)
        self.token_entry.bind("<KeyRelease>", lambda _event: self.update_token_status())
        self.token_entry.bind("<<Paste>>", lambda _event: self.root.after(20, self.update_token_status))

        controls = ttk.Frame(token_frame)
        controls.pack(fill="x")

        self.paste_button = ttk.Button(
            controls,
            text="Panodan yapıştır",
            command=self.paste_from_clipboard,
        )
        self.paste_button.pack(side="left")

        ttk.Button(
            controls,
            text="Temizle",
            command=self.clear_token,
        ).pack(side="left", padx=(8, 0))

        ttk.Checkbutton(
            controls,
            text="Tokeni göster",
            variable=self.show_var,
            command=self.toggle_token_visibility,
        ).pack(side="right")

        status_row = ttk.Frame(outer)
        status_row.pack(fill="x", pady=(14, 0))
        ttk.Label(status_row, text="Durum:", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.status_label = ttk.Label(status_row, textvariable=self.status_var)
        self.status_label.pack(side="left", padx=(6, 0))

        ttk.Label(
            outer,
            textvariable=self.detail_var,
            wraplength=640,
            justify="left",
        ).pack(anchor="w", pady=(8, 0))

        permissions = (
            "Gerekli token ayarları: Resource owner = patolojipratik, "
            "Repository access = All repositories; Administration, Contents ve "
            "Pages = Read and write."
        )
        ttk.Label(
            outer,
            text=permissions,
            wraplength=640,
            justify="left",
            foreground="#555555",
        ).pack(anchor="w", pady=(18, 0))

        bottom = ttk.Frame(outer)
        bottom.pack(fill="x", side="bottom", pady=(22, 0))

        ttk.Button(bottom, text="İptal", command=root.destroy).pack(side="right")
        self.connect_button = ttk.Button(
            bottom,
            text="GitHub'a bağlan",
            command=self.start_connect,
            state="disabled",
        )
        self.connect_button.pack(side="right", padx=(0, 10))

        self.progress = ttk.Progressbar(outer, mode="indeterminate")
        self.progress.pack(fill="x", side="bottom", pady=(16, 0))

        self.root.after(150, self.offer_clipboard_paste)
        self.token_entry.focus_set()

    def offer_clipboard_paste(self) -> None:
        """Panoda token varsa kullanıcıyı uğraştırmadan alana yerleştirir."""
        try:
            text = self.root.clipboard_get()
        except tk.TclError:
            return
        token = normalize_token(text)
        if token_looks_valid(token):
            self.token_var.set(token)
            self.update_token_status()
            self.detail_var.set("Panodaki GitHub tokeni otomatik olarak alana yerleştirildi.")

    def paste_from_clipboard(self) -> None:
        try:
            text = self.root.clipboard_get()
        except tk.TclError:
            messagebox.showwarning(
                "Pano boş",
                "Panoda yapıştırılabilecek metin bulunamadı. GitHub'daki tokeni önce kopyalayın.",
                parent=self.root,
            )
            return
        token = normalize_token(text)
        self.token_var.set(token)
        self.token_entry.icursor("end")
        self.update_token_status()
        if not token_looks_valid(token):
            messagebox.showwarning(
                "Token biçimi uygun değil",
                "Panodaki metin github_pat_ veya ghp_ ile başlayan geçerli bir GitHub tokenine benzemiyor.\n\n"
                "GitHub token sayfasında Generate token sonrasında gösterilen uzun değerin tamamını kopyalayın.",
                parent=self.root,
            )

    def clear_token(self) -> None:
        self.token_var.set("")
        self.detail_var.set("")
        self.update_token_status()
        self.token_entry.focus_set()

    def toggle_token_visibility(self) -> None:
        self.token_entry.configure(show="" if self.show_var.get() else "•")

    def update_token_status(self) -> None:
        token = normalize_token(self.token_var.get())
        if token != self.token_var.get():
            self.token_var.set(token)
        if not token:
            self.status_var.set("Token bekleniyor")
            self.detail_var.set("")
            self.connect_button.configure(state="disabled")
            return
        if not token.startswith(("github_pat_", "ghp_")):
            self.status_var.set("Yanlış metin")
            self.detail_var.set(
                f"Girilen metin {len(token)} karakter. Token github_pat_ veya ghp_ ile başlamalıdır."
            )
            self.connect_button.configure(state="disabled")
            return
        if len(token) < 30:
            self.status_var.set("Token eksik görünüyor")
            self.detail_var.set(f"Yalnızca {len(token)} karakter alındı; tokenin tamamını kopyalayın.")
            self.connect_button.configure(state="disabled")
            return
        self.status_var.set("Biçim uygun")
        self.detail_var.set(
            f"Token {len(token)} karakter olarak alındı. Güvenlik nedeniyle tamamı gösterilmiyor."
        )
        self.connect_button.configure(state="normal" if not self.busy else "disabled")

    def set_busy(self, value: bool) -> None:
        self.busy = value
        self.paste_button.configure(state="disabled" if value else "normal")
        self.token_entry.configure(state="disabled" if value else "normal")
        self.connect_button.configure(state="disabled" if value else "normal")
        if value:
            self.progress.start(12)
        else:
            self.progress.stop()
            self.update_token_status()

    def start_connect(self) -> None:
        token = normalize_token(self.token_var.get())
        if not token_looks_valid(token):
            self.update_token_status()
            return
        self.set_busy(True)
        self.status_var.set("GitHub doğrulanıyor...")
        self.detail_var.set("Token GitHub API ile kontrol ediliyor.")
        thread = threading.Thread(target=self.connect_worker, args=(token,), daemon=True)
        thread.start()

    def connect_worker(self, token: str) -> None:
        try:
            api = GitHubAPI(token)
            profile = api.verify_user()
            self.root.after(0, lambda: self.finish_success(profile, token))
        except GitHubError as exc:
            self.root.after(0, lambda msg=str(exc): self.finish_error(msg))
        except Exception as exc:  # Beklenmeyen yerel sorunlar için kullanıcı dostu hata
            self.root.after(0, lambda msg=f"Beklenmeyen hata: {exc}": self.finish_error(msg))

    def finish_success(self, profile: dict, token: str) -> None:
        login = str(profile.get("login", ""))
        if not login:
            self.finish_error("GitHub kullanıcı adı alınamadı.")
            return

        if login.lower() != self.settings.github_username.lower():
            proceed = messagebox.askyesno(
                "Farklı hesap",
                f"Bu token {login} hesabına ait. Ayarlardaki hesabı {login} olarak değiştireyim mi?",
                parent=self.root,
            )
            if not proceed:
                self.set_busy(False)
                self.status_var.set("İşlem iptal edildi")
                self.detail_var.set("Başka hesaba ait token kaydedilmedi.")
                return

        self.settings.github_username = login
        self.settings.commit_email = f"{profile['id']}+{login}@users.noreply.github.com"
        save_settings(self.settings)
        save_token(login, token)

        self.set_busy(False)
        messagebox.showinfo(
            "Bağlantı başarılı",
            f"GitHub hesabı bağlandı: {login}\n\n"
            f"Yerel commit e-postası:\n{self.settings.commit_email}\n\n"
            "Token Windows Kimlik Bilgileri Yöneticisi'ne kaydedildi.",
            parent=self.root,
        )
        self.root.destroy()

    def finish_error(self, message: str) -> None:
        self.set_busy(False)
        if "401" in message or "Bad credentials" in message:
            title = "Token GitHub tarafından reddedildi"
            body = (
                "GitHub 401 - Bad credentials yanıtı verdi.\n\n"
                "Token biçimi doğru görünse de değerin tamamı kopyalanmamış, token iptal edilmiş "
                "veya süresi dolmuş olabilir. GitHub'da yeni token oluşturup 'Panodan yapıştır' "
                "düğmesini kullanın.\n\nTeknik ayrıntı:\n" + message
            )
        else:
            title = "GitHub bağlantısı kurulamadı"
            body = message
        self.status_var.set("Bağlantı başarısız")
        self.detail_var.set("Token kaydedilmedi. Hata penceresindeki açıklamayı kontrol edin.")
        messagebox.showerror(title, body, parent=self.root)


def main() -> None:
    root = tk.Tk()
    try:
        ttk.Style(root).theme_use("vista")
    except tk.TclError:
        pass
    GitHubConnectWindow(root)
    root.mainloop()


if __name__ == "__main__":
    main()
