# Sürüm Notları — v3.3 Final

## Hızlı ana galeri

- Ana sayfadaki kartlarda `gallery-XXX` ve kaynak biçimi (`KFB`, `SVS` vb.) rozetleri kaldırıldı.
- Her slayt için ana galeri reposunda yaklaşık 360×240 piksellik, düşük boyutlu bir küçük ön izleme üretilir.
- Ana sayfa artık büyük `thumbnail.jpg` dosyalarını başlangıçta indirmez.
- Küçük ön izlemeye tıklayınca sanal mikroskop açılmaya devam eder.
- Ayrı bir **Sanal mikroskop** bağlantısı eklendi.
- **Detay ve büyük ön izleme** düğmesi kartı aşağı doğru genişletir.
- Başlık, açıklama ve etiketler ayrıntı bölümünde gösterilir.
- Büyük ön izleme yalnızca ayrıntı açıldığında internetten yüklenir.
- Büyük ön izlemede uzaklaştırma, %100 ve yakınlaştırma kontrolleri bulunur.
- Ayrıntı bölümü kapatılabilir; görüntü öğesi kapatıldığında sayfadan çıkarılır.

İlk ana galeri yayını sırasında mevcut yayınların küçük ön izlemeleri bir kez hazırlanır. Yerel slayt repo klasörü yoksa mevcut `thumbnail.jpg` GitHub Pages üzerinden indirilip küçültülür. Sonraki yayınlarda hazır küçük dosyalar yeniden kullanılır.

## Slayt bilgi editörü

- **Kaydet ve Öncekine Geç** düğmesi eklendi.
- **Kaydet ve Sonrakine Geç** düğmesi eklendi.
- Arama filtresi açıksa önceki/sonraki geçiş görünür filtrelenmiş slaytlar içinde yapılır.
- `Ctrl+Page Up` ve `Ctrl+Page Down` kısayolları aynı işlevleri çalıştırır.
- Düğmeler daha rahat sığması için iki satırlı bir düzene alındı.

## Korunan özellikler

- GitHub bağlantı hatalarında otomatik yeniden deneme
- güvenli yerel metadata ve tarih damgalı yedekler
- KFB ve SVS/OpenSlide desteği
- 512 px DZI karo ve 2048 px süper karo okuma
- paralel JPEG yazma ve Git fast-import
- yayın sonrası yerel temizlik
- elektrik kesintisi kurtarma
- sesli hata uyarısı
- **Mevcut Slaytı Bitir ve Dur**
