# Patoloji Pratik Slayt Yayıncısı — v3.3.1 Final

Bu uygulama `E:\Pratik_slaytları` içindeki sanal slaytları sırayla işler, DZI/OpenSeadragon biçimine dönüştürür, `gallery-001`, `gallery-002` biçiminde GitHub repolarına yükler, GitHub Pages yayınını açar ve ana galeriyi günceller.

Ana galeri:

`https://patolojipratik.github.io/galeri/`

## v3.3.1 neden güvenli ve hızlı sürüm?

- Slayt adı, organ, tanı, açıklama ve etiketler artık Python arayüzünden düzenlenir.
- CSV içine elle virgül veya tırnak işareti yazma zorunluluğu yoktur.
- Yerel bilgiler ana kaynaktır; otomatik GitHub → yerel metadata eşitlemesi varsayılan olarak kapalıdır.
- Eski veya boş çevrimiçi CSV, yerel tanıları silemez.
- Her kullanıcı düzenlemesinden önce tarih damgalı yedek oluşturulur.
- İleri kullanıcı uzaktan eşitlemeyi açarsa üç yönlü karşılaştırma yapılır; çakışmada yerel değer korunur.
- KFB ve SVS yanında OpenSlide'ın açabildiği ek formatlar taranabilir.
- Ana galeri küçük ön izlemelerle hızlı açılır; büyük ön izlemeler yalnızca istendiğinde yüklenir.
- Metadata editöründe kaydedip önceki veya sonraki slayta tek tıkla geçilebilir.

## Mevcut v2.x veya v3.x kurulumunun üzerine kurma

1. Programda **GÜVENLE KAPATABİLİRSİNİZ** yazısını bekleyin.
2. Programı kapatın.
3. Ek güvenlik için `E:\github\data\slides.csv` dosyasını başka bir klasöre bir kez kopyalayabilirsiniz.
4. Tam paket ZIP içeriğini doğrudan `E:\github` üzerine çıkartın.
5. Sorulduğunda dosyaları değiştirin; `E:\github` klasörünü önceden silmeyin.
6. Bir kez `GUNCELLE_VE_BASLAT.bat` çalıştırın. Bu dosya açılış öncesinde `slides.csv` ve varsa `slides.pending.csv` için ayrıca otomatik kurulum yedeği oluşturur.

Korunan veriler:

- `data\slides.csv`
- `data\slides.pending.csv`
- `data\yedek\`
- `data\yedek_kurulum\`
- `config\settings.json`
- `logs\`
- `repos\galeri`
- GitHub tokeni
- yayımlanmış slayt kayıtları

`GUNCELLE_VE_BASLAT.bat` mevcut çalışan paketleri gereksiz yere yükseltmez; yalnızca `requirements.txt` içindeki eksik bağımlılıkları kurar.

## Slayt bilgilerini düzenleme

Ana pencerede bir slayt seçin ve **Bilgileri Düzenle** düğmesine basın.

Düzenlenebilir alanlar:

- Başlık
- Organ / sistem
- Tanı
- Açıklama
- Etiketler

Etiketleri virgülle ayırabilirsiniz:

`mide, adenokarsinom, H&E, eğitim`

Tırnak işareti veya CSV kaçış karakteri yazmanız gerekmez. Uygulama bunları güvenli şekilde kaydeder.

### Kaydet

Bilgileri yerel envantere kaydeder. Önceki sürüm otomatik olarak şu klasöre yedeklenir:

`E:\github\data\yedek\`

### Kaydet ve Öncekine / Sonrakine Geç

Geçerli slayttaki bilgileri kaydeder ve soldaki görünür listede önceki veya sonraki slayta geçer. Arama filtresi açıksa geçiş filtrelenmiş sonuçlar içinde yapılır.

Klavye kısayolları:

- `Ctrl+Page Up`: kaydet ve öncekine geç
- `Ctrl+Page Down`: kaydet ve sonrakine geç

### Kaydet ve İnternette Yayınla

Bilgileri kaydeder, ana galeri reposunu yeniden oluşturur ve GitHub Pages'a gönderir. Slaytın büyük DZI dosyaları yeniden üretilmez; yalnızca küçük ana galeri dosyaları güncellenir.

## Ana galeri çalışma biçimi

Ana sayfa hızlı açılacak şekilde iki ayrı ön izleme kullanır:

- **Küçük ön izleme:** yaklaşık 360×240 piksel; ana sayfada yüklenir.
- **Büyük ön izleme:** slayt reposundaki `thumbnail.jpg`; yalnızca **Detay ve büyük ön izleme** açıldığında indirilir.

Kart üzerinde yalnızca tanı ve organ doğrudan gösterilir. Teknik `gallery-XXX` adı ve kaynak biçimi (`KFB`, `SVS` vb.) ana sayfada gösterilmez.

Kullanım:

1. Küçük ön izlemeye veya **Sanal mikroskop** düğmesine basarak sanal mikroskobu açın.
2. **Detay ve büyük ön izleme** ile kartı aşağı genişletin.
3. Başlık, açıklama ve etiketleri görün.
4. Büyük ön izlemede `−`, `100%` ve `+` kontrollerini kullanın.
5. **Detayları kapat** ile bölümü kapatın.

Güncellemeden sonraki ilk **Ana Galeriyi Yayınla** işleminde mevcut slaytların küçük ön izlemeleri bir kez hazırlanır. Yerel slayt klasörü daha önce temizlendiyse program mevcut büyük ön izlemeyi GitHub Pages'tan indirip küçültür. Bu ilk işlem birkaç dakika sürebilir; sonraki yayınlarda küçük dosyalar yeniden kullanılır.

## Çevrimiçi metadata eşitlemesi

v3.3'te varsayılan ayar:

```json
"sync_remote_metadata_on_start": false
```

Bu bilinçli bir güvenlik tercihidir. GitHub'daki `slayt_bilgileri.csv` artık uygulamanın ürettiği yayın çıktısıdır. Normal kullanımda GitHub web editöründen değiştirmeyin.

İleri kullanıcı bu ayarı `true` yaparsa sistem üç yönlü karşılaştırma uygular:

- yalnızca çevrimiçi taraf değişmişse çevrimiçi değer alınır,
- yalnızca yerel taraf değişmişse yerel değer korunur,
- iki taraf da değişmişse yerel değer korunur ve `data\remote_metadata_conflicts.txt` oluşturulur.

## Yeni slayt ekleme

Yeni slaytları yalnızca kaynak klasöre kopyalayın:

`E:\Pratik_slaytları`

Program sonraki açılışta yeni dosyaları otomatik bulur ve mevcut galeri numaralarını değiştirmeden kuyruğun sonuna ekler.

Varsayılan uzantılar:

- `.kfb`
- `.svs`
- `.tif`, `.tiff`
- `.ndpi`
- `.mrxs`
- `.scn`
- `.bif`
- `.svslide`
- `.vms`, `.vmu`
- `.dcm`
- `.czi`
- `.avs`

Bir uzantının listede bulunması, ilgili dosyanın OpenSlide tarafından kesin açılacağı anlamına gelmez. Desteklenmeyen dosya hata kaydına alınır; diğer yayımlanmış slaytlar korunur.

## Çalışma düğmeleri

### Sıradaki 1 Slaytı İşle

Kuyruktaki yalnızca bir slaydı tamamlar ve durur.

### Tümünü İşle

Yayımlanmış slaytları atlar ve kalanların tamamını sırayla işler.

### Mevcut Slaytı Bitir ve Dur

Aktif slaydı yarıda kesmez. Dönüşüm, GitHub yüklemesi, commit doğrulaması, Pages kontrolü, ana galeri güncellemesi ve yerel temizlik tamamlandıktan sonra yeni slayta geçmeden durur.

Üst bölüm yeniden **GÜVENLE KAPATABİLİRSİNİZ** olduğunda bilgisayar kapatılabilir.

## Elektrik kesintisi

Tamamlanmış yayınlar tekrar işlenmez. Kesinti sırasında aktif olan yarım yerel çıktı sonraki açılışta temizlenir ve yalnızca o slayt baştan hazırlanır. Bu, farklı karo veya kalite ayarlarına ait parçaların karışmasını önleyen güvenli yaklaşımdır.

## Disk kullanımı

Bir slayt başarıyla GitHub'a yüklenip commit ve Pages doğrulaması tamamlandıktan sonra yerel `repos\gallery-XXX` klasörü silinir. Kaynak KFB/SVS dosyası silinmez.

## Dönüşüm ayarları

Varsayılanlar:

- DZI karo: 512 px
- süper karo okuma: 2048 px
- paralel JPEG yazıcı: 4
- JPEG kalite: 72
- JPEG alt örnekleme: 4:2:0
- hedef repo üst sınırı: 800 MB
- Git fast-import: açık
- JPEG delta araması: kapalı

Ayarlar:

`E:\github\config\settings.json`

## Dosya yapısı

```text
E:\github
├─ app\                    program modülleri
├─ config\settings.json    ayarlar
├─ data\slides.csv         temel envanter
├─ data\yedek\             metadata yedekleri
├─ logs\                   işlem günlükleri
├─ repos\galeri            ana galeri çalışma kopyası
└─ work\                   geçici çalışma alanı
```

Kaynak slaytlar ayrı kalır:

`E:\Pratik_slaytları`


## v3.3.1 galeri görünümü

- Kartlardaki uzun “Detay ve büyük ön izleme” metni kaldırıldı; yerine erişilebilir büyüteç simgesi eklendi.
- Simgeye basıldığında büyük ön izleme ekranın tamamını kaplayan bir pencerede açılır.
- Büyük görüntü yalnızca bu pencere açılınca indirilir; kapatılınca sayfa normal görünüme döner.
- Açıklama, başlık ve etiketler tam ekran pencerenin bilgi bölümünde gösterilir.
- Yakınlaştırma, uzaklaştırma, yüzde yüz ve kapatma kontrolleri bulunur. Escape tuşu da pencereyi kapatır.
