@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Once KURULUM.bat calistirin.
  pause
  exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" baslat.py
