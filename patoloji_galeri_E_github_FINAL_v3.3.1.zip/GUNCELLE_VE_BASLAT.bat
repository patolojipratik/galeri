@echo off
cd /d "%~dp0"
echo Patoloji Pratik v3.3.1 Final veri yedegi kontrol ediliyor...
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" guncelle_oncesi_yedek.py
) else (
  py -3 guncelle_oncesi_yedek.py
)
if errorlevel 1 (
  echo.
  echo Veri yedegi olusturulamadi. Program baslatilmadi.
  pause
  exit /b 1
)
echo.
echo Bagimliliklar kontrol ediliyor...
if not exist ".venv\Scripts\python.exe" (
  py -3 kurulum.py
) else (
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
)
if errorlevel 1 (
  echo.
  echo Guncelleme basarisiz. Internet baglantisini ve Python kurulumunu kontrol edin.
  pause
  exit /b 1
)
echo.
echo Guncelleme tamamlandi. Program aciliyor...
start "" ".venv\Scripts\pythonw.exe" baslat.py
