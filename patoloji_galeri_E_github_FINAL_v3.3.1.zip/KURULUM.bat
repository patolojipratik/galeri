@echo off
cd /d "%~dp0"
py -3 kurulum.py
if errorlevel 1 (
  echo.
  echo Kurulum basarisiz. Python 3.10 veya daha yenisini kontrol edin.
)
pause
