from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import Settings
from .utils import atomic_write_json, now_iso


def receipts_dir(settings: Settings) -> Path:
    path = settings.data_dir / "receipts"
    path.mkdir(parents=True, exist_ok=True)
    return path


def receipt_path(settings: Settings, gallery_id: str) -> Path:
    return receipts_dir(settings) / f"{gallery_id}.json"


def load_receipt(settings: Settings, gallery_id: str) -> dict[str, Any]:
    path = receipt_path(settings, gallery_id)
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def write_receipt(settings: Settings, gallery_id: str, **values: Any) -> dict[str, Any]:
    current = load_receipt(settings, gallery_id)
    current.update(values)
    current["gallery_id"] = gallery_id
    current["updated_at"] = now_iso()
    atomic_write_json(receipt_path(settings, gallery_id), current)
    return current
