from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

Progress = Callable[[str, float | None], None]


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip())
    return value.strip("-._") or "image"


def sha256_file(path: Path, progress: Progress | None = None) -> str:
    total = max(path.stat().st_size, 1)
    done = 0
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(8 * 1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
            done += len(chunk)
            if progress:
                progress("Kaynak dosya denetleniyor", done / total * 100)
    return digest.hexdigest()


def directory_size(path: Path) -> int:
    size = 0
    for root, _, files in os.walk(path):
        if Path(root).name == ".git":
            continue
        for filename in files:
            file_path = Path(root) / filename
            try:
                size += file_path.stat().st_size
            except OSError:
                pass
    return size


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name, dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
