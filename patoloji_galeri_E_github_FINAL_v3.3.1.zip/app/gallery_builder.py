from __future__ import annotations

import io
import json
from pathlib import Path

import requests
from PIL import Image

from .config import Settings
from .github_api import GitHubAPI
from .git_ops import prepare_and_push, run_git
from .inventory import load_rows
from .metadata_sync import refresh_remote_sha, sync_remote_metadata, write_editable_csv
from .templates import main_gallery_html


SMALL_THUMB_DIR = "thumbs"
SMALL_THUMB_SIZE = (360, 240)


def _ensure_small_thumbnail(
    settings: Settings,
    gallery_repo_dir: Path,
    row: dict[str, str],
    progress=None,
) -> str:
    gallery_id = row.get("gallery_id", "").strip()
    if not gallery_id:
        return row.get("thumbnail_url", "")

    relative = f"{SMALL_THUMB_DIR}/{gallery_id}.jpg"
    target = gallery_repo_dir / relative
    if target.exists() and target.stat().st_size > 0:
        return relative

    target.parent.mkdir(parents=True, exist_ok=True)
    if progress:
        progress(f"{gallery_id}: ana galeri icin kucuk on izleme hazirlaniyor", None)
    local_source = settings.repos_dir / gallery_id / "thumbnail.jpg"
    image: Image.Image | None = None
    try:
        if local_source.exists():
            with Image.open(local_source) as opened:
                image = opened.convert("RGB")
        else:
            url = row.get("thumbnail_url", "").strip()
            if not url:
                return ""
            response = requests.get(
                url,
                timeout=(8, 20),
                headers={"User-Agent": "PatolojiPratik-Gallery/3.3.1"},
            )
            response.raise_for_status()
            with Image.open(io.BytesIO(response.content)) as opened:
                image = opened.convert("RGB")

        image.thumbnail(SMALL_THUMB_SIZE, Image.Resampling.LANCZOS)
        temp = target.with_suffix(".tmp.jpg")
        image.save(temp, format="JPEG", quality=68, optimize=True, progressive=True)
        temp.replace(target)
        return relative
    except Exception as exc:
        if progress:
            progress(f"{gallery_id}: kucuk on izleme hazirlanamadi; mevcut resim kullanilacak ({exc})", None)
        return row.get("thumbnail_url", "")
    finally:
        if image is not None:
            image.close()



def _align_local_gallery_repo(settings: Settings, api: GitHubAPI, progress=None) -> None:
    """Fast-forward the generated gallery worktree before applying web edits.

    GitHub's web editor creates a normal remote commit. Resetting the generated
    local gallery to remote main prevents a non-fast-forward push. Slide source
    state lives in data/slides.csv, so the gallery worktree is safe to regenerate.
    """
    if not api.repo_exists(settings.gallery_repo):
        return
    repo_dir = settings.repos_dir / settings.gallery_repo
    repo_dir.mkdir(parents=True, exist_ok=True)
    if not (repo_dir / ".git").exists():
        run_git(["init", "-b", "main"], repo_dir)
    remote = f"https://github.com/{settings.github_username}/{settings.gallery_repo}.git"
    current = run_git(["remote", "get-url", "origin"], repo_dir, check=False)
    if current.returncode == 0:
        run_git(["remote", "set-url", "origin", remote], repo_dir)
    else:
        run_git(["remote", "add", "origin", remote], repo_dir)
    fetched = run_git(["fetch", "--depth=1", "origin", "main"], repo_dir, check=False)
    if fetched.returncode == 0:
        run_git(["reset", "--hard", "FETCH_HEAD"], repo_dir)
        run_git(["clean", "-fd"], repo_dir, check=False)
        if progress:
            progress("Ana galeri GitHub'daki son duzenlemelerle esitlendi", 100)


def build_gallery(settings: Settings, progress=None) -> Path:
    repo_dir = settings.repos_dir / settings.gallery_repo
    repo_dir.mkdir(parents=True, exist_ok=True)
    rows = load_rows(settings)
    public_rows = []
    for row in rows:
        if row.get("status") != "published":
            continue
        public_item = {
            "gallery_id": row.get("gallery_id", ""),
            "number": int(row.get("number") or 0),
            "title": row.get("title", ""),
            "organ": row.get("organ", ""),
            "diagnosis": row.get("diagnosis", ""),
            "description": row.get("description", ""),
            "tags": row.get("tags", ""),
            "source_format": row.get("source_format", ""),
            "page_url": row.get("page_url", ""),
            "thumbnail_url": row.get("thumbnail_url", ""),
            "label_url": row.get("label_url", ""),
        }
        public_item["small_thumbnail_url"] = _ensure_small_thumbnail(
            settings, repo_dir, public_item, progress
        )
        public_rows.append(public_item)
    public_rows.sort(key=lambda x: x["number"])

    (repo_dir / "index.html").write_text(
        main_gallery_html(
            settings.github_username,
            settings.gallery_repo,
            settings.remote_metadata_filename,
        ),
        encoding="utf-8",
    )
    (repo_dir / "slides.json").write_text(
        json.dumps(public_rows, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    # Yalnizca kullanicinin duzenledigi alanlari iceren sade CSV. GitHub'in web
    # editorunde degistirildiginde galeri sayfasi bu dosyayi dogrudan okuyarak
    # ad ve aciklamalari uygulama acilmadan da gosterir.
    write_editable_csv(repo_dir / settings.remote_metadata_filename, public_rows)

    (repo_dir / ".nojekyll").write_text("", encoding="utf-8")
    (repo_dir / "README.md").write_text(
        "# Patoloji Pratik Slaytlari\n\n"
        "Sanal mikroskop ana galerisi.\n\n"
        "## Slayt adlarini ve aciklamalarini duzenleme\n\n"
        "Bilgiler Patoloji Pratik masaustu uygulamasindaki `Bilgileri Duzenle` "
        "penceresinden yonetilir. Baslik, organ, tani, aciklama ve etiketler "
        "uygulama tarafindan guvenli CSV biciminde yayinlanir.\n\n"
        "Ana sayfa kucuk on izlemeleri kullanir; buyuk on izlemeler yalnizca "
        "kullanici detay bolumunu actiginda yuklenir.\n",
        encoding="utf-8",
    )
    return repo_dir


def publish_gallery(
    settings: Settings,
    token: str,
    api: GitHubAPI,
    progress=None,
) -> str:
    # GitHub web editoru uzakta bir commit olusturur. Once uretilen ana galeri
    # calisma kopyasi bu commit'e hizalanir, sonra ad/aciklama verileri alinir.
    try:
        _align_local_gallery_repo(settings, api, progress)
    except Exception as exc:
        if progress:
            progress(f"Ana galeri uzaktaki commit ile hizalanamadi: {exc}", None)

    # Otomatik uzak esitleme v3.2 ve sonrasinda varsayilan olarak kapalidir. Ileri kullanici
    # ayarlardan acarsa uc yonlu karsilastirma yerel tanilari koruyarak uygulanir.
    try:
        sync_remote_metadata(settings, api, progress)
    except Exception as exc:
        if progress:
            progress(f"Cevrimici slayt bilgileri alinamadi; yerel bilgiler kullaniliyor: {exc}", None)

    repo_dir = build_gallery(settings, progress)
    api.create_public_repo(settings.gallery_repo, "Patoloji pratik sanal mikroskop galerisi")
    prepare_and_push(
        repo_dir,
        settings.gallery_repo,
        settings,
        token,
        "Ana galeri guncellendi",
        progress,
    )
    url = api.enable_pages(settings.gallery_repo)
    api.set_repo_homepage(settings.gallery_repo, url)
    try:
        refresh_remote_sha(settings, api)
    except Exception:
        pass
    return url
