from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


APP_ROOT = Path(__file__).resolve().parents[1]
SETTINGS_FILE = APP_ROOT / "config" / "settings.json"
APP_VERSION = "3.3.1 Final"
CURRENT_SETTINGS_SCHEMA = 6


@dataclass
class Settings:
    source_dir: str = r"E:\Pratik_slaytları"
    work_root: str = r"E:\github"
    github_username: str = "patolojipratik"
    commit_name: str = "Patoloji Pratik"
    commit_email: str = ""
    gallery_repo: str = "galeri"
    repo_prefix: str = "gallery-"
    repo_digits: int = 3

    # Kaynak klasorde aranacak uzantilar. KFB, kfbslide ile; digerleri
    # OpenSlide ile acilir. Virgulle ayrilarak yeni uzanti eklenebilir.
    source_extensions: str = (
        ".kfb,.svs,.tif,.tiff,.ndpi,.mrxs,.scn,.bif,.svslide,"
        ".vms,.vmu,.dcm,.czi,.avs"
    )

    tile_size: int = 512
    overlap: int = 1
    # KFB/OpenSlide'dan daha buyuk bir blok tek seferde okunur ve RAM'de
    # karolara ayrilir. Bu, read_region cagrilarini belirgin azaltir.
    super_tile_size: int = 2048
    encode_workers: int = 4
    # Pillow JPEG subsampling: 0=4:4:4, 1=4:2:2, 2=4:2:0.
    jpeg_subsampling: int = 2
    jpeg_quality: int = 72
    min_jpeg_quality: int = 52
    jpeg_quality_step: int = 10
    auto_reduce_jpeg_quality: bool = True

    thumbnail_width: int = 1400
    thumbnail_height: int = 900
    max_repo_size_mb: int = 800
    verify_pages_seconds: int = 180
    compute_sha256: bool = False
    cleanup_published_repos: bool = True
    auto_recover_on_start: bool = True
    prevent_sleep_during_work: bool = True
    fast_initial_import: bool = True

    # Ana galeri reposunda yalnizca isimlendirme alanlarini tasiyan, GitHub web
    # editorunde kolayca duzenlenebilen dosya.
    remote_metadata_filename: str = "slayt_bilgileri.csv"
    sync_remote_metadata_on_start: bool = False

    settings_schema: int = CURRENT_SETTINGS_SCHEMA

    @property
    def source_path(self) -> Path:
        return Path(self.source_dir)

    @property
    def root_path(self) -> Path:
        return Path(self.work_root)

    @property
    def repos_dir(self) -> Path:
        return self.root_path / "repos"

    @property
    def data_dir(self) -> Path:
        return self.root_path / "data"

    @property
    def logs_dir(self) -> Path:
        return self.root_path / "logs"

    @property
    def work_dir(self) -> Path:
        return self.root_path / "work"

    @property
    def slides_csv(self) -> Path:
        return self.data_dir / "slides.csv"

    @property
    def supported_extensions(self) -> tuple[str, ...]:
        values: list[str] = []
        for item in str(self.source_extensions).split(","):
            suffix = item.strip().lower()
            if not suffix:
                continue
            if not suffix.startswith("."):
                suffix = "." + suffix
            if suffix not in values:
                values.append(suffix)
        return tuple(values)

    def repo_name(self, number: int) -> str:
        return f"{self.repo_prefix}{number:0{self.repo_digits}d}"

    def page_url(self, repo_name: str) -> str:
        return f"https://{self.github_username}.github.io/{repo_name}/"

    def metadata_edit_url(self) -> str:
        return (
            f"https://github.com/{self.github_username}/{self.gallery_repo}/edit/"
            f"main/{self.remote_metadata_filename}"
        )


def ensure_layout(settings: Settings) -> None:
    for directory in (
        settings.root_path,
        settings.repos_dir,
        settings.data_dir,
        settings.logs_dir,
        settings.work_dir,
        APP_ROOT / "config",
    ):
        directory.mkdir(parents=True, exist_ok=True)


def _write_settings(settings: Settings) -> None:
    ensure_layout(settings)
    SETTINGS_FILE.write_text(
        json.dumps(asdict(settings), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_settings() -> Settings:
    settings = Settings()
    raw: dict[str, Any] = {}
    if SETTINGS_FILE.exists():
        raw = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        allowed = set(asdict(settings))
        settings = Settings(**{k: v for k, v in raw.items() if k in allowed})

    old_schema = int(raw.get("settings_schema") or 0) if raw else CURRENT_SETTINGS_SCHEMA
    migrated = old_schema < CURRENT_SETTINGS_SCHEMA
    if migrated:
        # v2.1 ve onceki kurulumlar icin tek seferlik varsayilanlar. Bu bloktan
        # sonra settings.json'da bilincli yazilan 256/1024 gibi tile degerleri
        # sessizce degistirilmez.
        if int(settings.tile_size) <= 256:
            settings.tile_size = 512
        settings.super_tile_size = max(2048, int(settings.super_tile_size))
        settings.encode_workers = max(2, int(settings.encode_workers))
        settings.jpeg_subsampling = max(0, min(2, int(settings.jpeg_subsampling)))
        settings.jpeg_quality = min(int(settings.jpeg_quality), 72)
        settings.max_repo_size_mb = min(int(settings.max_repo_size_mb), 800)
        settings.min_jpeg_quality = min(int(settings.min_jpeg_quality), 52)
        settings.jpeg_quality_step = max(5, int(settings.jpeg_quality_step))
        settings.auto_reduce_jpeg_quality = True
        # v3.2 ile Python arayuzu yerel ana kaynak oldu. Eski, bos veya gecikmis
        # GitHub CSV dosyalarinin tanilari silmemesi icin otomatik uzak esitleme
        # migration sirasinda kapatilir. Ileri kullanici isterse elle acabilir.
        settings.sync_remote_metadata_on_start = False
        # Yeni formatlar mevcut KFB ayarinin yanina eklenir.
        existing = {x.strip().lower() for x in str(settings.source_extensions).split(",") if x.strip()}
        existing.update({".kfb", ".svs"})
        settings.source_extensions = ",".join(sorted(existing))
        settings.settings_schema = CURRENT_SETTINGS_SCHEMA

    # Elle duzenlenen settings.json icin savunmaci, fakat kullanici tercihini
    # koruyan sinirlamalar.
    settings.jpeg_quality = max(35, min(92, int(settings.jpeg_quality)))
    settings.min_jpeg_quality = max(35, min(settings.jpeg_quality, int(settings.min_jpeg_quality)))
    settings.jpeg_quality_step = max(5, min(20, int(settings.jpeg_quality_step)))
    settings.max_repo_size_mb = max(250, min(900, int(settings.max_repo_size_mb)))
    settings.tile_size = max(256, min(1024, int(settings.tile_size)))
    settings.super_tile_size = max(settings.tile_size, min(4096, int(settings.super_tile_size)))
    settings.super_tile_size = (settings.super_tile_size // settings.tile_size) * settings.tile_size
    settings.super_tile_size = max(settings.tile_size, settings.super_tile_size)
    settings.encode_workers = max(1, min(8, int(settings.encode_workers)))
    settings.jpeg_subsampling = max(0, min(2, int(settings.jpeg_subsampling)))
    settings.source_extensions = ",".join(settings.supported_extensions)
    settings.remote_metadata_filename = Path(settings.remote_metadata_filename).name or "slayt_bilgileri.csv"

    ensure_layout(settings)
    if migrated:
        _write_settings(settings)
    return settings


def save_settings(settings: Settings) -> None:
    settings.settings_schema = CURRENT_SETTINGS_SCHEMA
    _write_settings(settings)
