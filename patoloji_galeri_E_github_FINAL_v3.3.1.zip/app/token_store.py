from __future__ import annotations

import keyring

SERVICE_NAME = "patoloji-pratik-github-yayinlama"


def save_token(username: str, token: str) -> None:
    keyring.set_password(SERVICE_NAME, username, token.strip())


def get_token(username: str) -> str | None:
    return keyring.get_password(SERVICE_NAME, username)


def delete_token(username: str) -> None:
    try:
        keyring.delete_password(SERVICE_NAME, username)
    except keyring.errors.PasswordDeleteError:
        pass
