from __future__ import annotations

import csv
import io
import json
import os
import uuid
from pathlib import Path

from .config import Settings
from .inventory import (
    EDITABLE_FIELDS,
    backup_inventory,
    load_rows,
    save_rows,
)


REMOTE_FIELDS = ("gallery_id",) + EDITABLE_FIELDS


def _cache_path(settings: Settings) -> Path:
    return settings.data_dir / "remote_metadata.sha"


def _base_path(settings: Settings) -> Path:
    return settings.data_dir / "remote_metadata_base.json"


def _conflict_path(settings: Settings) -> Path:
    return settings.data_dir / "remote_metadata_conflicts.txt"


def editable_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for row in sorted(rows, key=lambda r: int(r.get("number") or 0)):
        result.append({field: row.get(field, "") for field in REMOTE_FIELDS})
    return result


def write_editable_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=REMOTE_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(editable_rows(rows))


def _read_remote_csv(raw: bytes) -> list[dict[str, str]]:
    text = raw.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames or "gallery_id" not in reader.fieldnames:
        raise RuntimeError("Cevrimici bilgi CSV dosyasinda gallery_id sutunu bulunamadi.")
    rows: list[dict[str, str]] = []
    for source in reader:
        row = {field: str(source.get(field, "") or "") for field in REMOTE_FIELDS}
        if row["gallery_id"].strip():
            rows.append(row)
    return rows


def _snapshot(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {
        row.get("gallery_id", "").strip(): {
            field: str(row.get(field, "") or "") for field in EDITABLE_FIELDS
        }
        for row in rows
        if row.get("gallery_id", "").strip()
    }


def _read_base(settings: Settings) -> dict[str, dict[str, str]]:
    try:
        raw = json.loads(_base_path(settings).read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return {}
        result: dict[str, dict[str, str]] = {}
        for gallery_id, values in raw.items():
            if not isinstance(values, dict):
                continue
            result[str(gallery_id)] = {
                field: str(values.get(field, "") or "") for field in EDITABLE_FIELDS
            }
        return result
    except (OSError, ValueError, TypeError):
        return {}


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        temp.write_text(text, encoding="utf-8")
        os.replace(temp, path)
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass


def cached_remote_sha(settings: Settings) -> str:
    try:
        return _cache_path(settings).read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def remember_remote_state(
    settings: Settings,
    sha: str,
    rows: list[dict[str, str]],
) -> None:
    if sha:
        _atomic_write_text(_cache_path(settings), sha.strip())
    _atomic_write_text(
        _base_path(settings),
        json.dumps(_snapshot(rows), ensure_ascii=False, indent=2),
    )


def remember_remote_sha(settings: Settings, sha: str) -> None:
    """Backward-compatible SHA helper; the base snapshot is left unchanged."""
    if sha:
        _atomic_write_text(_cache_path(settings), sha.strip())


def sync_remote_metadata(settings: Settings, api, progress=None, *, force: bool = False) -> int:
    """Safely merge optional GitHub web edits with a three-way comparison.

    Local Python-editor data is the default source of truth. Remote synchronization
    is disabled by default. When explicitly enabled, a field is imported only if
    the remote side changed since the last known common version and the local side
    did not independently change. Conflicts preserve the local value.
    """
    if not settings.sync_remote_metadata_on_start:
        return 0
    if not api.repo_exists(settings.gallery_repo):
        return 0

    file_result = api.get_repo_file(
        settings.gallery_repo,
        settings.remote_metadata_filename,
    )
    if file_result is None:
        return 0
    raw, remote_sha = file_result
    if not force and remote_sha and remote_sha == cached_remote_sha(settings):
        return 0

    remote_rows = _read_remote_csv(raw)
    remote_by_id = {row["gallery_id"].strip(): row for row in remote_rows}
    base = _read_base(settings)

    # On first encounter, record the remote file as the common ancestor without
    # changing local diagnoses. This prevents an old/mostly empty public CSV from
    # erasing user-authored metadata during migration from v3.1.
    if not base:
        remember_remote_state(settings, remote_sha, remote_rows)
        if progress:
            progress(
                "Cevrimici bilgi dosyasi guvenli referans olarak kaydedildi; "
                "yerel tanilar degistirilmedi",
                100,
            )
        return 0

    rows = load_rows(settings)
    original_rows = [dict(row) for row in rows]
    changed_rows = 0
    conflicts: list[str] = []

    for row in rows:
        gallery_id = row.get("gallery_id", "").strip()
        remote = remote_by_id.get(gallery_id)
        if remote is None:
            continue
        previous = base.get(gallery_id, {field: "" for field in EDITABLE_FIELDS})
        row_changed = False
        for field in EDITABLE_FIELDS:
            base_value = str(previous.get(field, "") or "")
            local_value = str(row.get(field, "") or "")
            remote_value = str(remote.get(field, "") or "")

            remote_changed = remote_value != base_value
            local_changed = local_value != base_value
            if not remote_changed:
                continue
            if not local_changed or local_value == remote_value:
                if local_value != remote_value:
                    row[field] = remote_value
                    row_changed = True
            else:
                conflicts.append(
                    f"{gallery_id} | {field} | yerel korundu: {local_value!r} | "
                    f"cevrimici: {remote_value!r}"
                )
        if row_changed:
            changed_rows += 1

    if changed_rows:
        backup_inventory(settings, original_rows, reason="remote_sync_before")
        save_rows(settings, rows)

    if conflicts:
        _atomic_write_text(
            _conflict_path(settings),
            "Yerel ve cevrimici alan ayni anda degistigi icin yerel deger korundu.\n\n"
            + "\n".join(conflicts)
            + "\n",
        )
    else:
        try:
            _conflict_path(settings).unlink(missing_ok=True)
        except OSError:
            pass

    remember_remote_state(settings, remote_sha, remote_rows)
    if progress:
        if changed_rows:
            progress(f"Cevrimici duzenlemeler guvenle alindi: {changed_rows} slayt", 100)
        elif conflicts:
            progress(
                f"Cevrimici esitlemede {len(conflicts)} cakisma bulundu; yerel bilgiler korundu",
                100,
            )
        else:
            progress("Cevrimici slayt bilgileri kontrol edildi", 100)
    return changed_rows


def refresh_remote_sha(settings: Settings, api) -> str:
    """Remember the exact remote metadata version after the app publishes it."""
    result = api.get_repo_file(
        settings.gallery_repo,
        settings.remote_metadata_filename,
    )
    if result is None:
        return ""
    raw, sha = result
    remember_remote_state(settings, sha, _read_remote_csv(raw))
    return sha
