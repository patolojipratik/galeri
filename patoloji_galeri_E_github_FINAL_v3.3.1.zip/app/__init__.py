"""Patoloji Pratik Slayt Yayincisi."""

__version__ = "3.0-final"
