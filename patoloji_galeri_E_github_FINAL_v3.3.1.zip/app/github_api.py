from __future__ import annotations

import base64
import time
from typing import Any

import requests


class GitHubError(RuntimeError):
    pass


class GitHubAPI:
    def __init__(self, token: str, username: str | None = None) -> None:
        self.username = username
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {token}",
                "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "patoloji-pratik-gallery-uploader/1.0",
            }
        )

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        expected: tuple[int, ...] = (200,),
        retries: int = 6,
        **kwargs: Any,
    ) -> requests.Response:
        url = endpoint if endpoint.startswith("http") else f"https://api.github.com{endpoint}"
        last: requests.Response | None = None
        last_connection_error: requests.RequestException | None = None
        for attempt in range(retries):
            try:
                response = self.session.request(method, url, timeout=60, **kwargs)
            except requests.RequestException as exc:
                # GitHub ya da ara ag katmani baglantiyi yanitsiz kapatabilir.
                # Bu tur gecici hatalar yuklemenin basarisiz oldugu anlamina gelmez;
                # ayni API kontrolunu artan bekleme ile yeniden dene.
                last_connection_error = exc
                if attempt < retries - 1:
                    time.sleep(min(60, 2 ** attempt))
                    continue
                raise GitHubError(
                    f"GitHub baglantisi {retries} denemeden sonra kurulamadi: {exc}"
                ) from exc
            last = response
            if response.status_code in expected:
                return response
            if response.status_code in (403, 429) or response.status_code >= 500:
                retry_after = response.headers.get("Retry-After")
                wait = int(retry_after) if retry_after and retry_after.isdigit() else min(60, 2 ** attempt)
                time.sleep(wait)
                continue
            break
        if last is None and last_connection_error is not None:
            raise GitHubError(f"GitHub baglantisi kurulamadi: {last_connection_error}")
        assert last is not None
        try:
            detail = last.json().get("message", last.text)
        except ValueError:
            detail = last.text
        if last.status_code == 401:
            raise GitHubError(
                f"GitHub API {method} {endpoint}: 401 - Bad credentials. "
                "Token gecersiz, eksik, suresi dolmus veya iptal edilmis olabilir."
            )
        raise GitHubError(f"GitHub API {method} {endpoint}: {last.status_code} - {detail}")

    def verify_user(self) -> dict[str, Any]:
        return self.request("GET", "/user").json()

    def repo_exists(self, repo_name: str) -> bool:
        assert self.username
        response = self.request(
            "GET",
            f"/repos/{self.username}/{repo_name}",
            expected=(200, 404),
        )
        return response.status_code == 200

    def create_public_repo(self, repo_name: str, description: str) -> None:
        if self.repo_exists(repo_name):
            return
        self.request(
            "POST",
            "/user/repos",
            expected=(201,),
            json={
                "name": repo_name,
                "description": description,
                "private": False,
                "has_issues": False,
                "has_projects": False,
                "has_wiki": False,
                "auto_init": False,
            },
        )
        time.sleep(2)

    def enable_pages(self, repo_name: str) -> str:
        assert self.username
        endpoint = f"/repos/{self.username}/{repo_name}/pages"
        payload = {"source": {"branch": "main", "path": "/"}}
        for attempt in range(8):
            try:
                current = self.session.get(
                    f"https://api.github.com{endpoint}", timeout=60
                )
                if current.status_code == 200:
                    update = self.session.put(
                        f"https://api.github.com{endpoint}", json=payload, timeout=60
                    )
                    if update.status_code in (200, 204):
                        data = update.json() if update.content else current.json()
                        return data.get("html_url") or f"https://{self.username}.github.io/{repo_name}/"
                elif current.status_code == 404:
                    create = self.session.post(
                        f"https://api.github.com{endpoint}", json=payload, timeout=60
                    )
                    if create.status_code == 201:
                        return create.json().get("html_url") or f"https://{self.username}.github.io/{repo_name}/"
                    if create.status_code not in (403, 409, 422, 429):
                        raise GitHubError(
                            f"Pages acilamadi ({repo_name}): {create.status_code} {create.text}"
                        )
                elif current.status_code not in (403, 429):
                    raise GitHubError(
                        f"Pages durumu alinamadi ({repo_name}): {current.status_code} {current.text}"
                    )
            except requests.RequestException:
                # Gecici baglanti kopmalarinda ayni Pages islemini yeniden dene.
                pass
            time.sleep(min(30, 2 ** attempt))
        raise GitHubError(
            f"Pages acilamadi ({repo_name}). main branch GitHub tarafinda hazir olmayabilir."
        )

    def get_pages(self, repo_name: str) -> dict[str, Any] | None:
        assert self.username
        response = self.request(
            "GET",
            f"/repos/{self.username}/{repo_name}/pages",
            expected=(200, 404),
        )
        return response.json() if response.status_code == 200 else None

    def get_branch_sha(self, repo_name: str, branch: str = "main") -> str:
        assert self.username
        data = self.request(
            "GET",
            f"/repos/{self.username}/{repo_name}/branches/{branch}",
        ).json()
        return str(data.get("commit", {}).get("sha", ""))


    def get_repo_file(
        self,
        repo_name: str,
        path: str,
        ref: str = "main",
    ) -> tuple[bytes, str] | None:
        """Return repository file bytes and blob SHA, or None when absent."""
        assert self.username
        endpoint = f"/repos/{self.username}/{repo_name}/contents/{path}"
        response = self.request(
            "GET",
            endpoint,
            expected=(200, 404),
            params={"ref": ref},
        )
        if response.status_code == 404:
            return None
        data = response.json()
        if data.get("type") != "file":
            raise GitHubError(f"Repo yolu dosya degil: {repo_name}/{path}")
        content = str(data.get("content") or "").replace("\n", "")
        try:
            raw = base64.b64decode(content)
        except Exception as exc:
            raise GitHubError(f"Repo dosyasi cozulmedi: {repo_name}/{path}") from exc
        return raw, str(data.get("sha") or "")

    def set_repo_homepage(self, repo_name: str, homepage: str) -> None:
        assert self.username
        self.request(
            "PATCH",
            f"/repos/{self.username}/{repo_name}",
            json={"homepage": homepage},
        )


def page_is_reachable(url: str, timeout_seconds: int, progress=None) -> bool:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            response = requests.get(url, timeout=20, allow_redirects=True)
            if response.status_code == 200 and "openseadragon" in response.text.lower():
                return True
        except requests.RequestException:
            pass
        if progress:
            progress("GitHub Pages yayini bekleniyor", None)
        time.sleep(10)
    return False
