from __future__ import annotations

import csv
import os
import shutil
import time
import uuid
from pathlib import Path
from typing import Any

from .config import Settings
from .utils import now_iso

FIELDS = [
    "gallery_id",
    "number",
    "source_name",
    "source_path",
    "source_size",
    "source_mtime_ns",
    "source_format",
    "sha256",
    "title",
    "organ",
    "diagnosis",
    "description",
    "tags",
    "status",
    "phase",
    "attempts",
    "repo_url",
    "page_url",
    "thumbnail_url",
    "label_url",
    "last_verified_sha",
    "published_at",
    "local_status",
    "local_freed_bytes",
    "recovery_note",
    "error",
    "updated_at",
]

# These columns may be edited by the user in Excel. When a newer public CSV is
# detected while a pending machine-state file exists, only these fields are
# merged back into the canonical state.
EDITABLE_FIELDS = ("title", "organ", "diagnosis", "description", "tags")


def _pending_path(settings: Settings) -> Path:
    return settings.data_dir / "slides.pending.csv"


def _lock_notice_path(settings: Settings) -> Path:
    return settings.data_dir / "slides_csv_kilitli.txt"


def _read_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]




def _normalize_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    """Ensure older CSV files gain newly added columns without losing data."""
    normalized: list[dict[str, str]] = []
    for source in rows:
        row = {field: str(source.get(field, "") or "") for field in FIELDS}
        normalized.append(row)
    return normalized


def _write_csv_file(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with temp.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS, extrasaction="ignore")
            writer.writeheader()
            for row in sorted(rows, key=lambda r: int(r.get("number") or 0)):
                writer.writerow({field: row.get(field, "") for field in FIELDS})
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass


def _append_inventory_log(settings: Settings, message: str) -> None:
    try:
        settings.logs_dir.mkdir(parents=True, exist_ok=True)
        with (settings.logs_dir / "inventory.log").open("a", encoding="utf-8") as handle:
            handle.write(f"{now_iso()} {message}\n")
    except OSError:
        pass


def backup_inventory(
    settings: Settings,
    rows: list[dict[str, Any]] | None = None,
    *,
    reason: str = "manual",
    keep: int = 50,
) -> Path | None:
    """Create a timestamped inventory backup before user-authored metadata changes.

    Machine-state updates happen frequently, so backups are intentionally created
    only by metadata editing/synchronization paths rather than every pipeline write.
    """
    try:
        rows = rows if rows is not None else load_rows(settings)
        if not rows:
            return None
        backup_dir = settings.data_dir / "yedek"
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        safe_reason = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in reason)
        path = backup_dir / f"slides_{stamp}_{safe_reason or 'backup'}.csv"
        counter = 1
        while path.exists():
            path = backup_dir / f"slides_{stamp}_{safe_reason or 'backup'}_{counter}.csv"
            counter += 1
        _write_csv_file(path, rows)
        backups = sorted(backup_dir.glob("slides_*.csv"), key=lambda item: item.stat().st_mtime_ns)
        for old in backups[:-max(1, keep)]:
            try:
                old.unlink()
            except OSError:
                pass
        _append_inventory_log(settings, f"Envanter yedegi olusturuldu: {path.name}")
        return path
    except OSError as exc:
        _append_inventory_log(settings, f"Envanter yedegi olusturulamadi: {exc}")
        return None


def _normalize_tags(value: Any) -> str:
    pieces = str(value or "").replace(";", ",").split(",")
    result: list[str] = []
    seen: set[str] = set()
    for piece in pieces:
        tag = " ".join(piece.strip().split())
        if not tag:
            continue
        key = tag.casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(tag)
    return ", ".join(result)


def _merge_newer_user_edits(
    pending_rows: list[dict[str, str]],
    public_rows: list[dict[str, str]],
) -> list[dict[str, str]]:
    public_by_id = {row.get("gallery_id", ""): row for row in public_rows}
    for row in pending_rows:
        public = public_by_id.get(row.get("gallery_id", ""))
        if not public:
            continue
        for field in EDITABLE_FIELDS:
            # Empty values are also meaningful: the user may intentionally clear
            # a diagnosis or description.
            if field in public:
                row[field] = public.get(field, "")
    return pending_rows


def load_rows(settings: Settings) -> list[dict[str, str]]:
    """Load the newest durable state.

    slides.csv is convenient for Excel, but Windows/Excel may lock it. In that
    case every state update is written to slides.pending.csv and processing
    continues. The pending file is treated as canonical until it can be synced.
    """
    public_path = settings.slides_csv
    pending_path = _pending_path(settings)

    if pending_path.exists():
        try:
            pending_rows = _read_rows(pending_path)
        except (OSError, csv.Error):
            pending_rows = []
        if pending_rows:
            try:
                if (
                    public_path.exists()
                    and public_path.stat().st_mtime_ns > pending_path.stat().st_mtime_ns
                ):
                    pending_rows = _merge_newer_user_edits(
                        pending_rows,
                        _read_rows(public_path),
                    )
            except (OSError, csv.Error):
                pass
            return _normalize_rows(pending_rows)

    return _normalize_rows(_read_rows(public_path))


def sync_pending_csv(settings: Settings, retries: int = 10) -> bool:
    """Try to publish slides.pending.csv to slides.csv.

    Returns False instead of raising when Excel or another process keeps
    slides.csv locked. The pending file remains durable and the pipeline may
    safely continue.
    """
    pending = _pending_path(settings)
    if not pending.exists():
        return True

    settings.data_dir.mkdir(parents=True, exist_ok=True)
    backup = settings.slides_csv.with_suffix(".csv.bak")
    sync_temp = settings.data_dir / f".slides.sync.{os.getpid()}.{uuid.uuid4().hex}.tmp"
    last_error: OSError | None = None

    try:
        shutil.copyfile(pending, sync_temp)
        for attempt in range(max(1, retries)):
            try:
                if settings.slides_csv.exists():
                    try:
                        shutil.copy2(settings.slides_csv, backup)
                    except OSError:
                        pass
                os.replace(sync_temp, settings.slides_csv)
                pending.unlink(missing_ok=True)
                _lock_notice_path(settings).unlink(missing_ok=True)
                _append_inventory_log(settings, "slides.pending.csv slides.csv ile esitlendi.")
                return True
            except PermissionError as exc:
                last_error = exc
            except OSError as exc:
                # Windows sometimes reports sharing violations as a generic
                # OSError/WinError 5 or 32 rather than PermissionError.
                last_error = exc
            if attempt + 1 < retries:
                time.sleep(min(0.25 * (attempt + 1), 1.5))
                if not sync_temp.exists():
                    shutil.copyfile(pending, sync_temp)
    finally:
        try:
            sync_temp.unlink(missing_ok=True)
        except OSError:
            pass

    notice = (
        "slides.csv Excel veya baska bir program tarafindan kilitli.\n"
        "Yayin islemi DURMADI; en yeni durum slides.pending.csv dosyasinda tutuluyor.\n"
        "Excel'i kapattiginizda program bir sonraki kayitta otomatik olarak esitleyecek.\n"
        f"Son hata: {last_error or 'Bilinmeyen dosya kilidi'}\n"
    )
    try:
        _lock_notice_path(settings).write_text(notice, encoding="utf-8")
    except OSError:
        pass
    _append_inventory_log(settings, notice.replace("\n", " | ").strip())
    return False


def save_rows(settings: Settings, rows: list[dict[str, Any]]) -> bool:
    """Durably save state without ever stopping the publishing queue for a CSV lock."""
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    pending = _pending_path(settings)

    # The pending file is the crash-safe canonical write. It has a unique temp
    # name, so a stale slides.tmp from a prior power loss cannot block updates.
    _write_csv_file(pending, rows)

    # Best effort synchronization to the Excel-friendly slides.csv. A lock is
    # recorded but deliberately not raised to the pipeline.
    return sync_pending_csv(settings)


def scan_sources(settings: Settings) -> list[dict[str, str]]:
    """Kaynak klasore sonradan eklenen destekli slaytlari kuyruga ekle.

    Mevcut gallery numaralari degismez. Yeni dosyalar siradaki numarayi alir.
    Uzanti kontrolu buyuk/kucuk harfe duyarsizdir.
    """
    source = settings.source_path
    if not source.exists():
        raise FileNotFoundError(f"Kaynak klasor bulunamadi: {source}")

    rows = load_rows(settings)
    by_name = {row.get("source_name", "").lower(): row for row in rows}
    max_number = max((int(r.get("number") or 0) for r in rows), default=0)
    extensions = set(settings.supported_extensions)
    files = sorted(
        (p for p in source.iterdir() if p.is_file() and p.suffix.lower() in extensions),
        key=lambda p: p.name.lower(),
    )

    for file in files:
        stat = file.stat()
        key = file.name.lower()
        source_format = file.suffix.lower().lstrip(".").upper()
        if key in by_name:
            existing = by_name[key]
            existing["source_path"] = str(file)
            existing["source_size"] = str(stat.st_size)
            existing["source_mtime_ns"] = str(stat.st_mtime_ns)
            existing["source_format"] = source_format
            continue

        max_number += 1
        repo_name = settings.repo_name(max_number)
        row = {field: "" for field in FIELDS}
        row.update(
            {
                "gallery_id": repo_name,
                "number": str(max_number),
                "source_name": file.name,
                "source_path": str(file),
                "source_size": str(stat.st_size),
                "source_mtime_ns": str(stat.st_mtime_ns),
                "source_format": source_format,
                "title": f"Pratik slayti {max_number:0{settings.repo_digits}d}",
                "status": "pending",
                "phase": "pending",
                "attempts": "0",
                "repo_url": f"https://github.com/{settings.github_username}/{repo_name}",
                "page_url": settings.page_url(repo_name),
                "thumbnail_url": settings.page_url(repo_name) + "thumbnail.jpg",
                "label_url": settings.page_url(repo_name) + "label.jpg",
                "updated_at": now_iso(),
            }
        )
        rows.append(row)
        by_name[key] = row

    save_rows(settings, rows)
    return rows


def update_row(settings: Settings, gallery_id: str, **changes: Any) -> dict[str, str]:
    rows = load_rows(settings)
    for row in rows:
        if row.get("gallery_id") == gallery_id:
            for key, value in changes.items():
                row[key] = str(value) if value is not None else ""
            row["updated_at"] = now_iso()
            save_rows(settings, rows)
            return row
    raise KeyError(gallery_id)



def update_metadata_fields(
    settings: Settings,
    gallery_id: str,
    values: dict[str, Any],
) -> dict[str, str]:
    """Update user-facing metadata from the Python editor with a durable backup."""
    rows = load_rows(settings)
    target = next((row for row in rows if row.get("gallery_id") == gallery_id), None)
    if target is None:
        raise KeyError(gallery_id)

    backup_inventory(settings, rows, reason=f"metadata_{gallery_id}")
    for field in EDITABLE_FIELDS:
        if field not in values:
            continue
        value = values.get(field, "")
        target[field] = _normalize_tags(value) if field == "tags" else str(value or "").strip()
    target["updated_at"] = now_iso()
    save_rows(settings, rows)
    return target


def increment_attempt(settings: Settings, gallery_id: str) -> int:
    rows = load_rows(settings)
    for row in rows:
        if row.get("gallery_id") == gallery_id:
            value = int(row.get("attempts") or 0) + 1
            row["attempts"] = str(value)
            row["updated_at"] = now_iso()
            save_rows(settings, rows)
            return value
    raise KeyError(gallery_id)


def next_row(settings: Settings) -> dict[str, str] | None:
    rows = load_rows(settings)
    priority = {"converted": 0, "upload_error": 1, "pending": 2, "conversion_error": 3}
    candidates = [r for r in rows if r.get("status") in priority]
    if not candidates:
        return None
    return sorted(candidates, key=lambda r: (priority[r["status"]], int(r["number"])))[0]
