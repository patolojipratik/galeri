from __future__ import annotations

import getpass
import re

from app.config import load_settings, save_settings
from app.github_api import GitHubAPI, GitHubError
from app.token_store import save_token


def normalize_token(value: str) -> str:
    """Remove accidental quotes and whitespace introduced while copying."""
    token = value.strip().strip('"').strip("'")
    token = re.sub(r"\s+", "", token)
    return token


def token_looks_valid(token: str) -> bool:
    # Fine-grained PAT: github_pat_...  Classic PAT: ghp_...
    return token.startswith(("github_pat_", "ghp_")) and len(token) >= 30


def main() -> None:
    settings = load_settings()
    print("GitHub kullanici adi:", settings.github_username)
    print("Token ekranda gorunmez. GitHub'da olusturulunca yalnizca bir kez gosterilen")
    print("github_pat_... ile baslayan DEGERI yapistirin; token adini yapistirmayin.\n")

    token = normalize_token(
        getpass.getpass("Fine-grained GitHub tokenini yapistirin: ")
    )
    if not token:
        raise SystemExit("Token girilmedi.")
    if not token_looks_valid(token):
        raise SystemExit(
            "\nGirilen metin GitHub erisim tokenine benzemiyor.\n"
            "Fine-grained token 'github_pat_' ile baslamalidir.\n"
            "GitHub'da tokeni yeniden olusturun ve olusturma sonunda bir kez gosterilen\n"
            "tam degeri kopyalayip GITHUB_BAGLA.bat dosyasini yeniden calistirin."
        )

    api = GitHubAPI(token)
    try:
        profile = api.verify_user()
    except GitHubError as exc:
        message = str(exc)
        if "401" in message or "Bad credentials" in message:
            raise SystemExit(
                "\nGitHub tokeni kabul etmedi (401 - Bad credentials).\n"
                "Bu bir izin secimi hatasi degildir; token gecersiz, eksik kopyalanmis,\n"
                "suresi dolmus veya iptal edilmis demektir.\n\n"
                "Cozum:\n"
                "1. patolojipratik hesabinda yeni bir Fine-grained token olusturun.\n"
                "2. Resource owner: patolojipratik secin.\n"
                "3. Repository access: All repositories secin.\n"
                "4. Administration, Contents ve Pages: Read and write secin.\n"
                "5. Generate token sonrasi yalnizca bir kez gosterilen github_pat_...\n"
                "   degerinin tamamini kopyalayin.\n"
                "6. Bu dosyayi yeniden calistirin.\n\n"
                "Tokeni sohbet mesajina veya herhangi bir dosyaya yazmayin."
            ) from None
        raise SystemExit(f"\nGitHub baglantisi kurulamadi:\n{message}") from None

    login = profile["login"]
    if login.lower() != settings.github_username.lower():
        answer = input(
            f"Token {login} hesabina ait. Ayari {login} yapayim mi? [E/h]: "
        ).strip().lower()
        if answer not in ("", "e", "evet", "y", "yes"):
            raise SystemExit("Islem iptal edildi.")

    settings.github_username = login
    settings.commit_email = f"{profile['id']}+{login}@users.noreply.github.com"
    save_settings(settings)
    save_token(login, token)

    print("\nBaglanti basarili.")
    print("Hesap:", login)
    print("Yerel commit e-postasi:", settings.commit_email)
    print("Token Windows Kimlik Bilgileri Yoneticisi'ne kaydedildi.")


if __name__ == "__main__":
    main()
