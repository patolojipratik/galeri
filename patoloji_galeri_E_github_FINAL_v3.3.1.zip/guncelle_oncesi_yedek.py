from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
BACKUP = DATA / "yedek_kurulum"


def main() -> None:
    candidates = [DATA / "slides.csv", DATA / "slides.pending.csv"]
    existing = [path for path in candidates if path.exists()]
    if not existing:
        print("Mevcut slides.csv bulunmadi; yeni kurulum olarak devam ediliyor.")
        return
    BACKUP.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    for source in existing:
        destination = BACKUP / f"{source.stem}_before_v32_{stamp}{source.suffix}"
        shutil.copy2(source, destination)
        print(f"Veri yedegi: {destination}")


if __name__ == "__main__":
    main()
